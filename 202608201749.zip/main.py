import ctypes
import gzip
import heapq
import json
import math
import os
import random
import platform
import queue
import re
import shutil
import struct
import subprocess
import importlib
import tempfile
import threading
import time
import tkinter as tk
from ctypes import wintypes
from dataclasses import dataclass
from enum import Enum, auto


APP_TITLE = "造梦西游之黎尤浩劫篇 AI"
FIREFOX_PATH = r"D:\FirefoxPortable\FirefoxPortable.exe"
GAME_URL = "https://h.api.4399.com/g.php?gameId=100072570"
SAMPLE_W = 240
SAMPLE_H = 135
RESTART_WINDOW_SECONDS = 600.0
MAX_RESTARTS_PER_WINDOW = 3
RESTART_RESET_AFTER = 300.0


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", wintypes.LONG),
        ("top", wintypes.LONG),
        ("right", wintypes.LONG),
        ("bottom", wintypes.LONG),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", wintypes.LONG),
        ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class RGBQUAD(ctypes.Structure):
    _fields_ = [
        ("rgbBlue", ctypes.c_ubyte),
        ("rgbGreen", ctypes.c_ubyte),
        ("rgbRed", ctypes.c_ubyte),
        ("rgbReserved", ctypes.c_ubyte),
    ]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", RGBQUAD * 1)]


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", wintypes.DWORD),
        ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


@dataclass(frozen=True)
class RuntimeProfile:
    label: str
    sample_w: int
    sample_h: int
    loop_target: float
    ocr_interval: float
    ocr_max_width: int
    planning_depth: int
    input_scale: float
    cores: int
    memory_gb: float
    gpu_name: str = ""
    gpu_vram_gb: float = 0.0
    gpu_tier: int = 0
    prefer_dxgi: bool = False
    physical_cores: int = 0
    cpu_mhz: int = 0
    on_battery: bool = False
    disk_total_gb: float = 0.0
    disk_free_gb: float = 0.0
    model_memory_limit: int = 4200
    model_context_limit: int = 640
    model_save_interval: float = 180.0


def _memory_status():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MEMORYSTATUSEX)]
        kernel32.GlobalMemoryStatusEx.restype = wintypes.BOOL
        if kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return status
    except Exception:
        pass
    return None



class SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_ = [
        ("ACLineStatus", ctypes.c_ubyte),
        ("BatteryFlag", ctypes.c_ubyte),
        ("BatteryLifePercent", ctypes.c_ubyte),
        ("SystemStatusFlag", ctypes.c_ubyte),
        ("BatteryLifeTime", wintypes.DWORD),
        ("BatteryFullLifeTime", wintypes.DWORD),
    ]


def _power_status():
    try:
        status = SYSTEM_POWER_STATUS()
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GetSystemPowerStatus.argtypes = [ctypes.POINTER(SYSTEM_POWER_STATUS)]
        kernel32.GetSystemPowerStatus.restype = wintypes.BOOL
        if kernel32.GetSystemPowerStatus(ctypes.byref(status)):
            return status.ACLineStatus == 0
    except Exception:
        pass
    return False


def _storage_status(path):
    try:
        usage = shutil.disk_usage(os.path.abspath(path or os.getcwd()))
        return usage.total / (1024.0 ** 3), usage.free / (1024.0 ** 3)
    except OSError:
        return 0.0, 0.0


def _resolve_data_dir(script_dir):
    requested = str(os.environ.get("ZMYX_AI_DATA_DIR") or "").strip().strip('"')
    candidates = [requested, script_dir]
    local = str(os.environ.get("LOCALAPPDATA") or "").strip()
    if local:
        candidates.append(os.path.join(local, "ZMYX_AI"))
    for candidate in candidates:
        if not candidate:
            continue
        try:
            candidate = os.path.abspath(candidate)
            os.makedirs(candidate, exist_ok=True)
            probe = os.path.join(candidate, ".ai_write_probe.tmp")
            with open(probe, "wb") as handle:
                handle.write(b"ok")
            os.remove(probe)
            return candidate
        except OSError:
            continue
    return os.path.abspath(script_dir)


def _detect_cpu_info():
    physical = max(1, int(os.cpu_count() or 4) // 2)
    logical = max(1, int(os.cpu_count() or 4))
    mhz = 0
    try:
        command = (
            "$ErrorActionPreference='SilentlyContinue';"
            "$p=Get-CimInstance Win32_Processor | Select-Object NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed;"
            "if($p){$p | ConvertTo-Json -Compress}"
        )
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=2.5, creationflags=flags,
        )
        text = (result.stdout or "").strip()
        if text:
            data = json.loads(text)
            rows = data if isinstance(data, list) else [data]
            physical = max(1, sum(max(0, int(row.get("NumberOfCores") or 0)) for row in rows))
            logical = max(1, sum(max(0, int(row.get("NumberOfLogicalProcessors") or 0)) for row in rows))
            mhz = max([max(0, int(row.get("MaxClockSpeed") or 0)) for row in rows] or [0])
    except Exception:
        pass
    return physical, logical, mhz

def _detect_gpu_info():
    name = ""
    vram_gb = 0.0
    try:
        command = (
            "$ErrorActionPreference='SilentlyContinue';"
            "$g=Get-CimInstance Win32_VideoController | "
            "Where-Object {$_.Name -notmatch 'Microsoft Basic|Remote Display'} | "
            "Sort-Object AdapterRAM -Descending | Select-Object -First 1 Name,AdapterRAM;"
            "if($g){$g | ConvertTo-Json -Compress}"
        )
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=3.0,
            creationflags=flags,
        )
        text = (result.stdout or "").strip()
        if text:
            data = json.loads(text)
            name = str(data.get("Name") or "").strip()
            ram = float(data.get("AdapterRAM") or 0.0)
            if ram > 0:
                vram_gb = ram / (1024.0 ** 3)
    except Exception:
        pass
    if "NVIDIA" in name.upper():
        try:
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=2.0, creationflags=flags,
            )
            first = (result.stdout or "").strip().splitlines()[0]
            gpu_name, memory_mb = [part.strip() for part in first.rsplit(",", 1)]
            if gpu_name:
                name = gpu_name
            vram_gb = max(vram_gb, float(memory_mb) / 1024.0)
        except Exception:
            pass
    upper = name.upper()
    tier = 0
    if any(token in upper for token in ("RTX", "RADEON RX", "ARC A", "QUADRO", "RTX A")):
        tier = 3
    elif any(token in upper for token in ("GTX", "RADEON", "ARC", "VEGA", "IRIS XE")):
        tier = 2
    elif any(token in upper for token in ("INTEL", "AMD", "NVIDIA")):
        tier = 1
    if vram_gb >= 6.0:
        tier = max(tier, 3)
    elif vram_gb >= 2.0:
        tier = max(tier, 2)
    return name, vram_gb, tier


def detect_runtime_profile(data_dir=None):
    physical_cores, cores, cpu_mhz = _detect_cpu_info()
    status = _memory_status()
    memory_gb = status.ullTotalPhys / (1024.0 ** 3) if status else 0.0
    pointer_bits = ctypes.sizeof(ctypes.c_void_p) * 8
    gpu_name, gpu_vram_gb, gpu_tier = _detect_gpu_info()
    on_battery = _power_status()
    disk_total_gb, disk_free_gb = _storage_status(data_dir or os.path.dirname(os.path.abspath(__file__)))

    memory_score = 1.0 if memory_gb <= 0.0 else min(5.0, memory_gb / 4.0)
    cpu_score = physical_cores * 0.78 + cores * 0.22
    if cpu_mhz > 0:
        cpu_score *= max(0.72, min(1.28, cpu_mhz / 3600.0))
    gpu_score = gpu_tier * 1.25 + min(2.0, gpu_vram_gb / 4.0)
    total_score = cpu_score + memory_score + gpu_score
    if on_battery:
        total_score -= 1.6

    prefer_dxgi = (
        pointer_bits >= 64 and gpu_tier >= 1 and cores >= 4
        and (memory_gb <= 0.0 or memory_gb >= 5.0) and not on_battery
    )

    if total_score >= 18.0 and cores >= 12 and (memory_gb <= 0.0 or memory_gb >= 12.0):
        deep_plan = 4 if cores >= 16 and gpu_tier >= 2 and (memory_gb <= 0.0 or memory_gb >= 24.0) else 3
        label, sample_w, sample_h, loop_target, ocr_interval, ocr_max_width, planning_depth, input_scale = (
            "旗舰", 416 if gpu_tier >= 2 else 368, 234 if gpu_tier >= 2 else 207,
            0.032 if gpu_tier >= 2 else 0.040, 0.58, 1920, deep_plan, 0.88
        )
    elif total_score >= 12.0 and cores >= 8 and (memory_gb <= 0.0 or memory_gb >= 8.0):
        label, sample_w, sample_h, loop_target, ocr_interval, ocr_max_width, planning_depth, input_scale = (
            "高性能", 344 if gpu_tier >= 2 else 320, 194 if gpu_tier >= 2 else 180,
            0.045 if gpu_tier >= 2 else 0.052, 0.80, 1536, 3, 0.94
        )
    elif total_score >= 7.0 and cores >= 4 and (memory_gb <= 0.0 or memory_gb >= 5.0):
        label, sample_w, sample_h, loop_target, ocr_interval, ocr_max_width, planning_depth, input_scale = (
            "均衡", 280 if gpu_tier >= 2 else 256, 158 if gpu_tier >= 2 else 144,
            0.060 if gpu_tier >= 2 else 0.072, 1.02, 1344, 2, 1.00
        )
    else:
        label, sample_w, sample_h, loop_target, ocr_interval, ocr_max_width, planning_depth, input_scale = (
            "兼容", 208, 117, 0.105, 1.55, 1024, 1, 1.06
        )
    if on_battery:
        loop_target *= 1.18
        ocr_interval *= 1.22
        planning_depth = min(planning_depth, 2)

    if label == "旗舰":
        model_memory_limit, model_context_limit, model_save_interval = 18000, 4200, 240.0
    elif label == "高性能":
        model_memory_limit, model_context_limit, model_save_interval = 12000, 2800, 210.0
    elif label == "均衡":
        model_memory_limit, model_context_limit, model_save_interval = 7600, 1700, 180.0
    else:
        model_memory_limit, model_context_limit, model_save_interval = 4600, 900, 150.0
    if memory_gb >= 32.0 and disk_free_gb >= 40.0:
        model_memory_limit = int(model_memory_limit * 1.25)
        model_context_limit = int(model_context_limit * 1.20)
    if disk_free_gb > 0.0:
        if disk_free_gb < 1.5:
            model_memory_limit = min(model_memory_limit, 3200)
            model_context_limit = min(model_context_limit, 600)
            model_save_interval = max(model_save_interval, 420.0)
        elif disk_free_gb < 5.0:
            model_memory_limit = min(model_memory_limit, 5200)
            model_context_limit = min(model_context_limit, 1000)
            model_save_interval = max(model_save_interval, 300.0)
        elif disk_free_gb >= 250.0 and memory_gb >= 24.0:
            model_memory_limit = int(model_memory_limit * 1.15)
            model_context_limit = int(model_context_limit * 1.12)

    return RuntimeProfile(
        label=label, sample_w=sample_w, sample_h=sample_h, loop_target=loop_target,
        ocr_interval=ocr_interval, ocr_max_width=ocr_max_width, planning_depth=planning_depth,
        input_scale=input_scale, cores=cores, memory_gb=memory_gb, gpu_name=gpu_name,
        gpu_vram_gb=gpu_vram_gb, gpu_tier=gpu_tier, prefer_dxgi=prefer_dxgi,
        physical_cores=physical_cores, cpu_mhz=cpu_mhz, on_battery=on_battery,
        disk_total_gb=disk_total_gb, disk_free_gb=disk_free_gb,
        model_memory_limit=max(3000, model_memory_limit),
        model_context_limit=max(500, model_context_limit),
        model_save_interval=max(90.0, model_save_interval),
    )


def _ensure_dxcam(base_dir, stop_event=None):
    if stop_event is not None and stop_event.is_set():
        return None, None
    try:
        return importlib.import_module("dxcam"), importlib.import_module("numpy")
    except Exception:
        return None, None


class RuntimeGovernor:
    def __init__(self, profile):
        self.profile = profile
        self.process_ema = profile.loop_target * 0.55
        self.ocr_scale = 1.0
        self.overruns = 0
        self.healthy = 0
        self.cycles = 0
        self.cpu_load = 0.0
        self.memory_load = 0.0
        self.dynamic_depth = profile.planning_depth
        self.dynamic_input_scale = profile.input_scale
        self.dynamic_loop_target = profile.loop_target
        self.candidate_budget = self._candidate_ceiling()
        self.mode = "电池节能" if profile.on_battery else "正常"
        self._last_system_sample = 0.0
        self._system_times = None
        try:
            self._kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            self._kernel32.GetSystemTimes.argtypes = [
                ctypes.POINTER(wintypes.FILETIME), ctypes.POINTER(wintypes.FILETIME), ctypes.POINTER(wintypes.FILETIME)
            ]
            self._kernel32.GetSystemTimes.restype = wintypes.BOOL
        except Exception:
            self._kernel32 = None

    def _candidate_ceiling(self):
        if self.profile.planning_depth >= 4:
            return 19 if self.profile.cores >= 20 else 17
        if self.profile.planning_depth >= 3:
            return 15 if self.profile.cores >= 16 else 13
        if self.profile.planning_depth == 2:
            return 11 if self.profile.cores >= 10 else 9
        return 7

    @staticmethod
    def _filetime_value(value):
        return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)

    def _sample_system(self):
        now = time.monotonic()
        if now - self._last_system_sample < 0.75:
            return
        self._last_system_sample = now
        status = _memory_status()
        if status:
            self.memory_load = max(0.0, min(1.0, float(status.dwMemoryLoad) / 100.0))
        if not self._kernel32:
            return
        idle = wintypes.FILETIME()
        kernel = wintypes.FILETIME()
        user = wintypes.FILETIME()
        try:
            if not self._kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
                return
            values = tuple(self._filetime_value(item) for item in (idle, kernel, user))
            if self._system_times is not None:
                di = values[0] - self._system_times[0]
                dk = values[1] - self._system_times[1]
                du = values[2] - self._system_times[2]
                total = max(1, dk + du)
                self.cpu_load = max(0.0, min(1.0, 1.0 - di / total))
            self._system_times = values
        except Exception:
            pass

    @property
    def ocr_interval(self):
        return self.profile.ocr_interval * self.ocr_scale

    @property
    def estimated_hz(self):
        return 1.0 / max(self.dynamic_loop_target, self.process_ema, 0.001)

    @property
    def planning_depth(self):
        return self.dynamic_depth

    @property
    def input_scale(self):
        return self.dynamic_input_scale

    def finish(self, elapsed):
        elapsed = max(0.0, float(elapsed))
        self.cycles += 1
        self.process_ema = self.process_ema * 0.91 + elapsed * 0.09
        self._sample_system()
        base = max(self.profile.loop_target, 0.001)
        pressure = max(
            self.process_ema / max(self.dynamic_loop_target, 0.001),
            self.cpu_load / 0.84 if self.cpu_load else 0.0,
            self.memory_load / 0.88 if self.memory_load else 0.0,
        )
        if pressure > 1.52:
            self.overruns += 2
            self.healthy = 0
        elif pressure > 1.18:
            self.overruns += 1
            self.healthy = max(0, self.healthy - 2)
        elif pressure < 0.74:
            self.overruns = max(0, self.overruns - 1)
            self.healthy += 1
        else:
            self.overruns = max(0, self.overruns - 1)
            self.healthy = max(0, self.healthy - 1)

        if self.overruns >= 8:
            severe = pressure > 1.48 or self.memory_load > 0.93
            self.ocr_scale = min(3.6, self.ocr_scale * (1.18 if severe else 1.10))
            self.dynamic_depth = max(1, self.dynamic_depth - 1)
            self.candidate_budget = max(5, self.candidate_budget - (2 if severe else 1))
            self.dynamic_input_scale = min(1.16, self.dynamic_input_scale * 1.018)
            cap = base * (2.15 if severe else 1.72)
            self.dynamic_loop_target = min(cap, self.dynamic_loop_target * (1.14 if severe else 1.07))
            self.mode = "强降载" if severe else "降载"
            self.overruns = 0
        elif self.healthy >= 75:
            self.ocr_scale = max(0.84, self.ocr_scale * 0.94)
            if self.cycles % 2 == 0:
                self.dynamic_depth = min(self.profile.planning_depth, self.dynamic_depth + 1)
            self.candidate_budget = min(self._candidate_ceiling(), self.candidate_budget + 1)
            self.dynamic_input_scale += (self.profile.input_scale - self.dynamic_input_scale) * 0.38
            floor = base * (1.0 if not self.profile.on_battery else 1.08)
            self.dynamic_loop_target = max(floor, self.dynamic_loop_target * 0.94)
            self.mode = "提质" if self.dynamic_depth == self.profile.planning_depth else "恢复"
            self.healthy = 0
        elif self.cycles % 140 == 0 and self.mode not in ("强降载", "电池节能"):
            self.mode = "正常"

        if self.profile.on_battery:
            self.dynamic_loop_target = max(self.dynamic_loop_target, base * 1.05)
            self.dynamic_depth = min(self.dynamic_depth, 2)
        return max(0.004, self.dynamic_loop_target - elapsed)


def enable_dpi_awareness():
                                                                                             
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        if hasattr(user32, "SetProcessDpiAwarenessContext"):
            user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))                        
            return
    except Exception:
        pass
    try:
        ctypes.WinDLL("shcore", use_last_error=True).SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.WinDLL("user32", use_last_error=True).SetProcessDPIAware()
        except Exception:
            pass


class GameState(Enum):
    LOADING = auto()
    HOME = auto()
    SELECT_STAGE = auto()
    COMBAT = auto()
    REWARD = auto()
    EQUIPMENT = auto()
    UPGRADE = auto()
    RETRY = auto()
    UNKNOWN = auto()


STATE_NAMES = {
    GameState.LOADING: "加载",
    GameState.HOME: "主城/主页",
    GameState.SELECT_STAGE: "选择关卡",
    GameState.COMBAT: "战斗",
    GameState.REWARD: "奖励",
    GameState.EQUIPMENT: "装备",
    GameState.UPGRADE: "强化",
    GameState.RETRY: "死亡/重试",
    GameState.UNKNOWN: "未知界面",
}


class RestartGame(RuntimeError):
    pass


@dataclass(frozen=True)
class OCRWord:
    text: str
    x: float
    y: float
    w: float
    h: float
    line: int = -1

    @property
    def cx(self):
        return self.x + self.w / 2.0

    @property
    def cy(self):
        return self.y + self.h / 2.0


@dataclass
class OCRSnapshot:
    text: str
    words: tuple
    width: int
    height: int
    captured_at: float


@dataclass
class PendingAction:
    kind: str
    state: GameState
    fingerprint: tuple
    at: float
    power_before: int
    completed: bool = False


@dataclass
class StageStats:
    attempts: int = 0
    wins: int = 0
    total_seconds: float = 0.0
    stuck_events: int = 0

    @property
    def success_rate(self):
        return self.wins / self.attempts if self.attempts else 0.0

    @property
    def average_seconds(self):
        return self.total_seconds / self.wins if self.wins else 9999.0


@dataclass
class ActionStats:
    attempts: int = 0
    successes: int = 0
    failures: int = 0
    total_power_delta: int = 0
    total_seconds: float = 0.0

    @property
    def success_rate(self):
        return self.successes / self.attempts if self.attempts else 0.0

    @property
    def average_delta(self):
        return self.total_power_delta / self.successes if self.successes else 0.0

    @property
    def average_seconds(self):
        return self.total_seconds / self.attempts if self.attempts else 5.0


@dataclass
class CombatObservation:
    hp_ratio: object = None
    mp_ratio: object = None
    boss_ratio: object = None
    player_x: object = None
    enemy_x: object = None
    motion: float = 0.0


@dataclass
class WorldState:
    hp: object = None
    mp: object = None
    boss: object = None
    player_x: object = None
    target_x: object = None
    distance: object = None
    target_side: float = 0.0
    motion: float = 0.0
    scene_change: float = 0.0
    novelty: float = 0.0
    flow_x: float = 0.0
    flow_y: float = 0.0
    crowd: float = 0.0
    edge_energy: float = 0.0
    active_x: float = 0.5
    active_y: float = 0.55
    threat: float = 0.0
    incoming: float = 0.0
    dealt: float = 0.0
    combo: float = 0.0
    engaged: float = 0.0
    advantage: float = 0.5
    progress: float = 0.0
    telegraph: float = 0.0
    escape_side: float = 0.0
    opening: float = 0.0
    phase_shift: float = 0.0
    risk_trend: float = 0.0
    impact_risk: float = 0.0
    latent: tuple = ()
    fingerprint: tuple = ()
    captured_at: float = 0.0


class SceneUnderstanding:
    def __init__(self, vision, width=SAMPLE_W, height=SAMPLE_H):
        self.vision = vision
        self.width = width
        self.height = height
        self.prototypes = []
        self.max_prototypes = 128
        self.last_grid = None
        self.last_hp = None
        self.last_boss = None
        self.last_distance = None
        self.last_at = 0.0
        self.incoming_ema = 0.0
        self.dealt_ema = 0.0
        self.closing_ema = 0.0
        self.threat_ema = 0.0
        self.combo_ema = 0.0
        self.last_telegraph = 0.0
        self.last_threat_sample = 0.0
        self.risk_at = 0.0
        self.impact_ema = 0.0

    def reset_episode(self):
        self.last_grid = None
        self.last_hp = None
        self.last_boss = None
        self.last_distance = None
        self.last_at = 0.0
        self.incoming_ema = 0.0
        self.dealt_ema = 0.0
        self.closing_ema = 0.0
        self.threat_ema = 0.0
        self.combo_ema = 0.0
        self.last_telegraph = 0.0
        self.last_threat_sample = 0.0
        self.risk_at = 0.0
        self.impact_ema = 0.0

    @staticmethod
    def _clamp(value, lo=0.0, hi=1.0):
        return max(lo, min(hi, value))

    def _grid(self, frame, cols=20, rows=11):
        values = []
        if not frame:
            return values
        x1 = int(self.width * 0.03)
        x2 = int(self.width * 0.97)
        y1 = int(self.height * 0.21)
        y2 = int(self.height * 0.91)
        for gy in range(rows):
            y = min(y2 - 1, y1 + int((gy + 0.5) * (y2 - y1) / rows))
            for gx in range(cols):
                x = min(x2 - 1, x1 + int((gx + 0.5) * (x2 - x1) / cols))
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                lum = (r * 3 + g * 6 + b) / 2550.0
                sat = (max(r, g, b) - min(r, g, b)) / 255.0
                values.append((lum, sat))
        return values

    @staticmethod
    def _shift_error(current, previous, cols, rows, dx, dy):
        total = 0.0
        count = 0
        for y in range(rows):
            py = y + dy
            if py < 0 or py >= rows:
                continue
            for x in range(cols):
                px = x + dx
                if px < 0 or px >= cols:
                    continue
                a = current[y * cols + x]
                b = previous[py * cols + px]
                total += abs(a[0] - b[0]) + abs(a[1] - b[1]) * 0.28
                count += 1
        return total / max(count, 1)

    def _flow(self, current, previous, cols=20, rows=11):
        if not current or not previous or len(current) != len(previous):
            return 0.0, 0.0
        candidates = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                candidates.append((self._shift_error(current, previous, cols, rows, dx, dy), dx, dy))
        candidates.sort(key=lambda item: item[0])
        _, dx, dy = candidates[0]
        return float(dx), float(dy)

    def _visual_latent(self, grid, previous, cols=20, rows=11):
        if not grid:
            return (0.5, 0.25, 0.0) * 6
        latent = []
        for by in range(2):
            y0 = by * rows // 2
            y1 = (by + 1) * rows // 2
            for bx in range(3):
                x0 = bx * cols // 3
                x1 = (bx + 1) * cols // 3
                lum = sat = delta = 0.0
                count = 0
                for y in range(y0, y1):
                    for x in range(x0, x1):
                        idx = y * cols + x
                        l, st = grid[idx]
                        lum += l
                        sat += st
                        if previous and idx < len(previous):
                            pl, ps = previous[idx]
                            delta += abs(l - pl) + abs(st - ps) * 0.35
                        count += 1
                inv = 1.0 / max(count, 1)
                latent.extend((
                    self._clamp(lum * inv),
                    self._clamp(sat * inv),
                    self._clamp(delta * inv * 3.2),
                ))
        return tuple(latent)

    @staticmethod
    def _feature_distance(a, b):
        if not a or not b or len(a) != len(b):
            return 9.0
        return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)) / len(a))

    def _novelty(self, feature):
        if not self.prototypes:
            self.prototypes.append(tuple(feature))
            return 1.0
        distance = min(self._feature_distance(feature, item) for item in self.prototypes)
        novelty = self._clamp(distance / 0.26)
        if distance > 0.13:
            if len(self.prototypes) >= self.max_prototypes:
                self.prototypes.pop(0)
            self.prototypes.append(tuple(feature))
        return novelty

    def _temporal(self, hp, boss, distance, motion, crowd, near, scene_change, novelty, now):
        if not self.last_at:
            dt = 0.12
        else:
            dt = max(0.05, min(0.55, now - self.last_at))
        incoming = 0.0
        dealt = 0.0
        closing = 0.0
        if hp is not None and self.last_hp is not None:
            incoming = self._clamp(max(0.0, self.last_hp - hp) / dt * 4.5)
        if boss is not None and self.last_boss is not None:
            dealt = self._clamp(max(0.0, self.last_boss - boss) / dt * 4.2)
        if distance is not None and self.last_distance is not None:
            closing = max(-1.0, min(1.0, (self.last_distance - distance) / dt * 2.6))
        self.incoming_ema = self.incoming_ema * 0.68 + incoming * 0.32
        self.dealt_ema = self.dealt_ema * 0.66 + dealt * 0.34
        self.closing_ema = self.closing_ema * 0.72 + closing * 0.28
        motion_pressure = self._clamp((motion - 2.0) / 8.0)
        low_hp = 0.0 if hp is None else self._clamp((0.38 - hp) / 0.38)
        threat_sample = self._clamp(
            self.incoming_ema * 0.62
            + motion_pressure * near * 0.20
            + crowd * 0.08
            + max(0.0, self.closing_ema) * near * 0.06
            + low_hp * 0.16
        )
        self.threat_ema = max(threat_sample, self.threat_ema * 0.78)
        combo_sample = self._clamp(
            self.dealt_ema * 0.58
            + near * 0.22
            + (1.0 - self.threat_ema) * 0.10
            + self._clamp(scene_change / 2.0) * 0.05
            + novelty * 0.05
        )
        self.combo_ema = self.combo_ema * 0.62 + combo_sample * 0.38
        hp_term = 0.0 if hp is None else (hp - 0.5) * 0.34
        advantage = self._clamp(0.5 + hp_term + self.dealt_ema * 0.30 - self.incoming_ema * 0.42)
        progress = self._clamp(self._clamp(scene_change / 1.8) * 0.55 + novelty * 0.20 + abs(self.closing_ema) * 0.25)
        self.last_hp = hp if hp is not None else self.last_hp
        self.last_boss = boss if boss is not None else self.last_boss
        self.last_distance = distance if distance is not None else self.last_distance
        self.last_at = now
        return self.threat_ema, self.incoming_ema, self.dealt_ema, self.combo_ema, advantage, progress

    def _spatial_risk(self, grid, prior, player_x, target_x, flow_x):
        if not grid or not prior or len(grid) != len(prior):
            return 0.0, 0.0
        cols, rows = 20, 11
        px = 0.50 if player_x is None else self._clamp(player_x)
        left_risk = 0.0
        right_risk = 0.0
        center_risk = 0.0
        total = 0.0
        for y in range(rows):
            ny = (y + 0.5) / rows
            if ny < 0.18 or ny > 0.96:
                continue
            vertical = 0.45 + 0.55 * (1.0 - abs(ny - 0.62))
            for x in range(cols):
                i = y * cols + x
                lum, sat = grid[i]
                pl, ps = prior[i]
                delta = abs(lum - pl) + abs(sat - ps) * 0.42
                if delta < 0.045:
                    continue
                nx = (x + 0.5) / cols
                dist = abs(nx - px)
                proximity = max(0.0, 1.0 - dist / 0.34)
                if proximity <= 0.0:
                    continue
                weight = delta * proximity * vertical
                total += weight
                if nx < px - 0.035:
                    left_risk += weight
                elif nx > px + 0.035:
                    right_risk += weight
                else:
                    center_risk += weight * 1.25
        if total <= 1e-8:
            return 0.0, 0.0
                                                                                      
                                                                                      
        approach_bonus = 0.0
        if player_x is not None:
            if flow_x > 0.08 and left_risk > right_risk:
                approach_bonus = min(0.45, abs(flow_x) * 0.55)
            elif flow_x < -0.08 and right_risk > left_risk:
                approach_bonus = min(0.45, abs(flow_x) * 0.55)
        normalized = self._clamp((center_risk * 1.35 + min(left_risk, right_risk) * 0.45 + max(left_risk, right_risk) * 0.72) / 2.5)
        telegraph = self._clamp(normalized + approach_bonus)
                                                                            
        imbalance = left_risk - right_risk
        escape_side = 0.0
        if abs(imbalance) > 0.025:
            escape_side = 1.0 if imbalance > 0 else -1.0
                                                                                      
                                                                               
        if target_x is not None and player_x is not None and telegraph > 0.48 and abs(imbalance) < 0.12:
            escape_side = -1.0 if target_x > player_x else 1.0
        return telegraph, escape_side

    def encode(self, frame, previous, obs, fingerprint, motion):
        now = time.monotonic()
        grid = self._grid(frame)
        prior = self.last_grid
        flow_x, flow_y = self._flow(grid, prior)
        latent = self._visual_latent(grid, prior)
        active = []
        edge = 0.0
        cols, rows = 20, 11
        if grid:
            for y in range(rows):
                for x in range(cols):
                    index = y * cols + x
                    lum, sat = grid[index]
                    if x + 1 < cols:
                        edge += abs(lum - grid[index + 1][0])
                    if y + 1 < rows:
                        edge += abs(lum - grid[index + cols][0])
                    if prior and index < len(prior):
                        d = abs(lum - prior[index][0]) + abs(sat - prior[index][1]) * 0.35
                        if d > 0.10:
                            active.append((x, y, d))
        self.last_grid = grid
        if active:
            weight = sum(item[2] for item in active)
            active_x = sum((x + 0.5) / cols * w for x, _, w in active) / weight
            active_y = sum((y + 0.5) / rows * w for _, y, w in active) / weight
            crowd = self._clamp(len(active) / (cols * rows * 0.34))
        else:
            active_x, active_y, crowd = 0.5, 0.55, 0.0
        edge_energy = edge / max(cols * rows * 0.35, 1.0)
        player_x = obs.player_x
        target_x = obs.enemy_x
        if player_x is not None and target_x is None and crowd > 0.08 and abs(active_x - player_x) > 0.10:
            target_x = active_x
        distance = None
        side = 0.0
        if player_x is not None and target_x is not None:
            distance = abs(target_x - player_x)
            side = 1.0 if target_x > player_x else -1.0
        coarse = []
        if grid:
            for gy in (1, 3, 5, 7, 9):
                for gx in (1, 4, 7, 10, 13, 16, 19):
                    idx = min(len(grid) - 1, gy * cols + gx)
                    coarse.extend(grid[idx])
        coarse.extend((
            self._clamp((motion or 0.0) / 12.0),
            crowd,
            self._clamp(edge_energy),
            (flow_x + 1.0) / 2.0,
            (flow_y + 1.0) / 2.0,
        ))
        coarse.extend(latent)
        novelty = self._novelty(coarse)
        previous_fp = self.vision.combat_fingerprint(previous) if previous else ()
        scene_change = self.vision.fingerprint_distance(fingerprint, previous_fp)
        near = 0.35 if distance is None else 1.0 - self._clamp(distance / 0.42)
        threat, incoming, dealt, combo, advantage, progress = self._temporal(
            obs.hp_ratio, obs.boss_ratio, distance, motion or 0.0, crowd, near, scene_change, novelty, now
        )
        telegraph, escape_side = self._spatial_risk(grid, prior, player_x, target_x, flow_x)
                                                                                       
                                                                                        
        incoming = self._clamp(max(incoming, telegraph * (0.78 + crowd * 0.18)))
        threat = self._clamp(max(threat, telegraph * 0.90, incoming * 0.92))
        risk_dt = 0.10 if not self.risk_at else max(0.04, min(0.40, now - self.risk_at))
        telegraph_slope = max(-1.0, min(1.0, (telegraph - self.last_telegraph) / risk_dt * 0.72))
        threat_slope = max(-1.0, min(1.0, (threat - self.last_threat_sample) / risk_dt * 0.58))
        risk_trend = max(-1.0, min(1.0, telegraph_slope * 0.68 + threat_slope * 0.32))
        closing_pressure = max(0.0, self.closing_ema) * near
        impact_sample = self._clamp(
            telegraph * 0.48 + incoming * 0.28 + threat * 0.12
            + max(0.0, risk_trend) * 0.34 + closing_pressure * 0.14
        )
        self.impact_ema = max(impact_sample, self.impact_ema * (0.80 if risk_trend > 0 else 0.70))
        self.last_telegraph = telegraph
        self.last_threat_sample = threat
        self.risk_at = now
        opening = self._clamp(dealt * 0.58 + combo * 0.28 + advantage * 0.34 - incoming * 0.54 - telegraph * 0.36 - self.impact_ema * 0.22)
        phase_shift = self._clamp(scene_change * 0.36 + novelty * 0.44 + (0.24 if obs.boss_ratio is not None and scene_change > 0.72 else 0.0))
        engaged = self._clamp(max(near, crowd * 0.72, 0.62 if obs.boss_ratio is not None else 0.0))
        return WorldState(
            hp=obs.hp_ratio,
            mp=obs.mp_ratio,
            boss=obs.boss_ratio,
            player_x=player_x,
            target_x=target_x,
            distance=distance,
            target_side=side,
            motion=motion or 0.0,
            scene_change=scene_change,
            novelty=novelty,
            flow_x=flow_x,
            flow_y=flow_y,
            crowd=crowd,
            edge_energy=edge_energy,
            active_x=active_x,
            active_y=active_y,
            threat=threat,
            incoming=incoming,
            dealt=dealt,
            combo=combo,
            engaged=engaged,
            advantage=advantage,
            progress=progress,
            telegraph=telegraph,
            escape_side=escape_side,
            opening=opening,
            phase_shift=phase_shift,
            risk_trend=risk_trend,
            impact_risk=self.impact_ema,
            latent=latent,
            fingerprint=fingerprint,
            captured_at=now,
        )


class CausalWorldModel:
    PRIMITIVES = ("A", "D", "W", "S", "F", "H", "J", "K", "U", "I", "O", "L", "Z", "SPACE")
    TACTICS = ("TOWARD", "RETREAT", "EVADE", "JJJ", "KJ", "CHASEJ", "UJ", "IJ", "OJ", "LJ", "SPACEJ")
    ACTIONS = PRIMITIVES + TACTICS
    EFFECT_DIM = 11
    COMPONENTS = {
        "JJJ": ("J",),
        "KJ": ("K", "J"),
        "CHASEJ": ("J",),
        "UJ": ("U", "J"),
        "IJ": ("I", "J"),
        "OJ": ("O", "J"),
        "LJ": ("L", "J"),
        "SPACEJ": ("SPACE", "J"),
        "EVADE": ("K",),
    }
    BASE_KEY_GAP = {
        "A": 0.10, "D": 0.10, "W": 0.10, "S": 0.10, "F": 0.30,
        "H": 1.15, "J": 0.11, "K": 0.16, "U": 0.58, "I": 0.58,
        "O": 0.58, "L": 0.58, "Z": 1.00, "SPACE": 1.05,
    }

    def __init__(self, path, profile=None, legacy_path=None):
        self.path = path
        self.legacy_path = legacy_path
        self.profile = profile
        self.memory = []
        self.max_memory = max(3000, int(getattr(profile, "model_memory_limit", 4200)))
        self.by_action = {key: [] for key in self.ACTIONS}
        self.by_action["WAIT"] = []
        self.by_context_action = {}
        self.neighbor_scan_cap = 360 if getattr(profile, "label", "") == "旗舰" else (300 if getattr(profile, "label", "") == "高性能" else 240)
        self.action_counts = {key: 0 for key in self.ACTIONS}
        self.action_counts["WAIT"] = 0
        self.retry_delay = {key: 0.16 for key in self.ACTIONS}
        for key in ("H", "U", "I", "O", "L", "Z", "SPACE", "UJ", "IJ", "OJ", "LJ", "SPACEJ"):
            self.retry_delay[key] = 0.58
        self.key_gap = dict(self.BASE_KEY_GAP)
        self.key_last_at = {key: -9999.0 for key in self.PRIMITIVES}
        self.last_action_at = {key: -9999.0 for key in self.ACTIONS}
        self.last_effective_at = {key: -9999.0 for key in self.ACTIONS}
        self.pair_stats = {}
        self.triple_stats = {}
        self.context_stats = {}
        self.context_effect_stats = {}
        self.max_contexts = max(500, int(getattr(profile, "model_context_limit", 640)))
        self.effect_latency = {key: 0.0 for key in self.ACTIONS}
        self.terminal_stats = {key: {"w": 0, "l": 0} for key in self.ACTIONS}
        self.last_executed_action = None
        self.last_executed_at = -9999.0
        self.pending_pair = None
        self.pending_triple = None
        self.action_history = []
        self.total_updates = 0
        self.lifetime_updates = 0
        self.save_interval = max(90.0, float(getattr(profile, "model_save_interval", 180.0)))
        self.last_save = 0.0
        self.terminal_context_stats = {}
        self.credit_history = []
        self._load()

    @staticmethod
    def _v(value, default=0.5):
        if value is None:
            return default
        return max(0.0, min(1.0, float(value)))

    def feature(self, state):
        base = (
            self._v(state.hp), self._v(state.mp), self._v(state.boss), self._v(state.distance, 0.6),
            (state.target_side + 1.0) / 2.0,
            max(0.0, min(1.0, state.motion / 12.0)), self._v(state.novelty), self._v(state.crowd),
            max(0.0, min(1.0, state.edge_energy)),
            (max(-1.0, min(1.0, state.flow_x)) + 1.0) / 2.0,
            (max(-1.0, min(1.0, state.flow_y)) + 1.0) / 2.0,
            self._v(state.active_x), self._v(state.active_y), self._v(state.threat, 0.0),
            self._v(state.incoming, 0.0), self._v(state.dealt, 0.0), self._v(state.combo, 0.0),
            self._v(state.engaged, 0.0), self._v(state.advantage, 0.5), self._v(state.progress, 0.0),
            self._v(state.telegraph, 0.0), (max(-1.0, min(1.0, state.escape_side)) + 1.0) / 2.0,
            self._v(state.opening, 0.0), self._v(state.phase_shift, 0.0),
            (max(-1.0, min(1.0, state.risk_trend)) + 1.0) / 2.0,
            self._v(state.impact_risk, 0.0),
        )
        latent = tuple(max(0.0, min(1.0, float(x))) for x in tuple(state.latent or ())[:18])
        if len(latent) < 18:
            defaults = (0.5, 0.25, 0.0) * 6
            latent = latent + defaults[len(latent):]
        return base + latent

    @staticmethod
    def _normalize_feature(feature):
        if not feature:
            return None
        values = list(feature)
        if len(values) == 42:
            values = values[:24] + [0.5, 0.0] + values[24:]
        defaults = [
            0.5, 0.5, 0.5, 0.6, 0.5, 0.0, 0.5, 0.0, 0.0, 0.5, 0.5, 0.5,
            0.55, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.0, 0.0, 0.5, 0.0, 0.0,
            0.5, 0.0,
        ] + list((0.5, 0.25, 0.0) * 6)
        if len(values) < len(defaults):
            values.extend(defaults[len(values):])
        return tuple(float(x) for x in values[:len(defaults)])

    @staticmethod
    def _distance(a, b):
        a = CausalWorldModel._normalize_feature(a)
        b = CausalWorldModel._normalize_feature(b)
        if not a or not b:
            return 99.0
        weights = (
            1.8, 1.1, 2.0, 1.7, 1.0, 0.55, 0.42, 0.55, 0.30, 0.30,
            0.30, 0.28, 0.28, 1.70, 1.50, 1.65, 1.05, 0.85, 1.10, 0.65,
            1.62, 0.72, 1.15, 0.86, 1.30, 1.72,
        ) + (0.34, 0.20, 0.46) * 6
        return math.sqrt(sum(w * (x - y) ** 2 for w, x, y in zip(weights, a, b)) / sum(weights))

    @staticmethod
    def _raw_effect(before, after):
        def delta(a, b):
            return 0.0 if a is None or b is None else float(b) - float(a)
        hp = delta(before.hp, after.hp)
        mp = delta(before.mp, after.mp)
        boss_damage = 0.0 if before.boss is None or after.boss is None else float(before.boss) - float(after.boss)
        approach = 0.0 if before.distance is None or after.distance is None else float(before.distance) - float(after.distance)
        scene = max(0.0, min(4.0, after.scene_change)) / 4.0
        novelty = max(-1.0, min(1.0, after.novelty - before.novelty))
        motion = max(-1.0, min(1.0, (after.motion - before.motion) / 10.0))
        lateral = 0.0
        if before.player_x is not None and after.player_x is not None:
            lateral = max(-0.5, min(0.5, float(after.player_x) - float(before.player_x)))
        threat_relief = max(-1.0, min(1.0, float(before.threat) - float(after.threat)))
        combo_gain = max(-1.0, min(1.0, float(after.combo) - float(before.combo)))
        advantage_gain = max(-1.0, min(1.0, float(after.advantage) - float(before.advantage)))
        return (hp, mp, boss_damage, approach, scene, novelty, motion, lateral, threat_relief, combo_gain, advantage_gain)

    @classmethod
    def _context_key_from_feature(cls, feature):
        feature = cls._normalize_feature(feature)
        if not feature:
            feature = cls._normalize_feature([0.5] * 44)
        picks = (0, 2, 3, 4, 6, 7, 13, 20, 22, 23, 24, 25)
        parts = []
        for index in picks:
            value = max(0.0, min(0.999, float(feature[index])))
            parts.append(str(int(value * 4.0)))
        latent = feature[26:44]
        for block in range(6):
            chunk = latent[block * 3:block * 3 + 3]
            value = chunk[0] * 0.42 + chunk[1] * 0.20 + chunk[2] * 0.38
            parts.append(str(int(max(0.0, min(0.999, value)) * 4.0)))
        return "".join(parts)

    def _rebuild_index(self):
        self.by_action = {key: [] for key in self.ACTIONS}
        self.by_action["WAIT"] = []
        self.by_context_action = {}
        for item in self.memory:
            action = item.get("a")
            if action in self.by_action:
                self.by_action[action].append(item)
                feature = item.get("f")
                context = str(item.get("c") or self._context_key_from_feature(feature))[:8]
                item["c"] = context
                self.by_context_action.setdefault((context, action), []).append(item)

    @staticmethod
    def _bounded_candidates(items, cap=1200):
        items = list(items or ())
        if len(items) <= cap:
            return items
        newest = items[-min(360, cap // 3):]
        older = items[:-len(newest)]
        need = max(0, cap - len(newest))
        if not older or need <= 0:
            return newest
        step = max(1, len(older) // need)
        sampled = older[::step][:need]
        return sampled + newest

    def _nearest(self, action, feature, limit=18):
        context = self._context_key_from_feature(feature)[:8]
        local = self.by_context_action.get((context, action), ())
        if len(local) >= max(5, limit // 2):
            candidates = self._bounded_candidates(local, self.neighbor_scan_cap)
        else:
            global_items = self._bounded_candidates(self.by_action.get(action, ()), self.neighbor_scan_cap)
            if local:
                seen = {id(item) for item in local}
                candidates = list(local) + [item for item in global_items if id(item) not in seen]
            else:
                candidates = global_items
        rows = []
        for item in candidates:
            f = item.get("f")
            if not f:
                continue
            rows.append((self._distance(feature, f), item))
        return heapq.nsmallest(limit, rows, key=lambda pair: pair[0])

    def _effect_context_key(self, state):
        return self._context_key(state)[:12]

    def _context_effect_predict(self, action, state):
        bucket = self.context_effect_stats.get(self._effect_context_key(state)) or {}
        row = bucket.get(action) or {}
        n = max(0, int(row.get("n", 0)))
        effect = list(row.get("e") or ())
        if n <= 0 or len(effect) < self.EFFECT_DIM:
            return None, 1.0, 0
        effect = tuple(float(x) for x in effect[:self.EFFECT_DIM])
        err = max(0.0, min(2.0, float(row.get("err", 0.0))))
        uncertainty = min(0.92, 0.50 / math.sqrt(n + 0.35) + err * 0.34)
        return effect, uncertainty, n

    def predict(self, action, state, causal=True):
        direct, direct_uncertainty, direct_n = self._context_effect_predict(action, state)
        if direct_n >= 2:
            result = direct
            if causal and action != "WAIT":
                baseline, _, baseline_n = self._context_effect_predict("WAIT", state)
                if baseline_n >= 2:
                    result = tuple(result[i] - baseline[i] for i in range(self.EFFECT_DIM))
            return result, direct_uncertainty, direct_n
        feature = self.feature(state)
        rows = self._nearest(action, feature)
        if not rows:
            if direct_n:
                return direct, direct_uncertainty, direct_n
            return (0.0,) * self.EFFECT_DIM, 1.0, 0
        accum = [0.0] * self.EFFECT_DIM
        total = 0.0
        distances = []
        for distance, item in rows:
            weight = 1.0 / (0.035 + distance * distance)
            effect = list(item.get("e") or ())
            if len(effect) < self.EFFECT_DIM:
                effect.extend([0.0] * (self.EFFECT_DIM - len(effect)))
            for i in range(self.EFFECT_DIM):
                accum[i] += float(effect[i]) * weight
            total += weight
            distances.append(distance)
        result = tuple(value / max(total, 1e-9) for value in accum)
        if direct_n:
            blend = min(0.45, direct_n / 5.0)
            result = tuple(result[i] * (1.0 - blend) + direct[i] * blend for i in range(self.EFFECT_DIM))
        if causal and action != "WAIT":
            baseline, _, baseline_n = self.predict("WAIT", state, causal=False)
            if baseline_n:
                result = tuple(result[i] - baseline[i] for i in range(self.EFFECT_DIM))
        uncertainty = min(1.0, (sum(distances) / len(distances)) * 1.75 + 0.88 / math.sqrt(len(rows) + 0.5))
        if direct_n:
            uncertainty = min(uncertainty, direct_uncertainty + 0.10)
        return result, uncertainty, max(len(rows), direct_n)

    def _plan_predict(self, action, state):
        effect, uncertainty, n = self._context_effect_predict(action, state)
        if n <= 0:
            return (0.0,) * self.EFFECT_DIM, 1.0, 0
        if action != "WAIT":
            baseline, _, baseline_n = self._context_effect_predict("WAIT", state)
            if baseline_n >= 2:
                effect = tuple(effect[i] - baseline[i] for i in range(self.EFFECT_DIM))
        return effect, uncertainty, n

    @staticmethod
    def _utility(state):
        hp = 0.62 if state.hp is None else state.hp
        value = (
            hp * 2.9 + state.advantage * 0.75 + state.opening * 0.42
            - state.threat * (1.0 + max(0.0, 0.35 - hp) * 3.0)
            - state.telegraph * (0.46 + max(0.0, 0.32 - hp) * 1.6)
            - state.impact_risk * (0.72 + max(0.0, 0.42 - hp) * 2.1)
            - max(0.0, state.risk_trend) * 0.28
            - state.phase_shift * 0.08
        )
        if state.boss is not None:
            value += (1.0 - state.boss) * 5.6
        if state.distance is not None:
            ideal = 0.13 if max(state.threat, state.impact_risk) < 0.55 else 0.25
            value -= abs(min(0.52, state.distance) - ideal) * 0.36
        value += state.combo * 0.32 + state.progress * 0.12
        return value

    def _simulate(self, state, effect):
        hp, mp, boss_damage, approach, scene, novelty, motion, lateral, threat_relief, combo_gain, advantage_gain = effect
        def clamp(v):
            return max(0.0, min(1.0, v))
        relief = max(0.0, threat_relief)
        injury = max(0.0, -hp)
        return WorldState(
            hp=None if state.hp is None else clamp(state.hp + hp),
            mp=None if state.mp is None else clamp(state.mp + mp),
            boss=None if state.boss is None else clamp(state.boss - boss_damage),
            player_x=None if state.player_x is None else clamp(state.player_x + lateral),
            target_x=state.target_x,
            distance=None if state.distance is None else clamp(state.distance - approach),
            target_side=state.target_side,
            motion=max(0.0, state.motion + motion * 10.0),
            scene_change=max(0.0, scene * 4.0), novelty=clamp(state.novelty + novelty),
            flow_x=state.flow_x, flow_y=state.flow_y, crowd=state.crowd, edge_energy=state.edge_energy,
            active_x=state.active_x, active_y=state.active_y,
            threat=clamp(state.threat - threat_relief), incoming=clamp(state.incoming - relief * 0.50 + injury * 0.55), dealt=state.dealt,
            combo=clamp(state.combo + combo_gain), engaged=state.engaged,
            advantage=clamp(state.advantage + advantage_gain), progress=state.progress,
            telegraph=clamp(state.telegraph - relief * 0.65),
            escape_side=state.escape_side,
            opening=clamp(state.opening + max(0.0, advantage_gain) * 0.35 + max(0.0, combo_gain) * 0.20 - injury * 0.45),
            phase_shift=state.phase_shift,
            risk_trend=max(-1.0, min(1.0, state.risk_trend * 0.62 - relief * 0.80 + injury * 0.70)),
            impact_risk=clamp(state.impact_risk * 0.76 - relief * 0.90 + injury * 0.82),
            latent=state.latent,
            fingerprint=state.fingerprint, captured_at=state.captured_at,
        )

    def _bootstrap_prior(self, action, state):
        hp = 0.7 if state.hp is None else state.hp
        mp = 0.7 if state.mp is None else state.mp
        distance = state.distance
        near = distance is None or distance < 0.24
        mid = distance is not None and 0.12 <= distance <= 0.38
        far = distance is not None and distance > 0.30
        threat = max(state.threat, state.impact_risk * 0.92)
        rising = max(0.0, state.risk_trend)
        boss_known = state.boss is not None
        prior = 0.0
        if action == "TOWARD":
            prior += 0.30 if far else (0.10 if mid else -0.10)
            prior -= threat * 0.30 + rising * 0.12
        elif action == "RETREAT":
            prior += threat * 0.48 + state.telegraph * 0.30 + state.impact_risk * 0.36 + rising * 0.24 + max(0.0, 0.34 - hp) * 0.75
            if hp > 0.72 and threat < 0.25 and state.telegraph < 0.25:
                prior -= 0.18
        elif action == "EVADE":
            prior += state.telegraph * 0.72 + threat * 0.42 + state.incoming * 0.34 + state.impact_risk * 0.62 + rising * 0.36
            if hp < 0.28:
                prior += 0.20
            if state.opening > 0.65 and state.telegraph < 0.30 and state.impact_risk < 0.32:
                prior -= 0.18
        elif action in ("J", "JJJ", "CHASEJ"):
            prior += (0.24 if near else (0.12 if mid else -0.10)) * (1.0 - threat * 0.55)
            prior += state.opening * 0.17 - state.telegraph * 0.15 - state.impact_risk * 0.16
            if action == "JJJ":
                prior += state.combo * 0.18 - threat * 0.10
            if action == "CHASEJ":
                prior += 0.18 if mid else -0.03
        elif action in ("U", "I", "O", "L", "UJ", "IJ", "OJ", "LJ"):
            prior += 0.25 if near or mid else -0.08
            prior += state.combo * 0.13 - state.impact_risk * 0.10
            if mp < 0.13:
                prior -= 0.36
            elif mp < 0.25:
                prior -= 0.10
            if hp < 0.20 and threat > 0.45:
                prior -= 0.18
        elif action in ("SPACE", "SPACEJ"):
            prior += (0.20 if boss_known else 0.04) + threat * 0.13 + state.combo * 0.12
            if action == "SPACEJ" and not near and not mid:
                prior -= 0.12
        elif action == "H":
            prior += max(0.0, 0.52 - hp) * 1.05 + threat * 0.24 + state.impact_risk * 0.14 - (0.12 if hp > 0.80 else 0.0)
        elif action in ("K", "KJ"):
            prior += threat * 0.28 + state.impact_risk * 0.28 + rising * 0.14 + (0.12 if near else 0.02)
            if action == "KJ" and near:
                prior += 0.08
        elif action in ("A", "D") and state.target_side:
            toward = (action == "D" and state.target_side > 0) or (action == "A" and state.target_side < 0)
            prior += (0.12 if toward else -0.05) - threat * (0.16 if toward else -0.05)
        elif action == "F":
            prior += 0.14 if state.engaged < 0.30 and state.motion < 2.8 else -0.05
        elif action in ("W", "S"):
            prior += 0.065 if state.engaged < 0.35 else -0.025
        elif action == "Z":
            prior += 0.045 if state.engaged < 0.25 and state.progress < 0.25 else -0.09
        return prior

    @staticmethod
    def _transition_reward(effect, state):
        hp, _, boss_damage, approach, scene, _, _, _, threat_relief, combo_gain, advantage_gain = effect
        low_hp = 0.7 if state.hp is None else max(0.0, 0.40 - state.hp) * 2.5
        return (
            boss_damage * 7.0 + hp * (2.2 + low_hp * 2.0) + max(0.0, approach) * 0.50
            + scene * 0.24 + threat_relief * (1.2 + low_hp) + combo_gain * 0.45 + advantage_gain * 0.65
        )

    def _pair_bonus(self, action):
        if not self.last_executed_action or time.monotonic() - self.last_executed_at > 1.5:
            return 0.0
        item = self.pair_stats.get(self.last_executed_action + ">" + action)
        if not item or item.get("n", 0) <= 0:
            return 0.0
        n = item["n"]
        mean = item.get("r", 0.0) / max(n, 1)
        return max(-0.28, min(0.42, mean * min(0.55, math.log1p(n) / 5.0)))

    def _sequence_bonus(self, action):
        now = time.monotonic()
        recent = [a for a, stamp in self.action_history if now - stamp <= 2.2]
        if len(recent) < 2:
            return 0.0
        key = recent[-2] + ">" + recent[-1] + ">" + action
        item = self.triple_stats.get(key)
        if not item or item.get("n", 0) <= 0:
            return 0.0
        n = item["n"]
        mean = item.get("r", 0.0) / max(n, 1)
        return max(-0.24, min(0.50, mean * min(0.62, math.log1p(n) / 4.5)))

    def learned_sequence_candidates(self, state, available, limit=3):
        ranked = []
        for action in available:
            pair = self._pair_bonus(action)
            triple = self._sequence_bonus(action)
            ctx_mean, _, ctx_n, ctx_bad = self._context_value(action, state)
            score = pair + triple + ctx_mean * min(0.36, math.log1p(ctx_n) * 0.11) - ctx_bad * 0.42
            if score > 0.055:
                ranked.append((score, action))
        ranked.sort(reverse=True)
        return [action for _, action in ranked[:max(0, int(limit))]]

    def adaptive_effect_delay(self, action, fallback):
        learned = float(self.effect_latency.get(action, 0.0) or 0.0)
        if learned <= 0.0:
            return fallback
        return max(0.14, min(0.95, fallback * 0.35 + learned * 0.65))

    def local_sample_count(self, action, state, radius=0.24):
        feature = self.feature(state)
        count = 0
        for distance, _ in self._nearest(action, feature, limit=18):
            if distance <= radius:
                count += 1
        return count

    def context_confidence(self, state, actions=None):
        actions = tuple(actions or self.ACTIONS)
        if not actions:
            return 0.0
        samples = [min(6, self.local_sample_count(action, state)) for action in actions]
        coverage = sum(1 for n in samples if n > 0) / len(samples)
        density = sum(samples) / (len(samples) * 6.0)
        context_samples = [min(6, self.context_sample_count(action, state)) for action in actions]
        context_density = sum(context_samples) / (len(context_samples) * 6.0)
        return max(0.0, min(1.0, coverage * 0.52 + density * 0.30 + context_density * 0.18))

    def _context_key(self, state):
        return self._context_key_from_feature(self.feature(state))

    def context_sample_count(self, action, state):
        bucket = self.context_stats.get(self._context_key(state)) or {}
        row = bucket.get(action) or {}
        return max(0, int(row.get("n", 0)))

    def _context_value(self, action, state):
        bucket = self.context_stats.get(self._context_key(state)) or {}
        row = bucket.get(action) or {}
        n = max(0, int(row.get("n", 0)))
        if n <= 0:
            return 0.0, 1.0, 0, 0.0
        mean = float(row.get("mean", 0.0))
        m2 = max(0.0, float(row.get("m2", 0.0)))
        variance = m2 / max(1, n - 1)
        uncertainty = min(1.0, 0.72 / math.sqrt(n) + min(0.55, math.sqrt(variance) * 0.22))
        bad = max(0, int(row.get("bad", 0)))
        ok = max(0, min(n, int(row.get("ok", 0))))
        failure_rate = (n - ok) / max(1, n)
        bad_rate = min(1.0, bad / max(1, n) * 0.82 + failure_rate * (0.24 if n >= 3 else 0.10))
        return math.tanh(mean * 0.55), uncertainty, n, bad_rate


    def _terminal_context_value(self, action, state):
        bucket = self.terminal_context_stats.get(self._context_key(state)) or {}
        row = bucket.get(action) or {}
        wins = max(0.0, float(row.get("w", 0.0)))
        losses = max(0.0, float(row.get("l", 0.0)))
        total = wins + losses
        if total <= 0.0:
            return 0.0, 0.0
        value = (wins - losses) / (total + 3.0)
        confidence = min(1.0, total / 7.0)
        return value, confidence


    @staticmethod
    def _probe_cost(action):
        return {
            "F": 0.02, "A": 0.03, "D": 0.03, "W": 0.04, "S": 0.04,
            "TOWARD": 0.04, "RETREAT": 0.03, "K": 0.06, "EVADE": 0.06,
            "J": 0.08, "KJ": 0.10, "CHASEJ": 0.10, "JJJ": 0.12,
            "U": 0.16, "I": 0.16, "O": 0.16, "L": 0.16,
            "UJ": 0.20, "IJ": 0.20, "OJ": 0.20, "LJ": 0.20,
            "H": 0.26, "Z": 0.28, "SPACE": 0.32, "SPACEJ": 0.36,
        }.get(action, 0.12)

    def _mechanic_value(self, action, state):
        bucket = self.context_stats.get(self._context_key(state)) or {}
        row = bucket.get(action) or {}
        return (
            max(0.0, min(1.0, float(row.get("discover", 0.0)))),
            max(0.0, min(1.0, float(row.get("control", 0.0)))),
        )

    def probe_score(self, action, state):
        ctx_mean, ctx_uncertainty, ctx_n, ctx_bad = self._context_value(action, state)
        local = self.local_sample_count(action, state, radius=0.27)
        discovery, control = self._mechanic_value(action, state)
        hp = 0.7 if state.hp is None else state.hp
        safety = max(0.0, min(1.0, (hp - 0.22) / 0.58)) * max(0.0, 1.0 - max(state.threat, state.impact_risk))
        unknown = 1.0 / math.sqrt(ctx_n + local + 1.0)
        prior = self._bootstrap_prior(action, state)
        return (
            unknown * (0.56 + max(state.novelty, state.phase_shift) * 0.44) * safety
            + discovery * 0.42 + control * 0.24 + ctx_mean * 0.18 + prior * 0.14
            - ctx_bad * (0.85 + state.impact_risk * 0.55)
            - self._probe_cost(action) * (0.32 + max(0.0, 0.56 - hp) * 0.75)
            + ctx_uncertainty * safety * 0.08
        )

    def _update_context(self, action, before, after, reward, raw, effective):
        if action == "WAIT":
            return
        key = self._context_key(before)
        bucket = self.context_stats.setdefault(key, {})
        row = bucket.setdefault(action, {
            "n": 0, "mean": 0.0, "m2": 0.0, "bad": 0, "ok": 0,
            "discover": 0.0, "control": 0.0,
        })
        n0 = max(0, int(row.get("n", 0)))
        mean0 = float(row.get("mean", 0.0))
        m20 = max(0.0, float(row.get("m2", 0.0)))
        n1 = n0 + 1
        delta = reward - mean0
        mean1 = mean0 + delta / n1
        m21 = m20 + delta * (reward - mean1)
        row["n"] = n1
        row["mean"] = max(-6.0, min(6.0, mean1))
        row["m2"] = max(0.0, min(120.0, m21))
        if effective:
            row["ok"] = max(0, int(row.get("ok", 0))) + 1
        hp_loss = max(0.0, -float(raw[0]))
        danger_jump = max(0.0, float(after.threat) - float(before.threat))
        impact_jump = max(0.0, float(after.impact_risk) - float(before.impact_risk))
        crossed_critical = before.hp is not None and after.hp is not None and before.hp > 0.10 >= after.hp
        catastrophic = hp_loss >= 0.065 or danger_jump >= 0.30 or impact_jump >= 0.34 or crossed_critical
        if catastrophic:
            row["bad"] = max(0, int(row.get("bad", 0))) + 1
        discovery = max(0.0, min(1.0, raw[4] * 0.52 + max(0.0, raw[5]) * 0.18 + after.progress * 0.30))
        control = max(0.0, min(1.0,
            max(0.0, raw[2]) * 3.2 + abs(raw[3]) * 1.8 + raw[4] * 0.42
            + abs(raw[7]) * 2.2 + max(0.0, raw[8]) * 0.55 + max(0.0, raw[10]) * 0.45
        ))
        old_discover = max(0.0, min(1.0, float(row.get("discover", 0.0))))
        old_control = max(0.0, min(1.0, float(row.get("control", 0.0))))
        alpha = max(0.10, min(0.42, 1.6 / (n1 + 2.0)))
        row["discover"] = old_discover * (1.0 - alpha) + discovery * alpha
        row["control"] = old_control * (1.0 - alpha) + control * alpha
        if len(self.context_stats) > self.max_contexts:
            ranked = sorted(
                self.context_stats.items(),
                key=lambda pair: sum(max(0, int(v.get("n", 0))) for v in pair[1].values()),
            )
            for old_key, _ in ranked[:max(1, len(self.context_stats) - self.max_contexts)]:
                self.context_stats.pop(old_key, None)

    def _update_context_effect(self, action, before, raw):
        key = self._effect_context_key(before)
        bucket = self.context_effect_stats.setdefault(key, {})
        row = bucket.setdefault(action, {"n": 0, "e": [0.0] * self.EFFECT_DIM, "err": 0.0})
        n0 = max(0, int(row.get("n", 0)))
        old = list(row.get("e") or ())
        if len(old) < self.EFFECT_DIM:
            old.extend([0.0] * (self.EFFECT_DIM - len(old)))
        n1 = n0 + 1
        alpha = max(0.015, min(0.34, 1.0 / math.sqrt(n1)))
        delta_error = sum(abs(float(raw[i]) - float(old[i])) for i in range(self.EFFECT_DIM)) / self.EFFECT_DIM
        row["e"] = [float(old[i]) * (1.0 - alpha) + float(raw[i]) * alpha for i in range(self.EFFECT_DIM)]
        row["n"] = min(2000000, n1)
        row["err"] = max(0.0, min(2.0, float(row.get("err", 0.0)) * 0.94 + delta_error * 0.06))
        if len(self.context_effect_stats) > self.max_contexts * 2:
            ranked = sorted(
                self.context_effect_stats.items(),
                key=lambda pair: sum(max(0, int(v.get("n", 0))) for v in pair[1].values()),
            )
            remove = max(1, len(self.context_effect_stats) - self.max_contexts * 2)
            for old_key, _ in ranked[:remove]:
                self.context_effect_stats.pop(old_key, None)

    def _planning_subset(self, state, limit=8):
        ranked = []
        effect_bucket = self.context_effect_stats.get(self._effect_context_key(state)) or {}
        context_bucket = self.context_stats.get(self._context_key(state)) or {}
        for action in self.ACTIONS:
            prior = self._bootstrap_prior(action, state)
            effect_n = max(0, int((effect_bucket.get(action) or {}).get("n", 0)))
            context_n = max(0, int((context_bucket.get(action) or {}).get("n", 0)))
            learned = min(1.0, math.log1p(effect_n + context_n) / math.log(24.0))
            ranked.append((prior + learned * 0.095, action))
        ranked.sort(reverse=True)
        return [action for _, action in ranked[:max(4, limit)]]

    def action_score(self, action, state, depth=2):
        effect, uncertainty, n = self.predict(action, state)
        future = self._simulate(state, effect)
        gain = self._utility(future) - self._utility(state)
        hp = 0.7 if state.hp is None else state.hp
        boss_damage = max(0.0, effect[2])
        threat_relief = effect[8]
        gain += boss_damage * 5.3 + effect[0] * (4.0 if hp < 0.32 else 1.4) + threat_relief * (2.0 if hp < 0.32 else 0.75)
        gain += self._bootstrap_prior(action, state) / math.sqrt(n + 1.0)
        gain += self._pair_bonus(action)
        gain += self._sequence_bonus(action)
        ctx_mean, ctx_uncertainty, ctx_n, ctx_bad = self._context_value(action, state)
        ctx_confidence = min(1.0, ctx_n / 6.0)
        gain += ctx_mean * (0.10 + ctx_confidence * 0.48)
        discovery, control = self._mechanic_value(action, state)
        novel = max(state.novelty, state.phase_shift)
        gain += discovery * (0.08 + novel * 0.42) + control * (0.05 + novel * 0.16)

        predicted_mp_cost = max(0.0, -effect[1])
        if state.mp is not None and predicted_mp_cost > state.mp * 0.72:
            gain -= (predicted_mp_cost - state.mp * 0.72) * 2.4
        terminal = self.terminal_stats.get(action, {})
        terminal_n = terminal.get("w", 0) + terminal.get("l", 0)
        if terminal_n:
            gain += (terminal.get("w", 0) - terminal.get("l", 0)) / (terminal_n + 4.0) * 0.24
        local_terminal, local_terminal_conf = self._terminal_context_value(action, state)
        gain += local_terminal * (0.18 + local_terminal_conf * 0.46)

        safety = max(0.0, min(1.0, (hp - 0.18) / 0.55)) * max(0.0, 1.0 - max(state.threat, state.impact_risk))
        novelty_drive = max(0.0, min(1.0, novel)) * safety
        information = (uncertainty + ctx_uncertainty * 0.72) / math.sqrt(ctx_n + n + 1.0)
        exploration = (0.08 + novelty_drive * 0.50) * uncertainty / math.sqrt(n + 1.0)
        exploration += information * novelty_drive * 0.28
        if n == 0 and novelty_drive > 0.35:
            exploration += 0.10 * novelty_drive
        probe_cost = self._probe_cost(action)
        exploration -= probe_cost * novelty_drive * (0.11 + max(0.0, 0.55 - hp) * 0.24)

        risk = uncertainty * (
            0.08 + state.threat * 0.18 + state.telegraph * 0.22 + state.impact_risk * 0.32
            + max(0.0, state.risk_trend) * 0.18 + state.phase_shift * 0.08 + max(0.0, 0.35 - hp) * 1.05
        )
        risk += ctx_bad * (0.18 + state.threat * 0.36 + state.impact_risk * 0.42 + max(0.0, 0.42 - hp) * 0.78)
        if ctx_n >= 2 and ctx_bad >= 0.48 and action not in ("EVADE", "RETREAT", "K", "KJ", "H"):
            risk += 0.34 + ctx_bad * 0.55
        score = gain + exploration - risk

        if depth > 1 and n >= 3:
            next_scores = []
            next_actions = self._planning_subset(future, 9 if depth >= 3 else 7)
            for other in next_actions:
                predicted, unc2, n2 = self._plan_predict(other, future)
                if n2:
                    future2 = self._simulate(future, predicted)
                    step_value = (self._utility(future2) - self._utility(future)) - unc2 * (0.06 + future.impact_risk * 0.08)
                    next_scores.append((step_value, future2))
            if next_scores:
                next_scores.sort(key=lambda item: item[0], reverse=True)
                score += next_scores[0][0] * 0.42
                if depth >= 3:
                    third_best = None
                    for _, future2 in next_scores[:3]:
                        for third in self._planning_subset(future2, 6):
                            predicted3, unc3, n3 = self._plan_predict(third, future2)
                            if not n3:
                                continue
                            future3 = self._simulate(future2, predicted3)
                            value3 = (self._utility(future3) - self._utility(future2)) - unc3 * (0.05 + future2.impact_risk * 0.07)
                            if third_best is None or value3 > third_best:
                                third_best = value3
                    if third_best is not None:
                        score += third_best * 0.19
                        if depth >= 4:
                            fourth_best = None
                            for _, future2 in next_scores[:2]:
                                for third in self._planning_subset(future2, 5):
                                    predicted3, unc3, n3 = self._plan_predict(third, future2)
                                    if n3 < 2:
                                        continue
                                    future3 = self._simulate(future2, predicted3)
                                    for fourth in self._planning_subset(future3, 4):
                                        predicted4, unc4, n4 = self._plan_predict(fourth, future3)
                                        if not n4:
                                            continue
                                        future4 = self._simulate(future3, predicted4)
                                        value4 = (self._utility(future4) - self._utility(future3)) - unc4 * (0.045 + future3.impact_risk * 0.06)
                                        if fourth_best is None or value4 > fourth_best:
                                            fourth_best = value4
                            if fourth_best is not None:
                                score += fourth_best * 0.075
        return score, uncertainty, n

    def choose(self, state, available, depth=2):
        available = list(available)
        if not available:
            return None, 0.0
        hp = 0.7 if state.hp is None else state.hp
        critical = hp < 0.26 or state.impact_risk >= 0.68 or state.threat >= 0.82
        if critical:
            defensive = {"EVADE", "RETREAT", "K", "KJ", "H", "A", "D", "SPACE"}
            filtered = []
            for action in available:
                _, _, ctx_n, ctx_bad = self._context_value(action, state)
                if action in defensive or ctx_n < 2 or ctx_bad < 0.45:
                    filtered.append(action)
            if filtered:
                available = filtered
        scored = []
        for action in available:
            score, uncertainty, n = self.action_score(action, state, depth=depth)
            scored.append((score, -uncertainty, n, action))
        if not scored:
            return None, 0.0
        scored.sort(reverse=True)
        best = scored[0]
        total = sum(self.action_counts.get(a, 0) for a in available)
        safety = max(0.0, min(1.0, (hp - 0.20) / 0.55)) * (1.0 - max(state.threat, state.impact_risk))
        context_conf = self.context_confidence(state, available)
        contextual = max(0.0, min(1.0, max(state.novelty, state.phase_shift))) * safety
        contextual *= 0.30 + 0.70 * (1.0 - context_conf)
        maturity = min(1.0, math.log1p(max(0, self.lifetime_updates)) / math.log(250001.0))
        epsilon = max(0.0025, 0.050 / math.sqrt(total / max(len(available), 1) + 1.0))
        epsilon *= 1.0 - 0.46 * maturity * context_conf
        epsilon = min(0.15, epsilon + contextual * (0.10 - 0.035 * maturity))
        if len(scored) > 1 and random.random() < epsilon:
            pool = scored[:min(6 if contextual > 0.45 else 3, len(scored))]
            if contextual > 0.30:
                ranked = sorted(pool, key=lambda item: self.probe_score(item[3], state), reverse=True)
                best = ranked[0]
            else:
                best = random.choice(pool)
        return best[3], best[0]

    def _components(self, action):
        if action in self.PRIMITIVES:
            return (action,)
        return self.COMPONENTS.get(action, ())

    def available(self, now, skill_ready=None):
        skill_ready = skill_ready or {}
        result = []
        for action in self.ACTIONS:
            if now - self.last_action_at.get(action, -9999.0) < self.retry_delay.get(action, 0.16):
                continue
            blocked = False
            for key in self._components(action):
                if skill_ready.get(key) is False:
                    blocked = True
                    break
                if now - self.key_last_at.get(key, -9999.0) < self.key_gap.get(key, 0.10):
                    blocked = True
                    break
            if not blocked:
                result.append(action)
        return result

    def note_execution(self, action, now, components=None, state=None):
        if action in self.last_action_at:
            self.last_action_at[action] = now
        self.action_counts[action] = self.action_counts.get(action, 0) + 1
        keys = tuple(components or self._components(action))
        for key in keys:
            if key in self.key_last_at:
                self.key_last_at[key] = now
        history_recent = [(a, stamp) for a, stamp in self.action_history if now - stamp <= 8.0]
        sequence_recent = [(a, stamp) for a, stamp in history_recent if now - stamp <= 2.2]
        previous = sequence_recent[-1][0] if sequence_recent else None
        pair_key = previous + ">" + action if previous else None
        triple_key = None
        if len(sequence_recent) >= 2:
            triple_key = sequence_recent[-2][0] + ">" + sequence_recent[-1][0] + ">" + action
        self.pending_pair = (action, pair_key)
        self.pending_triple = (action, triple_key)
        self.action_history = (history_recent + [(action, now)])[-8:]
        self.last_executed_action = action
        self.last_executed_at = now
        if state is not None and action != "WAIT":
            context = self._context_key(state)
            self.credit_history = [(a, stamp, ctx) for a, stamp, ctx in self.credit_history if now - stamp <= 75.0]
            self.credit_history.append((action, now, context))
            self.credit_history = self.credit_history[-96:]

    def record(self, action, before, after, effective=None, raw_override=None, observed_latency=None):
        raw = tuple(raw_override) if raw_override is not None else self._raw_effect(before, after)
        feature = self.feature(before)
        magnitude = abs(raw[0]) * 2.0 + max(0.0, raw[2]) * 6.0 + abs(raw[3]) + raw[4] * 0.35 + abs(raw[8]) + abs(raw[10])
        priority = max(0.0, min(4.0, float(before.novelty) * 1.15 + magnitude + (0.55 if effective else 0.0)))
        context = self._context_key_from_feature(feature)[:8]
        item = {"a": action, "c": context, "f": list(feature), "e": list(raw), "q": priority}
        self.memory.append(item)
        if action in self.by_action:
            self.by_action[action].append(item)
            self.by_context_action.setdefault((context, action), []).append(item)
        self._update_context_effect(action, before, raw)
        if len(self.memory) > self.max_memory + max(160, self.max_memory // 30):
                                                                                           
            recent_start = max(0, len(self.memory) - 700)
            old = self.memory[:recent_start]
            recent = self.memory[recent_start:]
            old.sort(key=lambda item: float(item.get("q", 0.0)), reverse=True)
            self.memory = old[:max(0, self.max_memory - len(recent))] + recent
            self._rebuild_index()
        self.action_counts[action] = max(self.action_counts.get(action, 0), 1)
        self.total_updates += 1
        self.lifetime_updates += 1
        if action != "WAIT":
            if effective is None:
                effective = raw[2] > 0.003 or abs(raw[3]) > 0.012 or raw[4] > 0.10 or raw[0] > 0.01 or raw[8] > 0.04
            old = self.retry_delay.get(action, 0.16)
            stamp = after.captured_at or time.monotonic()
            if effective:
                self.last_effective_at[action] = stamp
                self.retry_delay[action] = max(0.11, old * 0.82)
                latency_value = observed_latency
                if latency_value is None:
                    latency_value = (after.captured_at or stamp) - (before.captured_at or stamp)
                latency = max(0.10, min(1.20, float(latency_value)))
                learned = self.effect_latency.get(action, 0.0)
                self.effect_latency[action] = latency if learned <= 0.0 else learned * 0.82 + latency * 0.18
            else:
                since_effective = stamp - self.last_effective_at.get(action, -9999.0)
                if 0.0 <= since_effective < max(1.0, old * 2.8):
                    self.retry_delay[action] = min(8.0, old * 1.20 + 0.04)
                else:
                    self.retry_delay[action] = max(0.11, old * 0.99)
            for key in self._components(action):
                if key in ("U", "I", "O", "L", "H", "SPACE", "Z"):
                    base = self.BASE_KEY_GAP[key]
                    old_gap = self.key_gap.get(key, base)
                    if effective:
                        self.key_gap[key] = max(base, old_gap * 0.97)
                    else:
                        self.key_gap[key] = min(9.0, old_gap * 1.045 + 0.012)
            reward = self._transition_reward(raw, before)
            self._update_context(action, before, after, reward, raw, bool(effective))
            if self.pending_pair and self.pending_pair[0] == action and self.pending_pair[1]:
                key = self.pending_pair[1]
                item = self.pair_stats.setdefault(key, {"n": 0, "r": 0.0})
                item["n"] += 1
                item["r"] += reward
                if len(self.pair_stats) > 720:
                    weakest = sorted(self.pair_stats, key=lambda k: self.pair_stats[k].get("n", 0))[:90]
                    for name in weakest:
                        self.pair_stats.pop(name, None)
            if self.pending_triple and self.pending_triple[0] == action and self.pending_triple[1]:
                key = self.pending_triple[1]
                item = self.triple_stats.setdefault(key, {"n": 0, "r": 0.0})
                item["n"] += 1
                item["r"] += reward
                if len(self.triple_stats) > 900:
                    weakest = sorted(self.triple_stats, key=lambda k: self.triple_stats[k].get("n", 0))[:120]
                    for name in weakest:
                        self.triple_stats.pop(name, None)
            self.pending_pair = None
            self.pending_triple = None
        if self.total_updates % 64 == 0:
            self.save()
        return raw

    def note_terminal(self, won):
        now = time.monotonic()
        recent = [(action, stamp) for action, stamp in self.action_history if action in self.terminal_stats and now - stamp <= 12.0]
        field = "w" if won else "l"
        for reverse_index, (action, stamp) in enumerate(reversed(recent[-8:])):
            temporal = math.exp(-max(0.0, now - stamp) / 7.0)
            weight = (0.76 ** reverse_index) * temporal
            if weight < 0.04:
                continue
            self.terminal_stats[action][field] += weight
        credited = [(a, stamp, ctx) for a, stamp, ctx in self.credit_history if now - stamp <= 60.0]
        for reverse_index, (action, stamp, context) in enumerate(reversed(credited[-40:])):
            temporal = math.exp(-max(0.0, now - stamp) / 24.0)
            weight = (0.92 ** reverse_index) * temporal
            if weight < 0.025:
                continue
            bucket = self.terminal_context_stats.setdefault(context, {})
            row = bucket.setdefault(action, {"w": 0.0, "l": 0.0})
            row[field] = min(5000.0, max(0.0, float(row.get(field, 0.0))) + weight)
        self.credit_history = []
        if len(self.terminal_context_stats) > self.max_contexts:
            ranked = sorted(
                self.terminal_context_stats.items(),
                key=lambda pair: sum(float(v.get("w", 0.0)) + float(v.get("l", 0.0)) for v in pair[1].values()),
            )
            for old_key, _ in ranked[:max(1, len(self.terminal_context_stats) - self.max_contexts)]:
                self.terminal_context_stats.pop(old_key, None)

    def needs_baseline(self):
        wait_samples = sum(1 for item in self.memory if item.get("a") == "WAIT")
        action_samples = sum(1 for item in self.memory if item.get("a") != "WAIT")
        return wait_samples < 3 or wait_samples * 18 < action_samples

    def model_confidence(self):
        action_samples = sum(min(10, self.action_counts.get(a, 0)) for a in self.ACTIONS)
        pair_samples = min(80, sum(item.get("n", 0) for item in self.pair_stats.values()))
        triple_samples = min(90, sum(item.get("n", 0) for item in self.triple_stats.values()))
        context_samples = min(180, sum(
            max(0, int(row.get("n", 0)))
            for bucket in self.context_stats.values() for row in bucket.values()
        ))
        lifetime = min(1.0, math.log1p(max(0, self.lifetime_updates)) / math.log(120001.0))
        return min(1.0,
            action_samples / (len(self.ACTIONS) * 7.0) * 0.54
            + pair_samples / 80.0 * 0.12
            + triple_samples / 90.0 * 0.08
            + context_samples / 180.0 * 0.18
            + lifetime * 0.08
        )

    def save(self, force=False):
        now = time.monotonic()
        if not force and now - self.last_save < self.save_interval:
            return
        _, free_gb = _storage_status(os.path.dirname(self.path) or ".")
        if free_gb > 0.0 and free_gb < 0.08:
            return
        data = {
            "version": 7, "memory": self.memory[-self.max_memory:], "counts": self.action_counts,
            "retry_delay": self.retry_delay, "key_gap": self.key_gap, "pair_stats": self.pair_stats,
            "triple_stats": self.triple_stats, "context_stats": self.context_stats,
            "context_effect_stats": self.context_effect_stats,
            "effect_latency": self.effect_latency, "terminal_stats": self.terminal_stats,
            "terminal_context_stats": self.terminal_context_stats,
            "lifetime_updates": self.lifetime_updates,
        }
        tmp = self.path + ".tmp"
        try:
            with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=5) as handle:
                json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, self.path)
            self.last_save = now
        except OSError:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    def _load(self):
        data = None
        loaded_from_legacy = False
        try:
            if os.path.isfile(self.path):
                with gzip.open(self.path, "rt", encoding="utf-8") as handle:
                    data = json.load(handle)
            elif self.legacy_path and os.path.isfile(self.legacy_path):
                with open(self.legacy_path, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
                loaded_from_legacy = True
            if not isinstance(data, dict) or data.get("version") not in (2, 3, 4, 5, 6, 7):
                return
            memory = data.get("memory") or []
            loaded = []
            for item in memory[-self.max_memory:]:
                if item.get("a") not in self.action_counts and item.get("a") != "WAIT":
                    continue
                f = self._normalize_feature(item.get("f"))
                e = list(item.get("e") or ())
                if len(e) < self.EFFECT_DIM:
                    e.extend([0.0] * (self.EFFECT_DIM - len(e)))
                context = str(item.get("c") or self._context_key_from_feature(f))[:8]
                loaded.append({
                    "a": item.get("a"), "c": context, "f": list(f) if f else [], "e": e[:self.EFFECT_DIM],
                    "q": max(0.0, min(4.0, float(item.get("q", 0.0)))),
                })
            self.memory = loaded
            self._rebuild_index()
            counts = data.get("counts") or {}
            for key in self.action_counts:
                if key in counts:
                    self.action_counts[key] = max(0, int(counts[key]))
            delays = data.get("retry_delay") or {}
            for key in self.retry_delay:
                if key in delays:
                    self.retry_delay[key] = max(0.11, min(8.0, float(delays[key])))
            gaps = data.get("key_gap") or {}
            for key, base in self.BASE_KEY_GAP.items():
                if key in gaps:
                    self.key_gap[key] = max(base, min(9.0, float(gaps[key])))
            pairs = data.get("pair_stats") or {}
            for key, item in pairs.items():
                if isinstance(item, dict):
                    n = max(0, int(item.get("n", 0)))
                    r = float(item.get("r", 0.0))
                    if n:
                        self.pair_stats[str(key)] = {"n": n, "r": r}
            triples = data.get("triple_stats") or {}
            for key, item in triples.items():
                if isinstance(item, dict):
                    n = max(0, int(item.get("n", 0)))
                    r = float(item.get("r", 0.0))
                    if n:
                        self.triple_stats[str(key)] = {"n": n, "r": r}
            contexts = data.get("context_stats") or {}
            if isinstance(contexts, dict):
                for context_key, bucket in list(contexts.items())[-self.max_contexts:]:
                    if not isinstance(bucket, dict):
                        continue
                    clean_bucket = {}
                    for action, row in bucket.items():
                        if action not in self.ACTIONS or not isinstance(row, dict):
                            continue
                        n = max(0, int(row.get("n", 0)))
                        if not n:
                            continue
                        clean_bucket[action] = {
                            "n": min(2000000, n),
                            "mean": max(-6.0, min(6.0, float(row.get("mean", 0.0)))),
                            "m2": max(0.0, min(120.0, float(row.get("m2", 0.0)))),
                            "bad": max(0, min(n, int(row.get("bad", 0)))),
                            "ok": max(0, min(n, int(row.get("ok", 0)))),
                            "discover": max(0.0, min(1.0, float(row.get("discover", 0.0)))),
                            "control": max(0.0, min(1.0, float(row.get("control", 0.0)))),
                        }
                    if clean_bucket:
                        self.context_stats[str(context_key)[:32]] = clean_bucket
            context_effects = data.get("context_effect_stats") or {}
            if isinstance(context_effects, dict):
                for context_key, bucket in list(context_effects.items())[-self.max_contexts * 2:]:
                    if not isinstance(bucket, dict):
                        continue
                    clean_bucket = {}
                    for action, row in bucket.items():
                        if action not in self.by_action or not isinstance(row, dict):
                            continue
                        n = max(0, int(row.get("n", 0)))
                        effect = list(row.get("e") or ())
                        if n <= 0 or len(effect) < self.EFFECT_DIM:
                            continue
                        clean_bucket[action] = {
                            "n": min(2000000, n),
                            "e": [max(-4.0, min(4.0, float(x))) for x in effect[:self.EFFECT_DIM]],
                            "err": max(0.0, min(2.0, float(row.get("err", 0.0)))),
                        }
                    if clean_bucket:
                        self.context_effect_stats[str(context_key)[:16]] = clean_bucket
            latencies = data.get("effect_latency") or {}
            for key in self.effect_latency:
                if key in latencies:
                    self.effect_latency[key] = max(0.0, min(1.2, float(latencies[key])))
            terminal = data.get("terminal_stats") or {}
            for key in self.terminal_stats:
                item = terminal.get(key)
                if isinstance(item, dict):
                    self.terminal_stats[key] = {"w": max(0.0, float(item.get("w", 0.0))), "l": max(0.0, float(item.get("l", 0.0)))}
            terminal_contexts = data.get("terminal_context_stats") or {}
            if isinstance(terminal_contexts, dict):
                for context_key, bucket in list(terminal_contexts.items())[-self.max_contexts:]:
                    if not isinstance(bucket, dict):
                        continue
                    clean = {}
                    for action, row in bucket.items():
                        if action not in self.ACTIONS or not isinstance(row, dict):
                            continue
                        wins = max(0.0, min(5000.0, float(row.get("w", 0.0))))
                        losses = max(0.0, min(5000.0, float(row.get("l", 0.0))))
                        if wins + losses > 0.0:
                            clean[action] = {"w": wins, "l": losses}
                    if clean:
                        self.terminal_context_stats[str(context_key)[:32]] = clean
            self.lifetime_updates = max(0, int(data.get("lifetime_updates", sum(self.action_counts.values()))))
            if loaded_from_legacy:
                self.last_save = -9999.0
        except (OSError, ValueError, TypeError, json.JSONDecodeError, EOFError):
            pass


class WinIO:
    KEYEVENTF_KEYUP = 0x0002
    MOUSEEVENTF_LEFTDOWN = 0x0002
    MOUSEEVENTF_LEFTUP = 0x0004
    SW_MAXIMIZE = 3
    VK_ESCAPE = 0x1B
    WM_CLOSE = 0x0010

    def __init__(self):
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
        try:
            self.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except Exception:
            try:
                self.user32.SetProcessDPIAware()
            except Exception:
                pass
        self.user32.IsWindowVisible.argtypes = [wintypes.HWND]
        self.user32.IsWindowVisible.restype = wintypes.BOOL
        self.user32.IsWindow.argtypes = [wintypes.HWND]
        self.user32.IsWindow.restype = wintypes.BOOL
        self.user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        self.user32.GetWindowTextLengthW.restype = ctypes.c_int
        self.user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user32.GetForegroundWindow.restype = wintypes.HWND
        self.user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        self.user32.BringWindowToTop.argtypes = [wintypes.HWND]
        self.user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        self.user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
        self.user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
        self.user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
        self.user32.GetDC.restype = wintypes.HDC
        self.user32.GetDC.argtypes = [wintypes.HWND]
        self.user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        self.user32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]
        self.user32.MapVirtualKeyW.restype = wintypes.UINT
        self.user32.keybd_event.argtypes = [
            ctypes.c_ubyte,
            ctypes.c_ubyte,
            wintypes.DWORD,
            ctypes.c_size_t,
        ]
        self.user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
        self.user32.mouse_event.argtypes = [
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.DWORD,
            ctypes.c_size_t,
        ]
        self.user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user32.GetAsyncKeyState.restype = ctypes.c_short
        self.user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        self.user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        self.gdi32.CreateCompatibleDC.restype = wintypes.HDC
        self.gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
        self.gdi32.CreateDIBSection.restype = wintypes.HANDLE
        self.gdi32.CreateDIBSection.argtypes = [
            wintypes.HDC,
            ctypes.POINTER(BITMAPINFO),
            wintypes.UINT,
            ctypes.POINTER(ctypes.c_void_p),
            wintypes.HANDLE,
            wintypes.DWORD,
        ]
        self.gdi32.SelectObject.restype = wintypes.HANDLE
        self.gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HANDLE]
        self.gdi32.SetStretchBltMode.argtypes = [wintypes.HDC, ctypes.c_int]
        self.gdi32.StretchBlt.argtypes = [
            wintypes.HDC,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.HDC,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.DWORD,
        ]
        self.gdi32.DeleteObject.argtypes = [wintypes.HANDLE]
        self.gdi32.DeleteDC.argtypes = [wintypes.HDC]
        self._held = set()
        self._lock = threading.RLock()
        self._guard = None

    def bind_input_guard(self, guard):
        self._guard = guard

    def _input_allowed(self):
        try:
            return bool(self._guard is None or self._guard())
        except Exception:
            return False

    def firefox_windows(self):
        found = []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        self.user32.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]

        @callback_type
        def visit(hwnd, _):
            if not self.user32.IsWindowVisible(hwnd):
                return True
            class_name = ctypes.create_unicode_buffer(128)
            self.user32.GetClassNameW(hwnd, class_name, 128)
            if class_name.value != "MozillaWindowClass":
                return True
            title_len = self.user32.GetWindowTextLengthW(hwnd)
            title = ctypes.create_unicode_buffer(max(2, title_len + 1))
            self.user32.GetWindowTextW(hwnd, title, len(title))
            rect = RECT()
            if self.user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                width = max(0, rect.right - rect.left)
                height = max(0, rect.bottom - rect.top)
                found.append((int(hwnd), title.value, width, height))
            return True

        self.user32.EnumWindows(visit, 0)
        return found

    @staticmethod
    def _game_title_ok(title):
        text = (title or "").lower()
        return "4399" in text or "造梦" in (title or "") or "黎尤浩劫" in (title or "")

    def choose_firefox(self, previous):
        candidates = []
        for hwnd, title, width, height in self.firefox_windows():
            size_ok = width >= 900 and height >= 540 and width / max(height, 1) >= 1.25
            if not size_ok or not self._game_title_ok(title):
                continue
            is_new = hwnd not in previous
            title_changed = hwnd in previous and previous.get(hwnd) != title
            if is_new:
                candidates.append((2, width * height, hwnd))
            elif title_changed:
                candidates.append((1, width * height, hwnd))
        if not candidates:
            return 0
        candidates.sort(reverse=True)
        return candidates[0][2]

    def window_pid(self, hwnd):
        pid = wintypes.DWORD(0)
        try:
            self.user32.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
            return int(pid.value)
        except Exception:
            return 0

    def window_title(self, hwnd):
        if not self.valid_window(hwnd):
            return ""
        title_len = self.user32.GetWindowTextLengthW(hwnd)
        title = ctypes.create_unicode_buffer(max(2, title_len + 1))
        self.user32.GetWindowTextW(hwnd, title, len(title))
        return title.value

    def valid_window(self, hwnd):
        return bool(hwnd and self.user32.IsWindow(hwnd) and self.user32.IsWindowVisible(hwnd))

    def foreground(self, hwnd):
        if not self.valid_window(hwnd):
            return False
        self.user32.ShowWindow(hwnd, self.SW_MAXIMIZE)
        self.user32.BringWindowToTop(hwnd)
        self.user32.SetForegroundWindow(hwnd)
        return int(self.user32.GetForegroundWindow()) == int(hwnd)

    def is_foreground(self, hwnd):
        return int(self.user32.GetForegroundWindow()) == int(hwnd)

    def close_owned_game_window(self, hwnd, expected_pid):
        if not self.valid_window(hwnd):
            return False
        if expected_pid and self.window_pid(hwnd) != int(expected_pid):
            return False
        if not self._game_title_ok(self.window_title(hwnd)):
            return False
        self.user32.PostMessageW(hwnd, self.WM_CLOSE, 0, 0)
        return True

    def client_rect(self, hwnd):
        rect = RECT()
        if not self.user32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        point = POINT(0, 0)
        if not self.user32.ClientToScreen(hwnd, ctypes.byref(point)):
            return None
        width = rect.right - rect.left
        height = rect.bottom - rect.top
        if width < 640 or height < 360:
            return None
        return point.x, point.y, width, height

    def key_down(self, key):
        if not self._input_allowed():
            return False
        vk = self._vk(key)
        with self._lock:
            if not self._input_allowed():
                return False
            if vk in self._held:
                return True
            self.user32.keybd_event(vk, self.user32.MapVirtualKeyW(vk, 0), 0, 0)
            self._held.add(vk)
            return True

    def key_up(self, key):
        vk = self._vk(key)
        with self._lock:
            if vk in self._held:
                self.user32.keybd_event(
                    vk,
                    self.user32.MapVirtualKeyW(vk, 0),
                    self.KEYEVENTF_KEYUP,
                    0,
                )
                self._held.discard(vk)

    def tap(self, key, duration=0.03):
        if not self._input_allowed() or not self.key_down(key):
            return False
        deadline = time.monotonic() + max(0.0, duration)
        try:
            while time.monotonic() < deadline:
                if not self._input_allowed():
                    return False
                time.sleep(min(0.008, max(0.0, deadline - time.monotonic())))
            return self._input_allowed()
        finally:
            self.key_up(key)

    def release_all(self):
        with self._lock:
            keys = list(self._held)
            for vk in keys:
                self.user32.keybd_event(
                    vk,
                    self.user32.MapVirtualKeyW(vk, 0),
                    self.KEYEVENTF_KEYUP,
                    0,
                )
            self._held.clear()

    def click(self, x, y):
        if not self._input_allowed():
            return False
        with self._lock:
            if not self._input_allowed():
                return False
            self.user32.SetCursorPos(int(x), int(y))
            if not self._input_allowed():
                return False
            self.user32.mouse_event(self.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
            try:
                deadline = time.monotonic() + 0.035
                while time.monotonic() < deadline:
                    if not self._input_allowed():
                        return False
                    time.sleep(0.006)
            finally:
                self.user32.mouse_event(self.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
            return self._input_allowed()

    def escape_down(self):
        return bool(self.user32.GetAsyncKeyState(self.VK_ESCAPE) & 0x8000)

    def _vk(self, key):
        if isinstance(key, int):
            return key
        if key == "SPACE":
            return 0x20
        return ord(key.upper())


class FrameGrabber:
    def __init__(self, winio, width=SAMPLE_W, height=SAMPLE_H, base_dir=None, profile=None, stop_event=None):
        self.io = winio
        self.width = width
        self.height = height
        self.backend_name = "GDI"
        self.dxcam = None
        self.np = None
        self.dxcam_errors = 0
        if base_dir and profile is not None and profile.prefer_dxgi:
            dxcam_mod, np_mod = _ensure_dxcam(base_dir, stop_event)
            if dxcam_mod is not None and np_mod is not None:
                try:
                    self.dxcam = dxcam_mod.create(output_color="BGRA")
                    self.np = np_mod
                    self.backend_name = "DXGI/GPU"
                except Exception:
                    self.dxcam = None
                    self.np = None
        self.screen_dc = self.io.user32.GetDC(0)
        self.memory_dc = self.io.gdi32.CreateCompatibleDC(self.screen_dc)
        self.info = self._make_info(width, height)
        self.bits = ctypes.c_void_p()
        self.bitmap = self.io.gdi32.CreateDIBSection(
            self.screen_dc,
            ctypes.byref(self.info),
            0,
            ctypes.byref(self.bits),
            None,
            0,
        )
        if not self.bitmap or not self.bits.value:
            raise RuntimeError("无法读取游戏画面")
        self.old_bitmap = self.io.gdi32.SelectObject(self.memory_dc, self.bitmap)
        self.io.gdi32.SetStretchBltMode(self.memory_dc, 4)
        self.closed = False

    @staticmethod
    def _make_info(width, height):
        info = BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        info.bmiHeader.biWidth = width
        info.bmiHeader.biHeight = -height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        return info

    def capture(self, rect):
        x, y, width, height = rect
        if self.dxcam is not None and self.np is not None:
            try:
                image = self.dxcam.grab(region=(int(x), int(y), int(x + width), int(y + height)))
                if image is not None and getattr(image, "ndim", 0) == 3 and image.shape[0] > 1 and image.shape[1] > 1:
                    if image.shape[2] == 3:
                        alpha = self.np.full((image.shape[0], image.shape[1], 1), 255, dtype=image.dtype)
                        image = self.np.concatenate((image, alpha), axis=2)
                    ys = self.np.linspace(0, image.shape[0] - 1, self.height).astype(self.np.intp)
                    xs = self.np.linspace(0, image.shape[1] - 1, self.width).astype(self.np.intp)
                    small = image[ys[:, None], xs[None, :], :4]
                    self.dxcam_errors = 0
                    return small.tobytes(order="C")
                if image is not None:
                    self.dxcam_errors += 1
            except Exception:
                self.dxcam_errors += 1
            if self.dxcam_errors >= 4:
                self.dxcam = None
                self.np = None
                self.backend_name = "GDI回退"
        ok = self.io.gdi32.StretchBlt(
            self.memory_dc,
            0,
            0,
            self.width,
            self.height,
            self.screen_dc,
            x,
            y,
            width,
            height,
            0x00CC0020,
        )
        if not ok:
            return None
        return ctypes.string_at(self.bits.value, self.width * self.height * 4)

    def capture_bmp(self, rect, path, max_width=1280):
        x, y, width, height = rect
        scale = min(1.0, max_width / max(width, 1))
        out_w = max(640, int(width * scale))
        out_h = max(360, int(height * scale))
        mem = self.io.gdi32.CreateCompatibleDC(self.screen_dc)
        info = self._make_info(out_w, out_h)
        bits = ctypes.c_void_p()
        bitmap = self.io.gdi32.CreateDIBSection(
            self.screen_dc,
            ctypes.byref(info),
            0,
            ctypes.byref(bits),
            None,
            0,
        )
        if not mem or not bitmap or not bits.value:
            if bitmap:
                self.io.gdi32.DeleteObject(bitmap)
            if mem:
                self.io.gdi32.DeleteDC(mem)
            return None
        old = self.io.gdi32.SelectObject(mem, bitmap)
        try:
            self.io.gdi32.SetStretchBltMode(mem, 4)
            ok = self.io.gdi32.StretchBlt(
                mem,
                0,
                0,
                out_w,
                out_h,
                self.screen_dc,
                x,
                y,
                width,
                height,
                0x00CC0020,
            )
            if not ok:
                return None
            raw = ctypes.string_at(bits.value, out_w * out_h * 4)
            file_size = 14 + 40 + len(raw)
            file_header = struct.pack("<2sIHHI", b"BM", file_size, 0, 0, 54)
            dib_header = struct.pack(
                "<IiiHHIIiiII",
                40,
                out_w,
                -out_h,
                1,
                32,
                0,
                len(raw),
                0,
                0,
                0,
                0,
            )
            try:
                with open(path, "wb") as handle:
                    handle.write(file_header)
                    handle.write(dib_header)
                    handle.write(raw)
            except OSError:
                return None
            return out_w, out_h
        finally:
            if old:
                self.io.gdi32.SelectObject(mem, old)
            self.io.gdi32.DeleteObject(bitmap)
            self.io.gdi32.DeleteDC(mem)

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.dxcam is not None:
            try:
                self.dxcam.stop()
            except Exception:
                pass
        self.dxcam = None
        self.np = None
        if self.old_bitmap:
            self.io.gdi32.SelectObject(self.memory_dc, self.old_bitmap)
        if self.bitmap:
            self.io.gdi32.DeleteObject(self.bitmap)
        if self.memory_dc:
            self.io.gdi32.DeleteDC(self.memory_dc)
        if self.screen_dc:
            self.io.user32.ReleaseDC(0, self.screen_dc)


class WindowsOCR:
    CHECK_SCRIPT = r'''
$ErrorActionPreference = 'Stop'
$OutputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$engine = $null
try {
    $zh = New-Object Windows.Globalization.Language -ArgumentList 'zh-CN'
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($zh)
} catch { $engine = $null }
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
}
if ($null -eq $engine) { throw 'Windows OCR unavailable' }
Write-Output $engine.RecognizerLanguage.LanguageTag
'''

    SCRIPT = r'''
$ErrorActionPreference = 'Stop'
$OutputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType=WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 })[0]
function Await($op, $type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    $task.Wait()
    return $task.Result
}
$engine = $null
try {
    $zh = New-Object Windows.Globalization.Language -ArgumentList 'zh-CN'
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($zh)
} catch { $engine = $null }
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
}
if ($null -eq $engine) { throw 'Windows OCR unavailable' }
$path = $env:AI_OCR_PATH
if ([string]::IsNullOrWhiteSpace($path)) { throw 'OCR image path missing' }
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
try {
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $lines = @()
    foreach ($line in $result.Lines) {
        $words = @()
        foreach ($word in $line.Words) {
            $r = $word.BoundingRect
            $words += [pscustomobject]@{ t=$word.Text; x=$r.X; y=$r.Y; w=$r.Width; h=$r.Height }
        }
        $lines += [pscustomobject]@{ t=$line.Text; words=$words }
    }
    [pscustomobject]@{ text=$result.Text; lines=$lines } | ConvertTo-Json -Depth 6 -Compress
} finally {
    $stream.Dispose()
}
'''

    SERVER_SCRIPT = r'''
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::InputEncoding = $utf8
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType=WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 })[0]
function Await($op, $type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    $task.Wait()
    return $task.Result
}
$engine = $null
try {
    $zh = New-Object Windows.Globalization.Language -ArgumentList 'zh-CN'
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($zh)
} catch { $engine = $null }
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
}
if ($null -eq $engine) { throw 'Windows OCR unavailable' }
[Console]::Out.WriteLine(([pscustomobject]@{ready=$true; lang=$engine.RecognizerLanguage.LanguageTag} | ConvertTo-Json -Compress))
[Console]::Out.Flush()
while (($line = [Console]::In.ReadLine()) -ne $null) {
    try {
        $req = $line | ConvertFrom-Json
        $path = [string]$req.path
        if ([string]::IsNullOrWhiteSpace($path)) { throw 'OCR image path missing' }
        $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
        $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        try {
            $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
            $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
            $lines = @()
            foreach ($ocrLine in $result.Lines) {
                $words = @()
                foreach ($word in $ocrLine.Words) {
                    $r = $word.BoundingRect
                    $words += [pscustomobject]@{t=$word.Text; x=$r.X; y=$r.Y; w=$r.Width; h=$r.Height}
                }
                $lines += [pscustomobject]@{t=$ocrLine.Text; words=$words}
            }
            $response = [pscustomobject]@{ok=$true; text=$result.Text; lines=$lines}
        } finally { $stream.Dispose() }
    } catch {
        $response = [pscustomobject]@{ok=$false; error=$_.Exception.Message}
    }
    [Console]::Out.WriteLine(($response | ConvertTo-Json -Depth 6 -Compress))
    [Console]::Out.Flush()
}
'''

    def __init__(self, base_dir, stop_event, max_width=1280):
        self.base_dir = base_dir
        self.max_width = max(800, int(max_width))
        self.stop_event = stop_event
        self.cancel_event = threading.Event()
        self.disabled = False
        self.failure_count = 0
        self.counter = 0
        self.last_error = ""
        self.server = None
        self.server_lines = queue.Queue()
        self.server_stderr = []
        self.server_reader = None
        self.server_error_reader = None
        self.language = ""

    def cancel(self):
        self.cancel_event.set()
        self._stop_server()

    def _cancelled(self):
        return self.stop_event.is_set() or self.cancel_event.is_set()

    def _powershell(self, script, env_extra=None, timeout=4.5):
        if self._cancelled():
            return None
        env = os.environ.copy()
        if env_extra:
            env.update(env_extra)
        flags = 0x08000000 if os.name == "nt" else 0
        proc = subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", script],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=flags,
            env=env,
        )
        deadline = time.monotonic() + timeout
        while proc.poll() is None:
            if self._cancelled():
                proc.terminate()
                try:
                    proc.wait(0.4)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    try:
                        proc.wait(0.4)
                    except subprocess.TimeoutExpired:
                        pass
                return None
            if time.monotonic() >= deadline:
                proc.kill()
                proc.communicate()
                raise TimeoutError("Windows OCR 超时")
            self.stop_event.wait(0.05)
        stdout, stderr = proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(stderr.decode("utf-8", errors="replace")[-500:])
        return stdout.decode("utf-8", errors="replace").strip()

    @staticmethod
    def _reader_loop(stream, output_queue, error_buffer):
        try:
            while True:
                line = stream.readline()
                if not line:
                    break
                output_queue.put(line)
        except Exception as exc:
            error_buffer.append(repr(exc))

    @staticmethod
    def _stderr_loop(stream, error_buffer):
        try:
            while True:
                line = stream.readline()
                if not line:
                    break
                text = line.decode("utf-8", errors="replace").strip()
                if text:
                    error_buffer.append(text)
                    del error_buffer[:-8]
        except Exception:
            pass

    def _read_server_line(self, timeout):
        deadline = time.monotonic() + timeout
        while not self._cancelled() and time.monotonic() < deadline:
            if self.server is not None and self.server.poll() is not None and self.server_lines.empty():
                detail = " | ".join(self.server_stderr[-3:]) or f"exit={self.server.returncode}"
                raise RuntimeError(f"OCR 子进程退出：{detail}")
            try:
                raw = self.server_lines.get(timeout=0.05)
                return raw.decode("utf-8", errors="replace").strip()
            except queue.Empty:
                pass
        if self._cancelled():
            return None
        raise TimeoutError("Windows OCR 子进程响应超时")

    def _start_server(self):
        if self.server is not None and self.server.poll() is None:
            return
        self._stop_server()
        flags = 0x08000000 if os.name == "nt" else 0
        self.server_lines = queue.Queue()
        self.server_stderr = []
        self.server = subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", self.SERVER_SCRIPT],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=flags,
        )
        output_queue = self.server_lines
        error_buffer = self.server_stderr
        self.server_reader = threading.Thread(target=self._reader_loop, args=(self.server.stdout, output_queue, error_buffer), daemon=True)
        self.server_error_reader = threading.Thread(target=self._stderr_loop, args=(self.server.stderr, error_buffer), daemon=True)
        self.server_reader.start()
        self.server_error_reader.start()
        try:
            line = self._read_server_line(5.5)
            data = json.loads(line or "{}")
            language = str(data.get("lang") or "").strip()
            if not data.get("ready") or not language:
                raise RuntimeError("常驻 Windows OCR 初始化失败")
            self.language = language
        except Exception:
            self._stop_server()
            raise

    def _stop_server(self):
        proc = self.server
        self.server = None
        if proc is None:
            return
        try:
            if proc.stdin:
                proc.stdin.close()
        except Exception:
            pass
        if proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(0.45)
            except Exception:
                try:
                    proc.kill()
                    proc.wait(0.45)
                except Exception:
                    pass

    def _server_recognize(self, path, timeout=4.5):
        self._start_server()
        if self._cancelled():
            return None
        payload = (json.dumps({"path": os.path.abspath(path)}, ensure_ascii=False) + "\n").encode("utf-8")
        try:
            self.server.stdin.write(payload)
            self.server.stdin.flush()
        except Exception as exc:
            self._stop_server()
            raise RuntimeError(f"OCR 子进程写入失败：{exc}")
        line = self._read_server_line(timeout)
        if not line:
            return None
        data = json.loads(line)
        if not data.get("ok"):
            raise RuntimeError(str(data.get("error") or "Windows OCR 识别失败"))
        return data

    def self_test(self):
        try:
            self._start_server()
            self.last_error = ""
            return True
        except Exception as exc:
            self.last_error = repr(exc)
            try:
                output = self._powershell(self.CHECK_SCRIPT, timeout=4.0)
                if not output:
                    raise RuntimeError("未检测到 Windows OCR 引擎")
                self.language = output.splitlines()[-1].strip()
                return bool(self.language)
            except Exception as fallback_exc:
                self.last_error = repr(fallback_exc)
                self.disabled = True
                return False

    def _temp_path(self):
        self.counter += 1
        prefix = f".ai_ocr_{os.getpid()}_{self.counter}_"
        try:
            fd, path = tempfile.mkstemp(prefix=prefix, suffix=".bmp", dir=self.base_dir)
        except OSError:
            fd, path = tempfile.mkstemp(prefix=prefix, suffix=".bmp")
        os.close(fd)
        return path

    def recognize(self, grabber, rect):
        if self.disabled or self._cancelled():
            return None
        path = self._temp_path()
        try:
            size = grabber.capture_bmp(rect, path, max_width=self.max_width)
            if not size or self._cancelled():
                return None
            try:
                data = self._server_recognize(path, timeout=4.5)
            except Exception as server_exc:
                self._stop_server()
                output = self._powershell(self.SCRIPT, {"AI_OCR_PATH": os.path.abspath(path)}, timeout=4.5)
                if not output:
                    raise server_exc
                data = json.loads(output)
            words = []
            for line_index, line in enumerate(data.get("lines") or []):
                for item in line.get("words") or []:
                    text = str(item.get("t") or "").strip()
                    if text:
                        words.append(
                            OCRWord(
                                text,
                                float(item.get("x") or 0),
                                float(item.get("y") or 0),
                                float(item.get("w") or 0),
                                float(item.get("h") or 0),
                                line_index,
                            )
                        )
            self.failure_count = 0
            self.last_error = ""
            return OCRSnapshot(str(data.get("text") or ""), tuple(words), size[0], size[1], time.monotonic())
        except Exception as exc:
            if not self._cancelled():
                self.failure_count += 1
                self.last_error = repr(exc)
                if self.failure_count >= 3:
                    self.disabled = True
            return None
        finally:
            try:
                os.remove(path)
            except OSError:
                pass


class AsyncOCR:
    def __init__(self, winio, stop_event, base_dir, max_width=1280):
        self.io = winio
        self.stop_event = stop_event
        self.worker = WindowsOCR(base_dir, stop_event, max_width=max_width)
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.thread = None
        self.pending_rect = None
        self.busy = False
        self.latest = None
        self.generation = 0
        self.seen_generation = 0

    @property
    def disabled(self):
        return self.worker.disabled

    def self_test(self):
        return self.worker.self_test()

    def start(self):
        if self.thread is None:
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()

    def request(self, rect):
        if self.disabled or self.stop_event.is_set():
            return False
        with self.lock:
            if self.busy or self.pending_rect is not None:
                return False
            self.pending_rect = tuple(rect)
        self.wake.set()
        return True

    def take_latest(self):
        with self.lock:
            if self.generation == self.seen_generation:
                return False, None
            self.seen_generation = self.generation
            return True, self.latest

    def _run(self):
        grabber = None
        try:
            grabber = FrameGrabber(self.io)
            while not self.stop_event.is_set() and not self.worker.cancel_event.is_set():
                self.wake.wait(0.15)
                self.wake.clear()
                with self.lock:
                    rect = self.pending_rect
                    self.pending_rect = None
                    if rect is not None:
                        self.busy = True
                if rect is None:
                    continue
                snapshot = self.worker.recognize(grabber, rect)
                with self.lock:
                    self.latest = snapshot
                    self.generation += 1
                    self.busy = False
        except Exception as exc:
            self.worker.last_error = repr(exc)
            self.worker.disabled = True
        finally:
            if grabber:
                grabber.close()
            with self.lock:
                self.busy = False

    def close(self):
        self.worker.cancel()
        self.wake.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(1.0)


class Vision:
    DANGER_WORDS = ("购买", "充值", "支付", "花费", "商城", "退出", "删除", "兑换", "续费")
    GLOBAL_DANGER_WORDS = ("确认购买", "购买", "充值", "支付", "花费", "续费", "删除角色", "退出游戏")
    SAFE_FORWARD_WORDS = (
        "继续游戏", "继续", "下一步", "下一关", "领取", "收下", "完成", "提交", "接取",
        "前往", "传送", "跳过", "挑战", "进入", "开始", "免费", "装备", "穿戴", "使用",
        "确认", "确定", "关闭", "返回",
    )
    SAFE_ABORT_WORDS = ("取消", "关闭", "返回", "以后再说", "稍后", "我知道了")

    def __init__(self, width=SAMPLE_W, height=SAMPLE_H):
        self.width = width
        self.height = height
        self.hp_max_run = 0
        self.mp_max_run = 0
        self.boss_max_run = 0
        self.hp_ratio = None
        self.mp_ratio = None
        self.boss_ratio = None
        self.hp_missing = 0
        self.mp_missing = 0
        self.boss_missing = 0
        self.player_x = None
        self.enemy_x = None

    def reset_combat_calibration(self):
        self.hp_max_run = 0
        self.mp_max_run = 0
        self.boss_max_run = 0
        self.hp_ratio = None
        self.mp_ratio = None
        self.boss_ratio = None
        self.hp_missing = 0
        self.mp_missing = 0
        self.boss_missing = 0
        self.player_x = None
        self.enemy_x = None

    def metrics(self, frame, previous):
        if not frame:
            return 0.0, 0.0, 1.0, 0.0
        total = 0
        dark = 0
        vivid = 0
        motion = 0
        count = self.width * self.height
        for i in range(0, len(frame), 4):
            b = frame[i]
            g = frame[i + 1]
            r = frame[i + 2]
            value = (r * 3 + g * 6 + b) // 10
            total += value
            if value < 16:
                dark += 1
            if max(r, g, b) - min(r, g, b) > 55 and max(r, g, b) > 105:
                vivid += 1
            if previous:
                pb = previous[i]
                pg = previous[i + 1]
                pr = previous[i + 2]
                pvalue = (pr * 3 + pg * 6 + pb) // 10
                motion += abs(value - pvalue)
        return total / count, motion / count if previous else 0.0, dark / count, vivid / count

    def fingerprint(self, frame, cols=12, rows=7):
        if not frame:
            return ()
        result = []
        for gy in range(rows):
            y = min(self.height - 1, int((gy + 0.5) * self.height / rows))
            for gx in range(cols):
                x = min(self.width - 1, int((gx + 0.5) * self.width / cols))
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                result.append(((r * 3 + g * 6 + b) // 10) // 16)
        return tuple(result)

    @staticmethod
    def fingerprint_distance(a, b):
        if not a or not b or len(a) != len(b):
            return 99.0
        return sum(abs(x - y) for x, y in zip(a, b)) / len(a)

    def hud_score(self, frame):
        if not frame:
            return 0
        max_x = int(self.width * 0.48)
        max_y = int(self.height * 0.28)
        best = 0
        for y in range(3, max_y, 3):
            run = 0
            for x in range(2, max_x):
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                high = max(r, g, b)
                low = min(r, g, b)
                colored = high > 115 and high - low > 48 and (r > 120 or b > 120 or g > 120)
                if colored:
                    run += 1
                    best = max(best, run)
                else:
                    run = 0
        if best >= int(self.width * 0.16):
            return 3
        if best >= int(self.width * 0.10):
            return 2
        if best >= int(self.width * 0.06):
            return 1
        return 0

    @staticmethod
    def _red_pixel(r, g, b):
        return r >= 88 and r - g >= 28 and r - b >= 24 and r >= int(g * 1.20)

    @staticmethod
    def _blue_pixel(r, g, b):
        return b >= 82 and b - r >= 22 and b - g >= 10 and b >= int(r * 1.16)

    def _longest_color_run(self, frame, x1, y1, x2, y2, color):
        if not frame:
            return 0
        predicate = self._red_pixel if color == "red" else self._blue_pixel
        best = 0
        for y in range(max(0, y1), min(self.height, y2)):
            run = 0
            gap = 0
            for x in range(max(0, x1), min(self.width, x2)):
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                if predicate(r, g, b):
                    run += 1 + gap
                    gap = 0
                    if run > best:
                        best = run
                elif run and gap < 2:
                    gap += 1
                else:
                    run = 0
                    gap = 0
        return best

    def _bar_ratio(self, run, name, minimum=5):
        max_name = f"{name}_max_run"
        ratio_name = f"{name}_ratio"
        missing_name = f"{name}_missing"
        maximum = getattr(self, max_name)
        previous = getattr(self, ratio_name)
        missing = getattr(self, missing_name)
        if run >= minimum:
            maximum = max(maximum, run)
            raw = min(1.0, run / max(maximum, 1))
            value = raw if previous is None else previous * 0.55 + raw * 0.45
            setattr(self, max_name, maximum)
            setattr(self, ratio_name, value)
            setattr(self, missing_name, 0)
            return value
        missing += 1
        setattr(self, missing_name, missing)
        if previous is not None and missing <= 4:
            return previous
        if maximum >= minimum * 2:
            setattr(self, ratio_name, 0.0)
            return 0.0
        return None

    def _motion_peaks(self, frame, previous, bins=36):
        if not frame or not previous or len(frame) != len(previous):
            return []
        scores = [0.0] * bins
        warm = [0.0] * bins
        y1 = int(self.height * 0.25)
        y2 = int(self.height * 0.88)
        x1 = int(self.width * 0.03)
        x2 = int(self.width * 0.97)
        for y in range(y1, y2, 2):
            for x in range(x1, x2, 2):
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                pb, pg, pr = previous[i], previous[i + 1], previous[i + 2]
                diff = abs(r - pr) + abs(g - pg) + abs(b - pb)
                if diff < 42:
                    continue
                index = min(bins - 1, int(x * bins / self.width))
                saturation = max(r, g, b) - min(r, g, b)
                scores[index] += diff + saturation * 0.22
                if r > 95 and r - g > 24 and r - b > 18:
                    warm[index] += diff * 0.45
        smooth = []
        for i in range(bins):
            value = scores[i] * 2.0
            if i:
                value += scores[i - 1]
            if i + 1 < bins:
                value += scores[i + 1]
            smooth.append(value / 4.0)
        ranked = sorted(range(bins), key=lambda i: smooth[i] + warm[i] * 0.30, reverse=True)
        peaks = []
        floor = max(180.0, sum(smooth) / max(len(smooth), 1) * 1.35)
        for index in ranked:
            if smooth[index] < floor:
                break
            x = (index + 0.5) / bins
            if any(abs(x - old_x) < 0.09 for old_x, _, _ in peaks):
                continue
            peaks.append((x, smooth[index], warm[index]))
            if len(peaks) >= 5:
                break
        return peaks

    def _locate_entities(self, frame, previous):
        peaks = self._motion_peaks(frame, previous)
        if not peaks:
            return self.player_x, self.enemy_x
        if self.player_x is None:
            candidates = [item for item in peaks if item[0] <= 0.62] or peaks
            player = min(candidates, key=lambda item: abs(item[0] - 0.34) - min(item[1], 3000) / 30000.0)
        else:
            player = min(peaks, key=lambda item: abs(item[0] - self.player_x) * 3.0 - min(item[1], 5000) / 20000.0)
        px = player[0]
        self.player_x = px if self.player_x is None else self.player_x * 0.62 + px * 0.38
        others = [item for item in peaks if abs(item[0] - self.player_x) >= 0.11]
        if others:
            enemy = max(others, key=lambda item: item[1] + item[2] * 0.65 + (0.18 if item[0] > self.player_x else 0.0) * item[1])
            ex = enemy[0]
            self.enemy_x = ex if self.enemy_x is None else self.enemy_x * 0.58 + ex * 0.42
        elif self.enemy_x is not None:
            self.enemy_x = self.enemy_x
        return self.player_x, self.enemy_x

    def combat_fingerprint(self, frame, cols=10, rows=5):
        if not frame:
            return ()
        result = []
        x1, x2 = int(self.width * 0.05), int(self.width * 0.95)
        y1, y2 = int(self.height * 0.26), int(self.height * 0.88)
        for gy in range(rows):
            y = min(y2 - 1, y1 + int((gy + 0.5) * (y2 - y1) / rows))
            for gx in range(cols):
                x = min(x2 - 1, x1 + int((gx + 0.5) * (x2 - x1) / cols))
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                result.append(((r * 3 + g * 6 + b) // 10) // 16)
        return tuple(result)

    def combat_observation(self, frame, previous, motion=0.0):
        hp_run = self._longest_color_run(frame, 2, 3, int(self.width * 0.52), int(self.height * 0.31), "red")
        mp_run = self._longest_color_run(frame, 2, 3, int(self.width * 0.52), int(self.height * 0.34), "blue")
        boss_run = self._longest_color_run(frame, int(self.width * 0.38), 2, int(self.width * 0.98), int(self.height * 0.24), "red")
        hp = self._bar_ratio(hp_run, "hp", 5)
        mp = self._bar_ratio(mp_run, "mp", 5)
        boss = self._bar_ratio(boss_run, "boss", 18)
        player_x, enemy_x = self._locate_entities(frame, previous)
        return CombatObservation(hp, mp, boss, player_x, enemy_x, motion)

    @staticmethod
    def _compact(text):
        return re.sub(r"\s+", "", text or "")

    def semantic_state(self, snapshot):
        if not snapshot:
            return GameState.UNKNOWN, 0.0
        text = self._compact(snapshot.text)
        if not text:
            return GameState.UNKNOWN, 0.0
        if any(word in text for word in ("确认购买", "充值中心", "支付", "退出游戏", "删除角色")):
            return GameState.UNKNOWN, 0.98
        retry_score = sum(word in text for word in ("挑战失败", "重试", "再次挑战", "重新挑战", "战斗失败"))
        reward_score = sum(word in text for word in ("通关", "胜利", "奖励", "战利品", "领取", "获得"))
        equip_score = sum(word in text for word in ("背包", "穿戴", "更换装备", "装备属性", "一键装备", "一键穿戴"))
        upgrade_score = sum(word in text for word in ("强化", "升级", "锻造", "强化等级", "成功率"))
        stage_score = sum(word in text for word in ("推荐战力", "挑战", "关卡", "副本", "进入关卡"))
        home_score = sum(word in text for word in ("主城", "冒险", "开始游戏", "任务", "角色"))
        if retry_score >= 1:
            return GameState.RETRY, 0.95
        if reward_score >= 2 or ("领取" in text and "奖励" in text):
            return GameState.REWARD, 0.94
        if equip_score >= 2 or ("背包" in text and "装备" in text):
            return GameState.EQUIPMENT, 0.91
        if upgrade_score >= 2 or ("强化" in text and ("等级" in text or "成功率" in text)):
            return GameState.UPGRADE, 0.91
        if stage_score >= 2 and ("挑战" in text or "进入" in text):
            return GameState.SELECT_STAGE, 0.90
        if home_score >= 2 or "主城" in text:
            return GameState.HOME, 0.86
        return GameState.UNKNOWN, 0.0

    def classify(self, frame, previous, snapshot, combat_hint=False):
        brightness, motion, darkness, _ = self.metrics(frame, previous)
        if brightness < 9 or darkness > 0.965:
            return GameState.LOADING, 0.99, motion
        hud = self.hud_score(frame)
        if hud >= 2 and motion >= 1.25:
            return GameState.COMBAT, min(0.96, 0.72 + hud * 0.07 + min(motion, 8.0) * 0.015), motion
        semantic = GameState.UNKNOWN
        confidence = 0.0
        if snapshot and time.monotonic() - snapshot.captured_at <= 4.0:
            semantic, confidence = self.semantic_state(snapshot)
        if hud >= 2 and combat_hint and semantic not in (GameState.REWARD, GameState.RETRY):
            return GameState.COMBAT, 0.76, motion
        if combat_hint and semantic == GameState.UNKNOWN and motion >= 0.72 and brightness >= 15 and darkness < 0.90:
                                                                                            
                                                                                             
            return GameState.COMBAT, min(0.82, 0.72 + min(motion, 7.0) * 0.014), motion
        if semantic != GameState.UNKNOWN:
            return semantic, confidence, motion
        return GameState.UNKNOWN, 0.25 if hud else 0.0, motion

    def has_danger(self, snapshot):
        if not snapshot:
            return False
        text = self._compact(snapshot.text)
        return any(word in text for word in self.GLOBAL_DANGER_WORDS)

    def _line_candidates(self, snapshot):
        candidates = list(snapshot.words)
        by_line = {}
        for word in snapshot.words:
            by_line.setdefault(word.line, []).append(word)
        for line_id, words in by_line.items():
            if line_id < 0 or len(words) < 2:
                continue
            words = sorted(words, key=lambda item: item.x)
            for start in range(len(words)):
                left = words[start]
                text = self._compact(left.text)
                x1, y1 = left.x, left.y
                x2, y2 = left.x + left.w, left.y + left.h
                previous = left
                for stop in range(start + 1, min(len(words), start + 4)):
                    item = words[stop]
                    gap = item.x - (previous.x + previous.w)
                    if gap > max(46.0, max(previous.h, item.h) * 2.2):
                        break
                    if abs(item.cy - previous.cy) > max(previous.h, item.h) * 0.9:
                        break
                    text += self._compact(item.text)
                    x1, y1 = min(x1, item.x), min(y1, item.y)
                    x2, y2 = max(x2, item.x + item.w), max(y2, item.y + item.h)
                    candidates.append(OCRWord(text, x1, y1, x2 - x1, y2 - y1, line_id))
                    previous = item
        return candidates

    def generic_safe_action_word(self, snapshot):
        if not snapshot:
            return None
        danger = self.has_danger(snapshot)
        priorities = self.SAFE_ABORT_WORDS if danger else self.SAFE_FORWARD_WORDS
        candidates = self._line_candidates(snapshot)
        for wanted in priorities:
            matches = []
            for word in candidates:
                text = self._compact(word.text)
                if wanted not in text:
                    continue
                nx = word.cx / max(snapshot.width, 1)
                ny = word.cy / max(snapshot.height, 1)
                if not (0.02 <= nx <= 0.98 and 0.04 <= ny <= 0.98):
                    continue
                if not danger and self._danger_near(snapshot, word, GameState.UNKNOWN):
                    continue
                                                                                    
                penalty = max(0, len(text) - len(wanted)) * 0.03
                center_bias = abs(nx - 0.5) * 0.08 + abs(ny - 0.62) * 0.04
                matches.append((penalty + center_bias, word))
            if matches:
                matches.sort(key=lambda item: item[0])
                return matches[0][1]
        return None

    def safe_growth_action_word(self, snapshot):
        if not snapshot or self.has_danger(snapshot):
            return None
        growth_terms = ("强化", "升级", "升星", "进阶", "培养", "镶嵌", "洗炼", "穿戴", "装备", "法宝", "坐骑")
        candidates = self._line_candidates(snapshot)
        matches = []
        for word in candidates:
            text = self._compact(word.text)
            if "免费" not in text or not any(term in text for term in growth_terms):
                continue
            if self._danger_near(snapshot, word, GameState.UNKNOWN):
                continue
            nx = word.cx / max(snapshot.width, 1)
            ny = word.cy / max(snapshot.height, 1)
            if 0.02 <= nx <= 0.98 and 0.04 <= ny <= 0.98:
                matches.append((len(text), abs(nx - 0.5) + abs(ny - 0.62) * 0.4, word))
        if not matches:
            return None
        matches.sort(key=lambda item: (item[0], item[1]))
        return matches[0][2]

    def action_word(self, snapshot, state, priorities):
        if not snapshot or self.has_danger(snapshot):
            return None
        if state not in (
            GameState.HOME, GameState.SELECT_STAGE, GameState.REWARD,
            GameState.EQUIPMENT, GameState.UPGRADE, GameState.RETRY,
        ):
            return None
        candidates = self._line_candidates(snapshot)
        for wanted in priorities:
            for word in candidates:
                text = self._compact(word.text)
                if wanted not in text:
                    continue
                nx = word.cx / max(snapshot.width, 1)
                ny = word.cy / max(snapshot.height, 1)
                if not (0.02 <= nx <= 0.98 and 0.04 <= ny <= 0.98):
                    continue
                if state == GameState.UPGRADE and "免费" not in text:
                    continue
                if self._danger_near(snapshot, word, state):
                    continue
                return word
        return None

    def _danger_near(self, snapshot, target, state):
        if state == GameState.UPGRADE and "免费" in self._compact(target.text):
            strong = ("购买", "充值", "支付", "花费", "商城", "退出", "删除", "兑换")
        else:
            strong = self.DANGER_WORDS
        radius = max(120.0, snapshot.width * 0.14)
        for word in snapshot.words:
            text = self._compact(word.text)
            if not any(danger in text for danger in strong):
                continue
            if abs(word.cx - target.cx) <= radius and abs(word.cy - target.cy) <= radius * 0.72:
                return True
        return False

    @staticmethod
    def _parse_power_number(number, unit):
        try:
            base = float(number.replace(",", ""))
        except (TypeError, ValueError):
            return None
        if unit == "万":
            base *= 10000
        elif unit == "亿":
            base *= 100000000
        value = int(base)
        return value if 1 <= value <= 10_000_000_000 else None

    def extract_power(self, snapshot):
        if not snapshot:
            return None
        text = self._compact(snapshot.text).replace("，", ",")
        values = []
        for number, unit in re.findall(
            r"(?:当前战力|角色战力|总战力|战斗力)[：:]?([0-9][0-9,.]{0,12})(万|亿)?",
            text,
        ):
            value = self._parse_power_number(number, unit)
            if value:
                values.append(value)
        if values:
            return max(values)

        blockers = ("推荐", "所需", "需求", "敌方", "怪物", "BOSS")
        for match in re.finditer(r"战力[：:]?([0-9][0-9,.]{0,12})(万|亿)?", text):
            prefix = text[max(0, match.start() - 6):match.start()].upper()
            if any(word.upper() in prefix for word in blockers):
                continue
            value = self._parse_power_number(match.group(1), match.group(2))
            if value:
                values.append(value)
        return max(values) if values else None


class SkillHUDTracker:
    KEYS = ("U", "I", "O", "L", "H", "SPACE", "Z")

    def __init__(self, width, height):
        self.width = int(width)
        self.height = int(height)
        self.latest = None
        self.pending = {}
        self.mapping_votes = {key: {} for key in self.KEYS}
        self.mapping = {}
        self.ready_baseline = {}
        self.mapping_confidence = {}
        self._centers = []
        for row_y in (0.76, 0.88):
            for col in range(12):
                self._centers.append((0.18 + col * 0.07, row_y))

    def _tile_features(self, frame):
        if not frame:
            return None
        features = []
        rx = max(2, int(self.width * 0.018))
        ry = max(2, int(self.height * 0.030))
        for nx, ny in self._centers:
            cx = max(rx, min(self.width - rx - 1, int(nx * self.width)))
            cy = max(ry, min(self.height - ry - 1, int(ny * self.height)))
            lum = sat = count = 0.0
            step_x = max(1, rx // 2)
            step_y = max(1, ry // 2)
            for y in range(cy - ry, cy + ry + 1, step_y):
                for x in range(cx - rx, cx + rx + 1, step_x):
                    i = (y * self.width + x) * 4
                    b, g, r = frame[i], frame[i + 1], frame[i + 2]
                    hi, lo = max(r, g, b), min(r, g, b)
                    lum += (r * 0.30 + g * 0.59 + b * 0.11) / 255.0
                    sat += (hi - lo) / max(hi, 32)
                    count += 1.0
            features.append((lum / max(count, 1.0), sat / max(count, 1.0)))
        return tuple(features)

    @staticmethod
    def _score(feature):
        return feature[0] * 0.58 + feature[1] * 0.42

    def observe(self, frame, now):
        current = self._tile_features(frame)
        if current is None:
            return
        self.latest = current
        for key, pending in list(self.pending.items()):
            age = now - pending["at"]
            if age < 0.10:
                continue
            if age <= 0.62 and not pending.get("voted"):
                before = pending["before"]
                ranked = []
                for index, (old, new) in enumerate(zip(before, current)):
                    old_score = self._score(old)
                    new_score = self._score(new)
                    drop = old_score - new_score
                    feature_shift = abs(old[0] - new[0]) * 0.55 + abs(old[1] - new[1]) * 0.45
                    ranked.append((drop * 0.72 + feature_shift * 0.28, index, old_score))
                ranked.sort(reverse=True)
                best = ranked[0]
                second = ranked[1][0] if len(ranked) > 1 else 0.0
                if best[0] >= 0.075 and best[0] >= second * 1.15:
                    pending["voted"] = True
                    votes = self.mapping_votes[key]
                    row = votes.setdefault(best[1], [0.0, 0])
                    row[0] += best[0]
                    row[1] += 1
                    candidates = sorted(((v[0], v[1], idx) for idx, v in votes.items()), reverse=True)
                    top = candidates[0]
                    runner = candidates[1][0] if len(candidates) > 1 else 0.0
                    if top[1] >= 2 and top[0] >= max(0.18, runner * 1.22):
                        self.mapping[key] = top[2]
                        self.mapping_confidence[key] = min(1.0, top[0] / 0.42)
                        baseline = pending["before"][top[2]]
                        score = self._score(baseline)
                        old_base = self.ready_baseline.get(key)
                        self.ready_baseline[key] = score if old_base is None else old_base * 0.72 + score * 0.28
            if age > 0.62:
                self.pending.pop(key, None)

    def note_action(self, key, now):
        if key not in self.KEYS or self.latest is None:
            return
        mapped = self.mapping.get(key)
        if mapped is not None:
            score = self._score(self.latest[mapped])
            old = self.ready_baseline.get(key)
            self.ready_baseline[key] = score if old is None else old * 0.82 + score * 0.18
        self.pending[key] = {"at": now, "before": self.latest, "voted": False}

    def readiness(self):
        result = {}
        if self.latest is None:
            return result
        for key in self.KEYS:
            index = self.mapping.get(key)
            baseline = self.ready_baseline.get(key)
            confidence = self.mapping_confidence.get(key, 0.0)
            if index is None or baseline is None or baseline < 0.12 or confidence < 0.45:
                continue
            current = self._score(self.latest[index])
            ratio = current / max(baseline, 1e-6)
            if ratio <= 0.79:
                result[key] = False
            elif ratio >= 0.90:
                result[key] = True
        return result


class StateDetector:
    def __init__(self):
        self.stable = GameState.UNKNOWN
        self.candidate = GameState.UNKNOWN
        self.count = 0
        self.confidence = 0.0

    def update(self, state, confidence):
        if state == GameState.LOADING:
            self.stable = state
            self.candidate = state
            self.count = 1
            self.confidence = confidence
            return self.stable
        needed = 2 if state == GameState.COMBAT else 3
        if confidence < (0.70 if state == GameState.COMBAT else 0.82):
            state = GameState.UNKNOWN
            needed = 3
        if state == self.candidate:
            self.count += 1
        else:
            self.candidate = state
            self.count = 1
        self.confidence = confidence
        if self.count >= needed:
            self.stable = state
        return self.stable


class VisualStateMemory:
    def __init__(self, vision):
        self.vision = vision
        self.prototypes = {state: [] for state in GameState}
        self.max_per_state = 18

    def observe(self, state, confidence, fingerprint):
        if state in (GameState.UNKNOWN, GameState.LOADING) or confidence < 0.82 or not fingerprint:
            return
        bucket = self.prototypes[state]
        if bucket and min(self.vision.fingerprint_distance(fingerprint, old) for old in bucket) < 0.42:
            return
        bucket.append(tuple(fingerprint))
        if len(bucket) > self.max_per_state:
            bucket.pop(0)

    def infer(self, fingerprint):
        candidates = []
        for state, bucket in self.prototypes.items():
            if state in (GameState.UNKNOWN, GameState.LOADING, GameState.COMBAT) or not bucket:
                continue
            distance = min(self.vision.fingerprint_distance(fingerprint, old) for old in bucket)
            candidates.append((distance, state))
        if not candidates:
            return GameState.UNKNOWN, 0.0
        candidates.sort(key=lambda item: item[0])
        best_distance, best_state = candidates[0]
        second = candidates[1][0] if len(candidates) > 1 else 99.0
        if best_distance > 0.78 or second - best_distance < 0.10:
            return GameState.UNKNOWN, 0.0
        confidence = max(0.82, min(0.93, 0.94 - best_distance * 0.14))
        return best_state, confidence


class PowerTracker:
    GROWTH_KINDS = ("equip", "free_upgrade", "safe_growth")

    def __init__(self, path=None):
        self.path = path
        self.current_power = 0
        self.best_power = 0
        self.actual_power_gains = 0
        self.action_completed = 0
        self.confirmed_power_gain_actions = 0
        self.pending = None
        self.stage_stats = {}
        self.action_stats = {kind: ActionStats() for kind in self.GROWTH_KINDS}
        self.selected_stage = None
        self.current_stage = None
        self.combat_started = 0.0
        self.power_candidate = 0
        self.power_candidate_hits = 0
        self.last_save = 0.0
        self._load()

    def observe_power(self, value):
        if not value:
            return False
        value = int(value)
        if self.power_candidate:
            tolerance = max(5, int(self.power_candidate * 0.003))
            if abs(value - self.power_candidate) <= tolerance:
                self.power_candidate_hits += 1
                weight = min(self.power_candidate_hits, 4)
                self.power_candidate = int(round((self.power_candidate * (weight - 1) + value) / weight))
            else:
                self.power_candidate = value
                self.power_candidate_hits = 1
        else:
            self.power_candidate = value
            self.power_candidate_hits = 1
        required = 2
        if self.current_power and abs(self.power_candidate - self.current_power) > max(5000, int(self.current_power * 0.50)):
            required = 3
        if self.power_candidate_hits < required:
            return False
        stable_value = self.power_candidate
        increased = bool(self.current_power and stable_value > self.current_power)
        if increased:
            self.actual_power_gains += 1
        self.current_power = stable_value
        self.best_power = max(self.best_power, stable_value)
        return increased

    def start_action(self, kind, state, fingerprint):
        self.pending = PendingAction(kind, state, fingerprint, time.monotonic(), self.current_power)
        if kind in self.action_stats:
            self.action_stats[kind].attempts += 1

    def _finish_growth_action(self, pending, success):
        stats = self.action_stats.get(pending.kind)
        if stats is not None:
            stats.total_seconds += max(0.1, time.monotonic() - pending.at)
            if success:
                stats.successes += 1
                stats.total_power_delta += max(0, self.current_power - pending.power_before)
            else:
                stats.failures += 1
        self.pending = None
        self.save()

    def resolve_action(self, state, fingerprint, vision):
        pending = self.pending
        if not pending:
            return
        now = time.monotonic()
        if now - pending.at < 0.65:
            return
        state_changed = state != pending.state and state != GameState.UNKNOWN
        scene_changed = vision.fingerprint_distance(fingerprint, pending.fingerprint) >= 1.8
        power_increased = self.current_power > pending.power_before > 0

        if pending.kind in self.action_stats:
            if not pending.completed and (scene_changed or state_changed):
                pending.completed = True
                self.action_completed += 1
            if power_increased:
                if not pending.completed:
                    self.action_completed += 1
                self.confirmed_power_gain_actions += 1
                self._finish_growth_action(pending, True)
                return
            if now - pending.at > 8.0:
                self._finish_growth_action(pending, False)
            return

        completed = False
        if pending.kind == "reward":
            completed = state_changed and state != GameState.REWARD
        elif pending.kind in ("home", "stage_select", "stage_enter", "retry", "open_equipment", "open_upgrade"):
            completed = state_changed or scene_changed
        if completed:
            self.action_completed += 1
            self.pending = None
        elif now - pending.at > 6.5:
            self.pending = None

    def growth_action_order(self):
        def score(kind):
            stats = self.action_stats[kind]
            if stats.attempts == 0:
                return 1_000_000.0
            expected_delta = (stats.total_power_delta + max(120.0, self.best_power * 0.0008)) / (stats.successes + 1.0)
            expected_seconds = max(0.8, stats.average_seconds)
            failure_risk = (stats.failures + 0.5) / (stats.attempts + 2.0)
            exploration = 80.0 / math.sqrt(stats.attempts + 1.0)
            return expected_delta / expected_seconds * (1.0 - min(0.90, failure_risk)) + exploration
        return sorted(self.GROWTH_KINDS, key=score, reverse=True)

    def select_stage(self, stage_id):
        self.selected_stage = stage_id

    def entered_combat(self):
        self.current_stage = self.selected_stage
        self.selected_stage = None
        self.combat_started = time.monotonic()

    def combat_result(self, won):
        if not self.combat_started:
            return
        stage = self.current_stage or "current"
        stats = self.stage_stats.setdefault(stage, StageStats())
        stats.attempts += 1
        if won:
            stats.wins += 1
            stats.total_seconds += max(0.1, time.monotonic() - self.combat_started)
        self.combat_started = 0.0
        self.save()

    def record_stuck(self):
        stage = self.current_stage or "current"
        self.stage_stats.setdefault(stage, StageStats()).stuck_events += 1
        self.save()

    def choose_stage(self, options):
        if not options:
            return None
        scored = []
        for numeric_value, required_power, word, stage_id in options:
            score = float(numeric_value)
            if required_power and self.current_power:
                ratio = self.current_power / max(required_power, 1)
                if ratio < 0.72:
                    score -= 150000.0 + (0.72 - ratio) * 60000.0
                elif ratio < 0.95:
                    score -= (0.95 - ratio) * 4500.0
                else:
                    score += min(1.5, ratio) * 220.0
            stats = self.stage_stats.get(stage_id)
            if stats and stats.attempts >= 2:
                reliability = stats.success_rate
                stuck_rate = stats.stuck_events / max(stats.attempts, 1)
                score += reliability * 1250.0 - stats.average_seconds * 0.12 - stuck_rate * 180.0
                if reliability < 0.55:
                    score -= 90000.0
            scored.append((score, word, stage_id))
        scored.sort(key=lambda item: item[0], reverse=True)
        return scored[0][1], scored[0][2]


    def save(self):
        if not self.path:
            return
        now = time.monotonic()
        if now - self.last_save < 1.0:
            return
        data = {
            "version": 1,
            "best_power": self.best_power,
            "stage_stats": {
                str(key): {
                    "attempts": value.attempts, "wins": value.wins,
                    "total_seconds": value.total_seconds, "stuck_events": value.stuck_events,
                }
                for key, value in self.stage_stats.items()
            },
            "action_stats": {
                key: {
                    "attempts": value.attempts, "successes": value.successes,
                    "failures": value.failures, "total_power_delta": value.total_power_delta,
                    "total_seconds": value.total_seconds,
                }
                for key, value in self.action_stats.items()
            },
        }
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, self.path)
            self.last_save = now
        except OSError:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    def _load(self):
        if not self.path:
            return
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            if data.get("version") != 1:
                return
            self.best_power = max(0, int(data.get("best_power", 0)))
            for key, raw in (data.get("stage_stats") or {}).items():
                if not isinstance(raw, dict):
                    continue
                self.stage_stats[str(key)] = StageStats(
                    attempts=max(0, int(raw.get("attempts", 0))),
                    wins=max(0, int(raw.get("wins", 0))),
                    total_seconds=max(0.0, float(raw.get("total_seconds", 0.0))),
                    stuck_events=max(0, int(raw.get("stuck_events", 0))),
                )
            for key, raw in (data.get("action_stats") or {}).items():
                if key not in self.action_stats or not isinstance(raw, dict):
                    continue
                self.action_stats[key] = ActionStats(
                    attempts=max(0, int(raw.get("attempts", 0))),
                    successes=max(0, int(raw.get("successes", 0))),
                    failures=max(0, int(raw.get("failures", 0))),
                    total_power_delta=max(0, int(raw.get("total_power_delta", 0))),
                    total_seconds=max(0.0, float(raw.get("total_seconds", 0.0))),
                )
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            pass


class AdaptiveAgent:
    def __init__(self, winio, hwnd, stop_event, send_status, base_dir, power_tracker, profile):
        self.io = winio
        self.hwnd = hwnd
        self.stop_event = stop_event
        self.send_status = send_status
        self.profile = profile
        self.governor = RuntimeGovernor(profile)
        self.vision = Vision(profile.sample_w, profile.sample_h)
        self.detector = StateDetector()
        self.state_memory = VisualStateMemory(self.vision)
        self.power = power_tracker
        self.grabber = FrameGrabber(winio, profile.sample_w, profile.sample_h, base_dir, profile, stop_event)
        self.ocr = AsyncOCR(winio, stop_event, base_dir, max_width=profile.ocr_max_width)
        self.ocr_available = False
        self.ocr_degraded_reported = False
        self.skill_hud = SkillHUDTracker(profile.sample_w, profile.sample_h)
        self.previous = None
        self.snapshot = None
        self.last_ocr_request = 0.0
        self.last_status = 0.0
        self.last_action = 0.0
        self.state_since = time.monotonic()
        self.last_effective_change = self.state_since
        self.scene_anchor = ()
        self.last_state = GameState.UNKNOWN
        self.recovery_attempts = 0
        self.last_recovery = 0.0
        self.target_confirmed = False
        self.confirm_deadline = self.state_since + 30.0
        self.in_combat_episode = False
        self.combat_episode_started = 0.0
        self.combat_obs = CombatObservation()
        self.combat_frame_fingerprint = ()
        self.scene = SceneUnderstanding(self.vision, profile.sample_w, profile.sample_h)
        self.world_model = CausalWorldModel(
            os.path.join(base_dir, ".ai_world_model_v3.json.gz"), profile,
            legacy_path=os.path.join(base_dir, ".ai_world_model_v2.json"),
        )
        self.world_state = WorldState(captured_at=self.state_since)
        self.previous_world_state = None
        self.world_probe = None
        self.last_world_action = 0.0
        self.last_passive_sample = self.state_since
        self.last_plan_score = 0.0
        self.tactical_mode = "观察"
        self.last_tactic = ""
        self.last_emergency = 0.0
        self.unknown_actions = 0
        self.unknown_dynamic_since = 0.0
        self.novel_play_mode = False
        self.novel_play_since = 0.0
        self.io.bind_input_guard(self._input_guard)

    def _input_guard(self):
        if self.stop_event.is_set():
            return False
        if self.io.escape_down():
            self.stop_event.set()
            return False
        return self.target_confirmed and self.io.valid_window(self.hwnd) and self.io.is_foreground(self.hwnd)


    def _update_novel_play_mode(self, state, motion, now):
        safe_unknown = (
            self.target_confirmed and state == GameState.UNKNOWN and not self.in_combat_episode
            and not self.vision.has_danger(self.snapshot) and motion >= 0.82
        )
        if safe_unknown:
            if not self.unknown_dynamic_since:
                self.unknown_dynamic_since = now
            if not self.novel_play_mode and now - self.unknown_dynamic_since >= 1.15:
                self.novel_play_mode = True
                self.novel_play_since = now
                self.scene.reset_episode()
                self.world_probe = None
                self.previous_world_state = None
                self.tactical_mode = "新玩法观察建模"
        else:
            self.unknown_dynamic_since = 0.0
            if self.novel_play_mode and state != GameState.UNKNOWN:
                self.novel_play_mode = False
                self.novel_play_since = 0.0
                self.world_probe = None
                self.previous_world_state = None

    def _novel_gameplay(self, now):
        state = self.world_state
        if state is None or self.world_probe is not None:
            return
        if self._emergency_reflex(now):
            return
        available = set(self.world_model.available(now, self.skill_hud.readiness()))
        if not available:
            return
        age = now - self.novel_play_since if self.novel_play_since else 0.0
        confidence = self.world_model.context_confidence(state)
        base = ["F", "TOWARD", "K", "J", "W", "S", "A", "D", "EVADE", "RETREAT"]
        if age >= 5.0 or confidence >= 0.18 or state.engaged >= 0.42:
            base += ["U", "I", "O", "L", "Z"]
        if (age >= 10.0 or confidence >= 0.32) and state.engaged >= 0.34:
            base += ["JJJ", "KJ", "CHASEJ", "UJ", "IJ", "OJ", "LJ", "SPACE"]
        candidates = [a for a in base if a in available]
        if not candidates:
            return
        candidates.sort(key=lambda a: self.world_model.probe_score(a, state), reverse=True)
        candidates = candidates[:max(5, min(self.governor.candidate_budget, 9))]
        action, score = self.world_model.choose(state, candidates, depth=1 if confidence < 0.30 else min(2, self.governor.planning_depth))
        if action and self._execute_world_action(action, now):
            self.tactical_mode = "新玩法因果探索"
            self.last_plan_score = score

    def run(self):
        try:
            self.ocr_available = self.ocr.self_test()
            if self.ocr_available:
                self.ocr.start()
                language = self.ocr.worker.language or "用户语言"
                if not language.lower().startswith("zh"):
                    self.send_status(f"中文 OCR 不可用，已降级到 {language} OCR｜视觉战斗保持启用｜Esc 停止")
            else:
                self.send_status("Windows OCR 不可用，已进入纯视觉战斗模式｜菜单仅做安全视觉等待｜Esc 停止")
            if not self.io.foreground(self.hwnd):
                raise RuntimeError("无法将游戏窗口置于前台")
            while not self.stop_event.is_set():
                cycle_started = time.perf_counter()
                if self.io.escape_down():
                    self.stop_event.set()
                    break
                if not self.io.valid_window(self.hwnd):
                    raise RuntimeError("Firefox 游戏窗口已关闭")
                if not self.io.is_foreground(self.hwnd):
                    self.io.release_all()
                    self.send_status("AI 已暂停｜游戏窗口不在前台｜Esc 停止")
                    self.stop_event.wait(0.12)
                    continue
                rect = self.io.client_rect(self.hwnd)
                if not rect:
                    self.io.release_all()
                    self.stop_event.wait(0.15)
                    continue
                frame = self.grabber.capture(rect)
                if not frame:
                    self.stop_event.wait(0.15)
                    continue
                now = time.monotonic()
                self.skill_hud.observe(frame, now)

                available, snapshot = self.ocr.take_latest()
                if available:
                    self.snapshot = snapshot
                    if snapshot:
                        self.power.observe_power(self.vision.extract_power(snapshot))
                if self.ocr.disabled and self.ocr_available:
                    self.ocr_available = False
                    self.snapshot = None
                    if not self.ocr_degraded_reported:
                        self.ocr_degraded_reported = True
                        self.send_status("OCR 运行中失效，已自动降级为纯视觉战斗模式｜Esc 停止")
                if self.ocr_available and now - self.last_ocr_request >= self.governor.ocr_interval and self.ocr.request(rect):
                    self.last_ocr_request = now

                fingerprint = self.vision.fingerprint(frame)
                raw_state, confidence, motion = self.vision.classify(
                    frame, self.previous, self.snapshot,
                    self.detector.stable == GameState.COMBAT or self.in_combat_episode or self.novel_play_mode,
                )
                if raw_state == GameState.UNKNOWN and not self.vision.has_danger(self.snapshot):
                    recalled_state, recalled_confidence = self.state_memory.infer(fingerprint)
                    if recalled_confidence > confidence and not self.novel_play_mode:
                        raw_state, confidence = recalled_state, recalled_confidence
                else:
                    self.state_memory.observe(raw_state, confidence, fingerprint)
                if not self.target_confirmed and raw_state not in (GameState.UNKNOWN, GameState.LOADING):
                    self.target_confirmed = True
                if not self.target_confirmed and now >= self.confirm_deadline:
                    if self.ocr_available:
                        self.ocr_available = False
                        self.snapshot = None
                        self.ocr_degraded_reported = True
                        self.send_status("OCR 未能确认游戏界面，已自动降级为纯视觉模式｜不会点击未确认菜单｜Esc 停止")
                    else:
                        self.send_status("纯视觉模式等待可确认的游戏 HUD｜不会点击未确认菜单｜Esc 停止")
                    self.confirm_deadline = now + 30.0

                stable = self.detector.update(raw_state, confidence)
                self._update_novel_play_mode(stable, motion, now)
                self._track_progress(stable, fingerprint, now)
                self.power.resolve_action(stable, fingerprint, self.vision)
                if stable != self.last_state:
                    self._on_state_change(self.last_state, stable)
                    self.last_state = stable
                    self.state_since = now
                if stable == GameState.COMBAT or self.in_combat_episode or self.novel_play_mode:
                    self.combat_obs = self.vision.combat_observation(frame, self.previous, motion)
                    self.combat_frame_fingerprint = self.vision.combat_fingerprint(frame)
                    self.world_state = self.scene.encode(
                        frame, self.previous, self.combat_obs, self.combat_frame_fingerprint, motion
                    )
                    self._resolve_world_probe(now)
                    self._learn_passive_transition(now)
                self._handle_state(stable, motion, fingerprint, now)
                self.previous = frame
                if now - self.last_status >= 1.2:
                    self._status(stable)
                    self.last_status = now
                delay = self.governor.finish(time.perf_counter() - cycle_started)
                self.stop_event.wait(delay)
        finally:
            self.world_model.save(force=True)
            self.ocr.close()
            self.io.bind_input_guard(None)
            self.io.release_all()
            self.grabber.close()

    def _track_progress(self, state, fingerprint, now):
        if state != self.last_state and state != GameState.UNKNOWN:
            self.last_effective_change = now
            self.scene_anchor = fingerprint
            self.recovery_attempts = 0
            self.unknown_actions = 0
            return
        if not self.scene_anchor:
            self.scene_anchor = fingerprint
            return
        distance = self.vision.fingerprint_distance(fingerprint, self.scene_anchor)
        threshold = 1.15 if state == GameState.COMBAT else (1.30 if self.novel_play_mode else 1.75)
        if distance >= threshold:
            self.last_effective_change = now
            self.scene_anchor = fingerprint
            self.recovery_attempts = 0

    def _on_state_change(self, old, new):
        if new == GameState.COMBAT and not self.in_combat_episode:
            self.in_combat_episode = True
            self.combat_episode_started = time.monotonic()
            self.power.entered_combat()
            self.vision.reset_combat_calibration()
            self.scene.reset_episode()
            self.world_probe = None
            self.previous_world_state = None
            self.tactical_mode = "观察"
            self.last_tactic = ""
        if self.in_combat_episode and new == GameState.REWARD:
            self.power.combat_result(True)
            self.world_model.note_terminal(True)
            self.in_combat_episode = False
            self.world_probe = None
            self.world_model.save()
        elif self.in_combat_episode and new == GameState.RETRY:
            self.power.combat_result(False)
            self.world_model.note_terminal(False)
            self.in_combat_episode = False
            self.world_probe = None
            self.world_model.save()
        if old == GameState.COMBAT and new != GameState.COMBAT:
            self.io.release_all()

    def _handle_state(self, state, motion, fingerprint, now):
        stale_for = now - self.last_effective_change
        if state == GameState.LOADING:
            self.io.release_all()
            if now - self.state_since > 90:
                raise RestartGame("加载超过 90 秒")
            return
        if state == GameState.UNKNOWN:
            danger = self.vision.has_danger(self.snapshot)
            if not danger and self.novel_play_mode and self.world_state is not None:
                if motion >= 0.42 or self.world_state.crowd >= 0.12 or self.world_state.scene_change >= 0.12:
                    self._novel_gameplay(now)
                    return
            if (
                self.in_combat_episode and self.world_state is not None and not danger
                and (motion >= 0.55 or self.world_state.crowd >= 0.18 or self.world_state.scene_change >= 0.16)
            ):
                self._combat(now, motion)
                return
            self.io.release_all()
            if (
                self.unknown_actions < 10 and now - self.last_action >= 1.45
                and self.snapshot and now - self.snapshot.captured_at <= 4.5
            ):
                growth_word = self.vision.safe_growth_action_word(self.snapshot)
                if growth_word and self._click_unknown_word(growth_word, "safe_growth", fingerprint):
                    self.unknown_actions += 1
                    self.tactical_mode = "安全成长探索"
                    return
                word = self.vision.generic_safe_action_word(self.snapshot)
                if word and self._click_unknown_word(word):
                    self.unknown_actions += 1
                    self.tactical_mode = "陌生界面安全探索"
                    return
            timeout = 150 if self.novel_play_mode else 105
            if now - self.state_since > timeout and stale_for > 58:
                if not self.ocr_available:
                    self.last_effective_change = now
                    self.send_status("纯视觉模式无法安全确认当前菜单，保持等待且不执行危险点击｜Esc 停止")
                    return
                raise RestartGame(f"超过 {timeout} 秒无法识别或推进当前界面")
            return
        if state == GameState.COMBAT:
            if stale_for > 16:
                self._recover_combat(now)
                return
            self._combat(now, motion)
            return
        self.io.release_all()
        if stale_for > 45 and state not in (GameState.REWARD, GameState.EQUIPMENT, GameState.UPGRADE):
            if now - self.last_action > 15:
                raise RestartGame(f"{STATE_NAMES[state]}界面长期无有效变化")
        if now - self.last_action < 1.25 or self.power.pending:
            return
        if state == GameState.HOME:
            if not self._try_growth_entry(fingerprint):
                self._click_ocr_action(state, ("冒险", "副本", "关卡", "开始游戏"), "home", fingerprint)
        elif state == GameState.SELECT_STAGE:
            if not self._click_ocr_action(state, ("挑战", "进入关卡", "开始挑战", "进入"), "stage_enter", fingerprint):
                self._select_stage(fingerprint)
        elif state == GameState.REWARD:
            self._click_ocr_action(state, ("领取", "收下", "继续", "下一关", "完成", "确定"), "reward", fingerprint)
        elif state == GameState.EQUIPMENT:
            self._click_ocr_action(state, ("一键装备", "一键穿戴", "穿戴", "更换"), "equip", fingerprint)
        elif state == GameState.UPGRADE:
            self._click_ocr_action(state, ("免费强化", "免费升级", "免费"), "free_upgrade", fingerprint)
        elif state == GameState.RETRY:
            self._click_ocr_action(state, ("再次挑战", "重新挑战", "重试", "返回关卡"), "retry", fingerprint)

    def _click_unknown_word(self, word, growth_kind=None, fingerprint=None):
        if not self.snapshot:
            return False
        rect = self.io.client_rect(self.hwnd)
        if not rect:
            return False
        x, y, width, height = rect
        nx = word.cx / max(self.snapshot.width, 1)
        ny = word.cy / max(self.snapshot.height, 1)
        if self.io.click(x + width * nx, y + height * ny):
            self.last_action = time.monotonic()
            if growth_kind and fingerprint is not None:
                self.power.start_action(growth_kind, GameState.UNKNOWN, fingerprint)
            self.last_ocr_request = 0.0
            return True
        return False

    def _try_growth_entry(self, fingerprint):
        mapping = {
            "equip": (("装备", "背包"), "open_equipment"),
            "free_upgrade": (("强化", "升级", "锻造"), "open_upgrade"),
        }
        for kind in self.power.growth_action_order():
            if kind == "safe_growth":
                word = self.vision.safe_growth_action_word(self.snapshot)
                if word and self._click_unknown_word(word, "safe_growth", fingerprint):
                    return True
                continue
            priorities, open_kind = mapping[kind]
            if self._click_ocr_action(GameState.HOME, priorities, open_kind, fingerprint):
                return True
        return False

    def _click_ocr_action(self, state, priorities, kind, fingerprint):
        word = self.vision.action_word(self.snapshot, state, priorities)
        if not word or not self.snapshot:
            return False
        rect = self.io.client_rect(self.hwnd)
        if not rect:
            return False
        x, y, width, height = rect
        nx = word.cx / max(self.snapshot.width, 1)
        ny = word.cy / max(self.snapshot.height, 1)
        if self.io.click(x + width * nx, y + height * ny):
            self.last_action = time.monotonic()
            self.power.start_action(kind, state, fingerprint)
            self.last_ocr_request = 0.0
            if kind in ("home", "stage_enter", "retry"):
                self.snapshot = None
            return True
        return False

    def _select_stage(self, fingerprint):
        if not self.snapshot or self.vision.has_danger(self.snapshot):
            return False
        options = []
        for word in self.snapshot.words:
            text = self.vision._compact(word.text)
            if not (
                re.fullmatch(r"\d{1,3}[-—]\d{1,3}", text)
                or re.fullmatch(r"第?\d{1,3}关", text)
            ):
                continue
            nx = word.cx / max(self.snapshot.width, 1)
            ny = word.cy / max(self.snapshot.height, 1)
            if not (0.02 <= nx <= 0.98 and 0.05 <= ny <= 0.98):
                continue
            nums = [int(x) for x in re.findall(r"\d+", text)]
            numeric = nums[0] * 1000 + (nums[1] if len(nums) > 1 else 0)
            required_power = None
            nearby = []
            for candidate in self.vision._line_candidates(self.snapshot):
                if abs(candidate.cy - word.cy) > self.snapshot.height * 0.16:
                    continue
                if abs(candidate.cx - word.cx) > self.snapshot.width * 0.38:
                    continue
                candidate_text = self.vision._compact(candidate.text).replace("，", ",")
                if "推荐战力" not in candidate_text:
                    continue
                match = re.search(r"推荐战力[：:]?([0-9][0-9,.]{0,12})(万|亿)?", candidate_text)
                if match:
                    value = self.vision._parse_power_number(match.group(1), match.group(2))
                    if value:
                        nearby.append((abs(candidate.cy - word.cy), value))
            if nearby:
                nearby.sort(key=lambda item: item[0])
                required_power = nearby[0][1]
            options.append((numeric, required_power, word, text))
        choice = self.power.choose_stage(options)
        if not choice:
            return False
        word, stage_id = choice
        rect = self.io.client_rect(self.hwnd)
        if not rect:
            return False
        x, y, width, height = rect
        nx = word.cx / max(self.snapshot.width, 1)
        ny = word.cy / max(self.snapshot.height, 1)
        if self.io.click(x + width * nx, y + height * ny):
            self.power.select_stage(stage_id)
            self.power.start_action("stage_select", GameState.SELECT_STAGE, fingerprint)
            self.last_action = time.monotonic()
            self.last_ocr_request = 0.0
            return True
        return False

    def _learn_passive_transition(self, now):
        current = self.world_state
        previous = self.previous_world_state
        if current is None:
            return
        if previous is not None and self.world_probe is None and now - self.last_world_action > 0.85:
            if now - self.last_passive_sample >= 0.30:
                self.world_model.record("WAIT", previous, current)
                self.last_passive_sample = now
        self.previous_world_state = current

    def _world_effective(self, before, after, raw):
        hp_delta, _, boss_damage, approach, scene, _, _, _, threat_relief, combo_gain, advantage_gain = raw
        if boss_damage > 0.003:
            return True
        if hp_delta > 0.008 or threat_relief > 0.035 or advantage_gain > 0.025:
            return True
        if abs(approach) > 0.015 or combo_gain > 0.045:
            return True
        if scene > 0.12:
            return True
        if before.motion < 1.2 and after.motion > 2.2:
            return True
        return False
    @staticmethod
    def _aggregate_probe_effect(observations, target_latency=0.35):
        if not observations:
            return None, 0.0
        base_weights = (0.12, 0.20, 0.28, 0.40)
        weighted = []
        for base, (sample_age, _, _) in zip(base_weights, observations):
            proximity = 1.0 / (0.10 + abs(float(sample_age) - float(target_latency)))
            weighted.append(base * (0.72 + 0.28 * min(2.2, proximity * 0.20)))
        total = sum(weighted) or 1.0
        effect = [0.0] * CausalWorldModel.EFFECT_DIM
        latency = 0.0
        for weight, (sample_age, _, raw) in zip(weighted, observations):
            normalized = weight / total
            latency += sample_age * normalized
            for index, value in enumerate(raw):
                effect[index] += float(value) * normalized
        return tuple(effect), latency

    def _finalize_world_probe(self):
        probe = self.world_probe
        if not probe or not probe.get("observations"):
            self.world_probe = None
            return
        before = probe["state"]
        after = probe["observations"][-1][1]
        raw, latency = self._aggregate_probe_effect(probe["observations"], probe.get("target_latency", 0.35))
        effective = self._world_effective(before, after, raw)
        self.world_model.record(
            probe["action"], before, after, effective,
            raw_override=raw, observed_latency=latency,
        )
        self.world_probe = None

    def _resolve_world_probe(self, now):
        probe = self.world_probe
        if not probe or self.world_state is None:
            return
        age = now - probe["at"]
        sample_times = probe["sample_times"]
        next_index = probe["next_index"]
        while next_index < len(sample_times) and age >= sample_times[next_index]:
            sample_age = sample_times[next_index]
            after = self.world_state
            raw = self.world_model._raw_effect(probe["state"], after)
            probe["observations"].append((sample_age, after, raw))
            next_index += 1
            probe["next_index"] = next_index
        if next_index >= len(sample_times):
            self._finalize_world_probe()

    def _action_duration(self, action):
        scale = self.governor.input_scale
        if action in ("A", "D", "TOWARD", "RETREAT"):
            return 0.115 * scale
        if action in ("W", "S"):
            return 0.075 * scale
        if action == "K":
            return 0.045 * scale
        if action == "SPACE":
            return 0.045 * scale
        if action in ("U", "I", "O", "L"):
            return 0.035 * scale
        return 0.032 * scale
    def _effect_delay(self, action):
        if action in ("A", "D", "W", "S", "TOWARD", "RETREAT"):
            base = 0.22
        elif action == "EVADE":
            base = 0.30
        elif action in ("JJJ", "KJ", "CHASEJ"):
            base = 0.43
        elif action in ("UJ", "IJ", "OJ", "LJ", "SPACEJ"):
            base = 0.54
        elif action in ("J", "U", "I", "O", "L", "SPACE", "WAIT"):
            base = 0.34
        else:
            base = 0.30
        return self.world_model.adaptive_effect_delay(action, base) * max(0.92, min(1.12, self.governor.input_scale))

    def _smart_wait(self, seconds):
        if seconds <= 0:
            return self._input_guard()
        if self.stop_event.wait(seconds):
            return False
        return self._input_guard()

    def _direction_key(self, toward=True):
        state = self.world_state
        side = 0.0 if state is None else state.target_side
        if not side and state is not None and state.player_x is not None:
            delta = state.active_x - state.player_x
            if abs(delta) > 0.08:
                side = 1.0 if delta > 0 else -1.0
        if not side:
            side = 1.0
        if not toward:
            if state is not None and abs(state.escape_side) > 0.5:
                side = state.escape_side
            else:
                side = -side
        return "D" if side > 0 else "A"

    def _perform_tactical_action(self, action):
        components = []
        if action == "WAIT":
            return True, components
        if action == "TOWARD":
            key = self._direction_key(True)
            return self.io.tap(key, self._action_duration("TOWARD")), [key]
        if action == "RETREAT":
            key = self._direction_key(False)
            return self.io.tap(key, self._action_duration("RETREAT") * 1.08), [key]
        if action == "EVADE":
            key = self._direction_key(False)
            if not self.io.key_down(key):
                return False, components
            components.append(key)
            try:
                if not self._smart_wait(0.018 * self.governor.input_scale):
                    return False, components
                if not self.io.tap("K", 0.040 * self.governor.input_scale):
                    return False, components
                components.append("K")
                self._smart_wait(0.055 * self.governor.input_scale)
                return True, components
            finally:
                self.io.key_up(key)
        if action == "JJJ":
            for index in range(3):
                if not self.io.tap("J", 0.026):
                    return False, components
                components.append("J")
                if index < 2 and not self._smart_wait(0.034):
                    return False, components
            return True, components
        if action == "KJ":
            if not self.io.tap("K", 0.040):
                return False, components
            components.append("K")
            if not self._smart_wait(0.052) or not self.io.tap("J", 0.028):
                return False, components
            components.append("J")
            if self._smart_wait(0.035) and self.io.tap("J", 0.025):
                components.append("J")
            return True, components
        if action == "CHASEJ":
            direction = self._direction_key(True)
            if not self.io.key_down(direction):
                return False, components
            components.append(direction)
            try:
                if not self._smart_wait(0.040) or not self.io.tap("J", 0.028):
                    return False, components
                components.append("J")
                if not self._smart_wait(0.050) or not self.io.tap("J", 0.026):
                    return False, components
                components.append("J")
                return True, components
            finally:
                self.io.key_up(direction)
        if action in ("UJ", "IJ", "OJ", "LJ"):
            skill = action[0]
            if not self.io.tap(skill, 0.034):
                return False, components
            components.append(skill)
            if not self._smart_wait(0.060) or not self.io.tap("J", 0.026):
                return False, components
            components.append("J")
            return True, components
        if action == "SPACEJ":
            if not self.io.tap("SPACE", 0.044):
                return False, components
            components.append("SPACE")
            if not self._smart_wait(0.070) or not self.io.tap("J", 0.027):
                return False, components
            components.append("J")
            if self._smart_wait(0.040) and self.io.tap("J", 0.025):
                components.append("J")
            return True, components
        if action in CausalWorldModel.PRIMITIVES:
            return self.io.tap(action, self._action_duration(action)), [action]
        return False, components

    def _candidate_actions(self, state, available):
        allowed = set(available)
        if not allowed:
            return []
        hp = 0.70 if state.hp is None else state.hp
        mp = 0.70 if state.mp is None else state.mp
        distance = state.distance
        threat = max(state.threat, state.impact_risk * 0.92)
        boss = state.boss
        skill_actions = {"U", "I", "O", "L", "UJ", "IJ", "OJ", "LJ"}
        if hp < 0.16:
            self.tactical_mode = "极限保命"
            desired = ["EVADE", "H", "SPACE", "K", "RETREAT", "KJ", "A", "D"]
        elif state.impact_risk >= 0.54 or state.risk_trend >= 0.48 or state.telegraph >= 0.56 or threat >= 0.70 or state.incoming >= 0.48:
            self.tactical_mode = "预判读招规避"
            desired = ["EVADE", "K", "RETREAT", "KJ", "SPACE", "H", "J", "TOWARD"]
        elif state.opening >= 0.68 and distance is not None and distance <= 0.30:
            self.tactical_mode = "抓后摇爆发"
            desired = ["UJ", "IJ", "OJ", "LJ", "SPACEJ", "JJJ", "J", "KJ", "CHASEJ", "TOWARD"]
        elif distance is None:
            self.tactical_mode = "寻敌推进"
            desired = ["TOWARD", "D", "F", "W", "S", "K", "J", "A", "Z"]
        elif distance > 0.36:
            self.tactical_mode = "追击"
            desired = ["TOWARD", "CHASEJ", "K", "U", "I", "O", "L", "F", "D", "A"]
        elif distance > 0.18:
            self.tactical_mode = "中距压制"
            desired = ["CHASEJ", "TOWARD", "J", "JJJ", "UJ", "IJ", "OJ", "LJ", "KJ", "SPACEJ", "K", "EVADE"]
        else:
            if boss is not None and (boss < 0.34 or state.combo > 0.58) and threat < 0.58:
                self.tactical_mode = "斩杀爆发"
                desired = ["SPACEJ", "UJ", "IJ", "OJ", "LJ", "JJJ", "J", "KJ", "RETREAT"]
            else:
                self.tactical_mode = "近身连压"
                desired = ["JJJ", "J", "UJ", "IJ", "OJ", "LJ", "KJ", "SPACEJ", "EVADE", "RETREAT", "H"]
        if mp < 0.12:
            desired = [a for a in desired if a not in skill_actions]
        elif mp < 0.24:
            desired = [a for a in desired if a not in ("UJ", "IJ", "OJ", "LJ")]
            for skill in ("U", "I", "O", "L"):
                if skill in allowed:
                    desired.append(skill)
        if boss is None and state.engaged < 0.45 and state.crowd < 0.35:
            desired = [a for a in desired if a not in ("SPACEJ", "SPACE")]
        novel = max(state.novelty, state.phase_shift)
        if novel >= 0.62 and hp >= 0.50 and threat <= 0.50:
            self.tactical_mode = "陌生机制因果探测"
            probes = ["F", "TOWARD", "K", "J", "W", "S", "A", "D", "EVADE", "RETREAT", "U", "I", "O", "L", "Z", "SPACE"]
            probes = [a for a in probes if a in allowed]
            probes.sort(key=lambda a: self.world_model.probe_score(a, state), reverse=True)
            probe_head = probes[:min(8, max(5, self.governor.candidate_budget // 2 + 2))]
            desired = probe_head + [a for a in desired if a not in probe_head]
        learned = []
        if threat < 0.68 and state.telegraph < 0.58 and state.impact_risk < 0.54:
            learned = self.world_model.learned_sequence_candidates(state, allowed, limit=3)
        desired = learned + [a for a in desired if a not in learned]
        result = [a for a in desired if a in allowed]
        if not result:
            result = list(available)
        budget = max(5, int(self.governor.candidate_budget))
        return result[:budget]
    def _execute_world_action(self, action, now):
        before = self.world_state
        if before is None or self.world_probe is not None:
            return False
        self.io.release_all()
        ok, components = self._perform_tactical_action(action)
        if not ok:
            self.io.release_all()
            return False
        stamp = time.monotonic()
        self.world_model.note_execution(action, stamp, components, before)
        for key in components:
            self.skill_hud.note_action(key, stamp)
        self.last_world_action = stamp
        self.last_action = stamp
        self.last_tactic = action
        adaptive = self._effect_delay(action)
        self.world_probe = {
            "action": action,
            "state": before,
            "at": stamp,
            "sample_times": (0.10, 0.20, 0.35, 0.55),
            "target_latency": adaptive,
            "next_index": 0,
            "observations": [],
        }
        return True
    def _emergency_reflex(self, now):
        state = self.world_state
        if state is None or now - self.last_emergency < 0.24:
            return False
        hp = 0.70 if state.hp is None else state.hp
        urgent = (
            state.impact_risk >= 0.54 or state.risk_trend >= 0.56 or state.telegraph >= 0.62
            or state.incoming >= 0.58 or state.threat >= 0.84
            or (hp < 0.15 and max(state.threat, state.impact_risk) >= 0.46)
        )
        if not urgent:
            return False
        if self.world_probe is not None:
            probe = self.world_probe
            if now - probe["at"] >= 0.08:
                raw = self.world_model._raw_effect(probe["state"], state)
                probe.setdefault("observations", []).append((max(0.08, now - probe["at"]), state, raw))
                self._finalize_world_probe()
            else:
                self.world_probe = None
        available = self.world_model.available(now, self.skill_hud.readiness())
        emergency = [a for a in ("EVADE", "K", "RETREAT", "H", "SPACE", "KJ", "A", "D") if a in available]
        if not emergency:
            return False
        action, score = self.world_model.choose(state, emergency, depth=1)
        if action and self._execute_world_action(action, now):
            self.last_emergency = now
            self.tactical_mode = "提前量保命反应"
            self.last_plan_score = score
            return True
        return False

    def _combat(self, now, motion):
        if self._emergency_reflex(now):
            return
        if self.world_probe is not None:
            return
        state = self.world_state
        if state is None:
            return
        available = self.world_model.available(now, self.skill_hud.readiness())
        if not available:
            return
        hp = 0.70 if state.hp is None else state.hp
        if hp > 0.64 and state.threat < 0.24 and self.world_model.needs_baseline():
            if self._execute_world_action("WAIT", now):
                self.tactical_mode = "观察建模"
                self.last_plan_score = 0.0
                return
        candidates = self._candidate_actions(state, available)
        action, score = self.world_model.choose(state, candidates, depth=self.governor.planning_depth)
        if action is None:
            return
        self.last_plan_score = score
        self._execute_world_action(action, now)
    def _recover_combat(self, now):
        if now - self.last_recovery < 1.6:
            return
        self.io.release_all()
        self.recovery_attempts += 1
        self.power.record_stuck()
        self.last_recovery = now
        self.world_probe = None
        state = self.world_state
        self.tactical_mode = "脱困重规划"
        if state is not None:
            available = self.world_model.available(now, self.skill_hud.readiness())
            candidates = [a for a in ("EVADE", "TOWARD", "KJ", "K", "F", "CHASEJ", "J", "W", "S", "RETREAT", "D", "A") if a in available]
            if candidates:
                action, score = self.world_model.choose(state, candidates, depth=self.governor.planning_depth)
                if action and self._execute_world_action(action, now):
                    self.last_plan_score = score
                    return
        fallback = ("F", "K", "D", "J", "W", "A")[(self.recovery_attempts - 1) % 6]
        self.io.tap(fallback, self._action_duration(fallback))
        if self.recovery_attempts >= 11 and now - self.last_effective_change > 68:
            raise RestartGame("战术模型连续脱困失败，战斗超过 68 秒无有效推进")
    def _status(self, state):
        if self.power.current_power:
            power_text = f"战力 {self.power.current_power:,}"
        else:
            power_text = "战力待识别"
        if self.ocr_available:
            lang = self.ocr.worker.language or "?"
            ocr_text = f"OCR:{lang}"
        else:
            ocr_text = "纯视觉"
        ready_map = self.skill_hud.readiness()
        visual_skill_count = sum(1 for value in ready_map.values() if value is not None)
        def pct(value):
            return "--" if value is None else f"{int(max(0.0, min(1.0, value)) * 100):d}%"
        obs = self.combat_obs
        visual = f"HP {pct(obs.hp_ratio)} MP {pct(obs.mp_ratio)}"
        if obs.player_x is not None and obs.enemy_x is not None:
            visual += f" 敌距 {abs(obs.enemy_x - obs.player_x):.2f}"
        confidence = int(self.world_model.model_confidence() * 100)
        context_conf = int(self.world_model.context_confidence(self.world_state) * 100) if self.world_state else 0
        memory = len(self.world_model.memory)
        lifetime_k = self.world_model.lifetime_updates / 1000.0
        threat = int(max(0.0, min(1.0, self.world_state.threat if self.world_state else 0.0)) * 100)
        telegraph = int(max(0.0, min(1.0, self.world_state.telegraph if self.world_state else 0.0)) * 100)
        impact = int(max(0.0, min(1.0, self.world_state.impact_risk if self.world_state else 0.0)) * 100)
        tactic = self.last_tactic or "--"
        cpu = int(self.governor.cpu_load * 100) if self.governor.cpu_load else 0
        ram = int(self.governor.memory_load * 100) if self.governor.memory_load else 0
        gpu = self.profile.gpu_name.strip()
        gpu_text = (gpu[:18] + "…") if len(gpu) > 19 else (gpu or "GPU?")
        mode = "新玩法" if self.novel_play_mode and state == GameState.UNKNOWN else STATE_NAMES[state]
        self.send_status(
            f"{mode}｜{power_text}｜{visual}｜{self.tactical_mode} 威胁{threat}% 预兆{telegraph}% 冲击{impact}%｜招式 {tactic}｜模型 {confidence}% 局部{context_conf}%/{memory}条/终身{lifetime_k:.1f}k｜规划{self.governor.planning_depth}层 {self.last_plan_score:+.2f}｜{self.profile.label}/{self.governor.mode} {self.governor.estimated_hz:.0f}Hz CPU{cpu}% RAM{ram}%｜{self.grabber.backend_name} {gpu_text}｜战力↑ {self.power.actual_power_gains}｜{ocr_text}/技能视觉{visual_skill_count}｜Esc 停止"
        )


class App:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("520x270")
        self.root.resizable(False, False)
        self.root.configure(bg="#101722")
        self.io = WinIO()
        self.base_dir = _resolve_data_dir(os.path.dirname(os.path.abspath(__file__)))
        self.profile = detect_runtime_profile(self.base_dir)
        self.messages = queue.SimpleQueue()
        self.stop_event = threading.Event()
        self.shutdown_event = threading.Event()
        self.worker = None
        self.running = False
        self.closing = False
        self.close_deadline = 0.0
        self.owned_game_windows = {}
        cleanup_old_ocr_files(self.base_dir)
        self._build()
        self.root.bind_all("<Escape>", lambda _: self.stop())
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.escape_monitor = threading.Thread(target=self._escape_monitor_loop, daemon=True)
        self.escape_monitor.start()
        self.root.after(45, self.poll)

    def _escape_monitor_loop(self):
        latched = False
        while not self.shutdown_event.is_set():
            down = self.io.escape_down()
            if self.running and down and not latched:
                latched = True
                self.stop_event.set()
                self.io.release_all()
                self.messages.put(("status", "Esc 已触发硬停止｜正在清理线程与按键…"))
            elif not down:
                latched = False
            self.shutdown_event.wait(0.015)

    def _owned_game_pid(self, hwnd):
        return self.owned_game_windows.get(int(hwnd), 0)

    def _build(self):
        tk.Label(
            self.root,
            text="造梦西游之黎尤浩劫篇",
            font=("Microsoft YaHei UI", 19, "bold"),
            fg="#f4f7fb",
            bg="#101722",
        ).pack(pady=(22, 4))
        tk.Label(
            self.root,
            text="陌生机制探索｜因果规划｜硬件自适应｜战力闭环",
            font=("Microsoft YaHei UI", 10),
            fg="#91a4ba",
            bg="#101722",
        ).pack()
        self.button = tk.Button(
            self.root,
            text="AI",
            command=self.start,
            width=13,
            height=2,
            font=("Microsoft YaHei UI", 16, "bold"),
            fg="white",
            bg="#16a56a",
            activebackground="#128357",
            activeforeground="white",
            bd=0,
            cursor="hand2",
        )
        self.button.pack(pady=20)
        ram = f"{self.profile.memory_gb:.0f}GB" if self.profile.memory_gb > 0 else "RAM?"
        gpu = self.profile.gpu_name.strip() or "GPU未识别"
        if len(gpu) > 28:
            gpu = gpu[:28] + "…"
        cpu_text = f"{self.profile.physical_cores or self.profile.cores}C/{self.profile.cores}T"
        if self.profile.cpu_mhz > 0:
            cpu_text += f" {self.profile.cpu_mhz / 1000.0:.1f}GHz"
        power_text = " 电池" if self.profile.on_battery else ""
        disk_text = f"盘余{self.profile.disk_free_gb:.0f}GB" if self.profile.disk_free_gb > 0 else "磁盘?"
        self.status = tk.StringVar(value=f"点击 AI 开始｜{self.profile.label}{power_text} {cpu_text}/{ram}/{disk_text}｜{gpu}｜Esc 随时停止")
        tk.Label(
            self.root,
            textvariable=self.status,
            font=("Microsoft YaHei UI", 9),
            fg="#c6d2df",
            bg="#101722",
            wraplength=485,
        ).pack()

    def start(self):
        if self.running:
            return
        if not os.path.isfile(FIREFOX_PATH):
            self.status.set("未找到 D:\\FirefoxPortable\\FirefoxPortable.exe")
            return
        self.running = True
        self.stop_event.clear()
        self.button.configure(state="disabled", text="运行中", bg="#4c657d")
        self.status.set(f"正在启动 Firefox 并确认游戏画面…｜{self.profile.label}模式｜Esc 停止")
        self.worker = threading.Thread(target=self._worker, daemon=True)
        self.worker.start()

    def _launch_game_window(self):
        previous = {item[0]: item[1] for item in self.io.firefox_windows()}
        subprocess.Popen(
            [FIREFOX_PATH, "-new-window", GAME_URL],
            cwd=os.path.dirname(FIREFOX_PATH),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        deadline = time.monotonic() + 45
        while not self.stop_event.is_set() and time.monotonic() < deadline:
            hwnd = self.io.choose_firefox(previous)
            if hwnd:
                self.owned_game_windows[int(hwnd)] = self.io.window_pid(hwnd)
                return hwnd
            self.stop_event.wait(0.35)
        if self.stop_event.is_set():
            return 0
        raise RuntimeError("未找到新出现或已切换到游戏页面的大尺寸 Firefox 窗口")

    def _worker(self):
        hwnd = 0
        tracker = None
        try:
            restart_times = []
            tracker = PowerTracker(os.path.join(self.base_dir, ".ai_progress.json"))
            while not self.stop_event.is_set():
                hwnd = self._launch_game_window()
                if not hwnd or self.stop_event.is_set():
                    return
                self.messages.put(("status", "游戏窗口已确认，开始识别状态…｜Esc 停止"))
                session_started = time.monotonic()
                try:
                    if self.profile.prefer_dxgi:
                        gpu_name = self.profile.gpu_name.strip() or "独立GPU"
                        self.messages.put(("status", f"检测到 {gpu_name}｜尝试启用已安装的GPU捕获；未安装则立即使用GDI｜Esc 停止"))
                    AdaptiveAgent(
                        self.io, hwnd, self.stop_event, self._send_status, self.base_dir, tracker, self.profile
                    ).run()
                    return
                except RestartGame as exc:
                    self.io.release_all()
                    now = time.monotonic()
                    if now - session_started >= RESTART_RESET_AFTER:
                        restart_times.clear()
                    restart_times = [stamp for stamp in restart_times if now - stamp <= RESTART_WINDOW_SECONDS]
                    restart_times.append(now)
                    if self.stop_event.is_set():
                        return
                    if len(restart_times) > MAX_RESTARTS_PER_WINDOW:
                        raise RuntimeError(f"10 分钟内自动恢复超过 3 次：{exc}")
                    self.messages.put(("status", f"检测到卡住：{exc}｜正在安全重开游戏窗口（10分钟窗口 {len(restart_times)}/3）"))
                    self.io.close_owned_game_window(hwnd, self._owned_game_pid(hwnd))
                    self.owned_game_windows.pop(int(hwnd), None)
                    self.stop_event.wait(1.0)
                    hwnd = 0
        except Exception as exc:
            self.messages.put(("status", f"已停止：{exc}"))
        finally:
            try:
                if tracker is not None:
                    tracker.save()
            except Exception:
                pass
            self.io.bind_input_guard(None)
            self.io.release_all()
            self.messages.put(("done", None))

    def _send_status(self, text):
        self.messages.put(("status", text))

    def stop(self):
        if not self.running:
            return
        self.stop_event.set()
        self.io.release_all()
        self.status.set("正在停止并释放按键…")

    def poll(self):
        if self.io.escape_down():
            self.stop()
        while True:
            try:
                kind, value = self.messages.get_nowait()
            except queue.Empty:
                break
            if kind == "status":
                self.status.set(value)
            elif kind == "done":
                self.running = False
                self.button.configure(state="normal", text="AI", bg="#16a56a")
                if self.status.get().startswith("正在停止"):
                    self.status.set("AI 已关闭｜点击 AI 可重新开始")
        self.root.after(45, self.poll)

    def close(self):
        if self.closing:
            return
        self.closing = True
        self.stop_event.set()
        self.shutdown_event.set()
        self.io.release_all()
        self.close_deadline = time.monotonic() + 3.0
        self.status.set("正在关闭并清理 OCR/工作线程…")
        self._finish_close()

    def _finish_close(self):
        worker_alive = bool(self.worker and self.worker.is_alive())
        if worker_alive and time.monotonic() < self.close_deadline:
            self.root.after(50, self._finish_close)
            return
        if self.escape_monitor and self.escape_monitor.is_alive():
            self.escape_monitor.join(0.10)
        self.io.release_all()
        self.root.destroy()


def cleanup_old_ocr_files(base_dir, older_than=600.0):
    now = time.time()
    try:
        for name in os.listdir(base_dir):
            if not (name.startswith(".ai_ocr_") and name.endswith(".bmp")):
                continue
            path = os.path.join(base_dir, name)
            try:
                if now - os.path.getmtime(path) >= older_than:
                    os.remove(path)
            except OSError:
                pass
    except OSError:
        pass


def main():
    if platform.system() != "Windows":
        raise SystemExit("本程序仅支持 Windows 11")
    enable_dpi_awareness()
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
