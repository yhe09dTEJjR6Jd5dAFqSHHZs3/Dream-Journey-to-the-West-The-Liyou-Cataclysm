import ctypes
import gzip
import heapq
import json
import math
import os
import random
import platform
import queue
import re
import shutil
import struct
import subprocess
import importlib
import tempfile
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox
from ctypes import wintypes
from dataclasses import dataclass
from enum import Enum, auto


APP_TITLE = "造梦西游之黎尤浩劫篇 AI"
FIREFOX_PATH = r"D:\FirefoxPortable\FirefoxPortable.exe"
GAME_URL = "https://h.api.4399.com/g.php?gameId=100072570"
RESTART_WINDOW_SECONDS = 600.0
MAX_RESTARTS_PER_WINDOW = 3
RESTART_RESET_AFTER = 300.0
_DEPENDENCY_LOCK = threading.RLock()
_DEPENDENCY_INSTALL_LOCK = threading.Lock()
_DEPENDENCY_JOBS = {}
_DEPENDENCY_FAILURES = set()


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", wintypes.LONG),
        ("top", wintypes.LONG),
        ("right", wintypes.LONG),
        ("bottom", wintypes.LONG),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class MONITORINFOEXW(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT), ("rcWork", RECT), ("dwFlags", wintypes.DWORD), ("szDevice", wintypes.WCHAR * 32)]


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("pt", POINT), ("mouseData", wintypes.DWORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]


class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", INPUTUNION)]


AI_INPUT_TAG = 0xA14C5EED


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", wintypes.LONG),
        ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class RGBQUAD(ctypes.Structure):
    _fields_ = [
        ("rgbBlue", ctypes.c_ubyte),
        ("rgbGreen", ctypes.c_ubyte),
        ("rgbRed", ctypes.c_ubyte),
        ("rgbReserved", ctypes.c_ubyte),
    ]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", RGBQUAD * 1)]


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", wintypes.DWORD),
        ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


@dataclass(frozen=True)
class RuntimeProfile:
    label: str
    sample_w: int
    sample_h: int
    loop_target: float
    ocr_interval: float
    ocr_max_width: int
    input_scale: float
    cores: int
    memory_gb: float
    gpu_name: str = ""
    gpu_vram_gb: float = 0.0
    gpu_tier: int = 0
    gpu_index: int = 0
    gpu_uuid: str = ""
    prefer_dxgi: bool = False
    physical_cores: int = 0
    cpu_mhz: int = 0
    on_battery: bool = False
    disk_total_gb: float = 0.0
    disk_free_gb: float = 0.0
    model_memory_limit: int = 4200
    model_context_limit: int = 640
    model_save_interval: float = 180.0


def _memory_status():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MEMORYSTATUSEX)]
        kernel32.GlobalMemoryStatusEx.restype = wintypes.BOOL
        if kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return status
    except Exception:
        pass
    return None


class SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_ = [
        ("ACLineStatus", ctypes.c_ubyte),
        ("BatteryFlag", ctypes.c_ubyte),
        ("BatteryLifePercent", ctypes.c_ubyte),
        ("SystemStatusFlag", ctypes.c_ubyte),
        ("BatteryLifeTime", wintypes.DWORD),
        ("BatteryFullLifeTime", wintypes.DWORD),
    ]


def _power_status():
    try:
        status = SYSTEM_POWER_STATUS()
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GetSystemPowerStatus.argtypes = [ctypes.POINTER(SYSTEM_POWER_STATUS)]
        kernel32.GetSystemPowerStatus.restype = wintypes.BOOL
        if kernel32.GetSystemPowerStatus(ctypes.byref(status)):
            return status.ACLineStatus == 0
    except Exception:
        pass
    return False


def _storage_status(path):
    try:
        usage = shutil.disk_usage(os.path.abspath(path or os.getcwd()))
        return usage.total / (1024.0 ** 3), usage.free / (1024.0 ** 3)
    except OSError:
        return 0.0, 0.0


def _resolve_firefox_path(script_dir):
    requested = str(os.environ.get("ZMYX_FIREFOX") or "").strip().strip('"')
    drive = os.path.splitdrive(os.path.abspath(script_dir))[0]
    candidates = [requested, FIREFOX_PATH]
    if drive:
        candidates.extend([os.path.join(drive + os.sep, "FirefoxPortable", "FirefoxPortable.exe"), os.path.join(drive + os.sep, "PortableApps", "FirefoxPortable", "FirefoxPortable.exe"), os.path.join(drive + os.sep, "FirefoxPortable.exe")])
    for letter in "DEFGHIJKLMNOPQRSTUVWXYZ":
        root = letter + ":\\"
        if not os.path.isdir(root):
            continue
        candidates.extend([os.path.join(root, "FirefoxPortable", "FirefoxPortable.exe"), os.path.join(root, "PortableApps", "FirefoxPortable", "FirefoxPortable.exe"), os.path.join(root, "Firefox", "firefox.exe"), os.path.join(root, "FirefoxPortable.exe")])
    candidates.extend([shutil.which("FirefoxPortable.exe") or "", shutil.which("firefox.exe") or ""])
    seen = set()
    for candidate in candidates:
        if not candidate:
            continue
        path = os.path.abspath(candidate)
        key = os.path.normcase(path)
        if key in seen:
            continue
        seen.add(key)
        if os.path.isfile(path):
            return path
    return requested or FIREFOX_PATH


def _select_data_dir(root, script_dir):
    initial = script_dir if os.path.splitdrive(os.path.abspath(script_dir))[0].upper() not in ("", "C:") else ("D:\\" if os.path.isdir("D:\\") else os.path.expanduser("~"))
    while True:
        selected = filedialog.askdirectory(parent=root, title="选择用于保存 AI 数据的非 C 盘文件夹", initialdir=initial, mustexist=True)
        if not selected:
            root.destroy()
            raise SystemExit("未选择数据目录")
        path = os.path.abspath(selected)
        drive = os.path.splitdrive(path)[0].upper()
        if not drive or drive == "C:":
            messagebox.showerror(APP_TITLE, "必须选择非 C 盘文件夹。", parent=root)
            initial = path
            continue
        probe = os.path.join(path, ".ai_write_probe.tmp")
        try:
            with open(probe, "wb") as handle:
                handle.write(b"ok")
            os.remove(probe)
            return path
        except OSError as exc:
            try:
                if os.path.exists(probe):
                    os.remove(probe)
            except OSError:
                pass
            messagebox.showerror(APP_TITLE, f"所选文件夹不可写：{exc}", parent=root)
            initial = path


def _detect_cpu_info():
    physical = max(1, int(os.cpu_count() or 4) // 2)
    logical = max(1, int(os.cpu_count() or 4))
    mhz = 0
    try:
        command = (
            "$ErrorActionPreference='SilentlyContinue';"
            "$p=Get-CimInstance Win32_Processor | Select-Object NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed;"
            "if($p){$p | ConvertTo-Json -Compress}"
        )
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=2.5, creationflags=flags,
        )
        text = (result.stdout or "").strip()
        if text:
            data = json.loads(text)
            rows = data if isinstance(data, list) else [data]
            physical = max(1, sum(max(0, int(row.get("NumberOfCores") or 0)) for row in rows))
            logical = max(1, sum(max(0, int(row.get("NumberOfLogicalProcessors") or 0)) for row in rows))
            mhz = max([max(0, int(row.get("MaxClockSpeed") or 0)) for row in rows] or [0])
    except Exception:
        pass
    return physical, logical, mhz

def _detect_gpu_info():
    name = ""
    vram_gb = 0.0
    gpu_index = 0
    gpu_uuid = ""
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=index,uuid,name,memory.total,memory.free,utilization.gpu", "--format=csv,noheader,nounits"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=2.5, creationflags=flags,
        )
        rows = []
        for line in (result.stdout or "").strip().splitlines():
            parts = [part.strip() for part in line.split(",", 5)]
            if len(parts) != 6:
                continue
            index, uuid, gpu_name, total_mb, free_mb, util = parts
            total_mb = max(0.0, float(total_mb))
            free_mb = max(0.0, float(free_mb))
            util = max(0.0, min(100.0, float(util)))
            score = free_mb * 1.35 + total_mb * 0.65 - util * 32.0
            rows.append((score, total_mb, int(index), uuid, gpu_name))
        if rows:
            rows.sort(reverse=True)
            _, total_mb, gpu_index, gpu_uuid, name = rows[0]
            vram_gb = total_mb / 1024.0
    except Exception:
        pass
    if not name:
        try:
            command = (
                "$ErrorActionPreference='SilentlyContinue';"
                "$g=Get-CimInstance Win32_VideoController | "
                "Where-Object {$_.Name -notmatch 'Microsoft Basic|Remote Display'} | "
                "Sort-Object AdapterRAM -Descending | Select-Object -First 1 Name,AdapterRAM;"
                "if($g){$g | ConvertTo-Json -Compress}"
            )
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=3.0, creationflags=flags,
            )
            text = (result.stdout or "").strip()
            if text:
                data = json.loads(text)
                name = str(data.get("Name") or "").strip()
                ram = float(data.get("AdapterRAM") or 0.0)
                if ram > 0:
                    vram_gb = ram / (1024.0 ** 3)
        except Exception:
            pass
    upper = name.upper()
    tier = 0
    if "NVIDIA" in upper:
        tier = 3 if vram_gb >= 4.0 or "RTX" in upper else 2
    elif any(token in upper for token in ("RADEON RX", "ARC A", "QUADRO", "RTX A")):
        tier = 3
    elif any(token in upper for token in ("GTX", "RADEON", "ARC", "VEGA", "IRIS XE")):
        tier = 2
    elif any(token in upper for token in ("INTEL", "AMD")):
        tier = 1
    if vram_gb >= 12.0:
        tier = max(tier, 4)
    elif vram_gb >= 6.0:
        tier = max(tier, 3)
    elif vram_gb >= 2.0:
        tier = max(tier, 2)
    return name, vram_gb, tier, gpu_index, gpu_uuid


def detect_runtime_profile(data_dir=None):
    physical_cores, cores, cpu_mhz = _detect_cpu_info()
    status = _memory_status()
    memory_gb = status.ullTotalPhys / (1024.0 ** 3) if status else 0.0
    pointer_bits = ctypes.sizeof(ctypes.c_void_p) * 8
    gpu_name, gpu_vram_gb, gpu_tier, gpu_index, gpu_uuid = _detect_gpu_info()
    on_battery = _power_status()
    disk_total_gb, disk_free_gb = _storage_status(data_dir or os.path.dirname(os.path.abspath(__file__)))

    memory_score = 1.0 if memory_gb <= 0.0 else min(5.0, memory_gb / 4.0)
    cpu_score = physical_cores * 0.78 + cores * 0.22
    if cpu_mhz > 0:
        cpu_score *= max(0.72, min(1.28, cpu_mhz / 3600.0))
    gpu_score = gpu_tier * 1.25 + min(2.0, gpu_vram_gb / 4.0)
    total_score = cpu_score + memory_score + gpu_score
    if on_battery:
        total_score -= 1.6

    prefer_dxgi = (
        pointer_bits >= 64 and gpu_tier >= 1 and cores >= 4
        and (memory_gb <= 0.0 or memory_gb >= 5.0) and not on_battery
    )

    resource = max(0.0, total_score)
    gpu_headroom = min(1.0, max(0.0, gpu_vram_gb) / 24.0) if gpu_tier >= 2 else 0.0
    cpu_headroom = min(1.0, max(0.0, physical_cores - 2) / 14.0)
    memory_headroom = 0.45 if memory_gb <= 0.0 else min(1.0, max(0.0, memory_gb - 4.0) / 28.0)
    sample_w = int(round((208.0 + resource * 13.0 + 196.0 * gpu_headroom + 52.0 * memory_headroom + max(0.0, gpu_vram_gb - 8.0) * 8.0) / 8.0) * 8)
    sample_w = max(208, sample_w)
    sample_h = max(117, int(round(sample_w * 9.0 / 16.0)))
    loop_target = max(0.024, min(0.110, 0.118 - resource * 0.0048 - gpu_headroom * 0.018))
    ocr_interval = max(0.48, min(1.65, 1.48 - resource * 0.045 - gpu_headroom * 0.30))
    ocr_max_width = int(max(1024, min(2560, 1050 + resource * 48 + gpu_vram_gb * 34)))
    input_scale = max(0.80, min(1.08, 1.07 - resource * 0.010))
    label = "在线自适应"
    if on_battery:
        loop_target *= 1.22
        ocr_interval *= 1.25
        sample_w = max(208, int(sample_w * 0.82) // 8 * 8)
        sample_h = max(117, int(round(sample_w * 9.0 / 16.0)))

    model_memory_limit = int(3600 + max(0.0, memory_gb) * 220 + max(0.0, gpu_vram_gb) * 310 + max(0, cores) * 80)
    model_context_limit = int(700 + max(0.0, memory_gb) * 38 + max(0.0, gpu_vram_gb) * 74 + max(0, cores) * 24)
    model_save_interval = max(120.0, min(300.0, 145.0 + model_memory_limit / 130.0))
    if memory_gb >= 32.0 and disk_free_gb >= 40.0:
        model_memory_limit = int(model_memory_limit * 1.25)
        model_context_limit = int(model_context_limit * 1.20)
    if disk_free_gb > 0.0:
        if disk_free_gb < 1.5:
            model_memory_limit = min(model_memory_limit, 3200)
            model_context_limit = min(model_context_limit, 600)
            model_save_interval = max(model_save_interval, 420.0)
        elif disk_free_gb < 5.0:
            model_memory_limit = min(model_memory_limit, 5200)
            model_context_limit = min(model_context_limit, 1000)
            model_save_interval = max(model_save_interval, 300.0)
        elif disk_free_gb >= 250.0 and memory_gb >= 24.0:
            model_memory_limit = int(model_memory_limit * 1.15)
            model_context_limit = int(model_context_limit * 1.12)

    return RuntimeProfile(
        label=label, sample_w=sample_w, sample_h=sample_h, loop_target=loop_target,
        ocr_interval=ocr_interval, ocr_max_width=ocr_max_width,
        input_scale=input_scale, cores=cores, memory_gb=memory_gb, gpu_name=gpu_name,
        gpu_vram_gb=gpu_vram_gb, gpu_tier=gpu_tier, gpu_index=gpu_index, gpu_uuid=gpu_uuid, prefer_dxgi=prefer_dxgi,
        physical_cores=physical_cores, cpu_mhz=cpu_mhz, on_battery=on_battery,
        disk_total_gb=disk_total_gb, disk_free_gb=disk_free_gb,
        model_memory_limit=max(3000, model_memory_limit),
        model_context_limit=max(500, model_context_limit),
        model_save_interval=max(90.0, model_save_interval),
    )


def _dependency_dir(base_dir):
    path = os.path.join(os.path.abspath(base_dir), ".ai_deps")
    if path not in sys.path:
        sys.path.insert(0, path)
    return path


def _dependency_jobs_active(base_dir=None):
    root = os.path.normcase(os.path.abspath(base_dir)) if base_dir else None
    with _DEPENDENCY_LOCK:
        dead = [key for key, thread in _DEPENDENCY_JOBS.items() if not thread.is_alive()]
        for key in dead:
            _DEPENDENCY_JOBS.pop(key, None)
        return any(thread.is_alive() and (root is None or key[0] == root) for key, thread in _DEPENDENCY_JOBS.items())


def _dependency_job_named(base_dir, names):
    root = os.path.normcase(os.path.abspath(base_dir))
    names = tuple(str(name) for name in names)
    with _DEPENDENCY_LOCK:
        for key, thread in _DEPENDENCY_JOBS.items():
            if key[0] == root and thread.is_alive() and any(key[1].startswith(name) for name in names):
                return True
    return False


def _cuda_environment_key(profile=None):
    if profile is None:
        gpu_name, _, _, _, gpu_uuid = _detect_gpu_info()
    else:
        gpu_name = str(getattr(profile, "gpu_name", "") or "")
        gpu_uuid = str(getattr(profile, "gpu_uuid", "") or "")
    return "|".join((os.path.normcase(os.path.abspath(sys.executable)), platform.python_version(), gpu_uuid, gpu_name))


def _cuda_marker_path(base_dir):
    return os.path.join(os.path.abspath(base_dir), ".ai_cuda_status.json")


def _cuda_marker_blocks(base_dir, profile=None):
    key = _cuda_environment_key(profile)
    if key in _DEPENDENCY_FAILURES:
        return True
    try:
        with open(_cuda_marker_path(base_dir), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict) or data.get("environment") != key or bool(data.get("cuda_ok")):
            return False
        stamp = float(data.get("checked_at", 0.0) or 0.0)
        if time.time() - stamp <= 7 * 24 * 3600:
            _DEPENDENCY_FAILURES.add(key)
            return True
    except Exception:
        pass
    return False


def _record_cuda_status(base_dir, ok, detail="", profile=None):
    key = _cuda_environment_key(profile)
    if ok:
        _DEPENDENCY_FAILURES.discard(key)
    else:
        _DEPENDENCY_FAILURES.add(key)
    path = _cuda_marker_path(base_dir)
    tmp = path + ".tmp"
    try:
        data = {"environment": key, "cuda_ok": bool(ok), "checked_at": time.time(), "detail": str(detail or "")[:240]}
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, path)
    except OSError:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass


def _torch_cuda_smoke(base_dir, record=True):
    target = _dependency_dir(base_dir)
    env = os.environ.copy()
    prior = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = target + (os.pathsep + prior if prior else "")
    code = "import torch,sys; ok=bool(torch.cuda.is_available()); print('1' if ok else '0'); sys.exit(0 if ok else 3)"
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run([sys.executable, "-c", code], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=25.0, creationflags=flags, env=env, cwd=target)
        ok = result.returncode == 0 and (result.stdout or "").strip().endswith("1")
        detail = (result.stderr or result.stdout or "").strip()[-220:]
        if record:
            _record_cuda_status(base_dir, ok, detail)
        return ok
    except Exception as exc:
        if record:
            _record_cuda_status(base_dir, False, repr(exc))
        return False


def _install_optional_worker(name, base_dir, install, stop_event, timeout, key):
    target = _dependency_dir(base_dir)
    temp_root = os.path.join(os.path.abspath(base_dir), ".ai_tmp")
    process = None
    acquired = False
    try:
        os.makedirs(target, exist_ok=True)
        os.makedirs(temp_root, exist_ok=True)
        if str(name).startswith("torch_cuda") and _torch_cuda_smoke(base_dir, record=False):
            _record_cuda_status(base_dir, True, "existing")
            return
        while not acquired:
            if stop_event is not None and stop_event.is_set():
                return
            acquired = _DEPENDENCY_INSTALL_LOCK.acquire(timeout=0.10)
        if stop_event is not None and stop_event.is_set():
            return
        env = os.environ.copy()
        env["TMP"] = temp_root
        env["TEMP"] = temp_root
        env["TMPDIR"] = temp_root
        env["PIP_CACHE_DIR"] = temp_root
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        process = subprocess.Popen(
            [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-input", "--no-cache-dir", "--target", target] + list(install),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags, env=env, cwd=temp_root,
        )
        deadline = time.monotonic() + max(30.0, float(timeout))
        while process.poll() is None:
            if (stop_event is not None and stop_event.is_set()) or time.monotonic() >= deadline:
                process.terminate()
                try:
                    process.wait(2.0)
                except Exception:
                    process.kill()
                if str(name).startswith("torch_cuda") and not (stop_event is not None and stop_event.is_set()):
                    _DEPENDENCY_FAILURES.add(_cuda_environment_key())
                return
            time.sleep(0.10)
        if process.returncode == 0:
            importlib.invalidate_caches()
            if str(name).startswith("torch_cuda"):
                _torch_cuda_smoke(base_dir)
        elif str(name).startswith("torch_cuda"):
            _DEPENDENCY_FAILURES.add(_cuda_environment_key())
    except Exception:
        if str(name).startswith("torch_cuda"):
            _DEPENDENCY_FAILURES.add(_cuda_environment_key())
        if process is not None and process.poll() is None:
            try:
                process.kill()
            except Exception:
                pass
    finally:
        if acquired:
            try:
                _DEPENDENCY_INSTALL_LOCK.release()
            except RuntimeError:
                pass
        with _DEPENDENCY_LOCK:
            _DEPENDENCY_JOBS.pop(key, None)


def _schedule_optional_install(name, base_dir, install, stop_event, timeout):
    root = os.path.normcase(os.path.abspath(base_dir))
    key = (root, str(name))
    with _DEPENDENCY_LOCK:
        current = _DEPENDENCY_JOBS.get(key)
        if current is not None and current.is_alive():
            return
        thread = threading.Thread(target=_install_optional_worker, args=(name, base_dir, tuple(install), stop_event, timeout, key), daemon=True)
        _DEPENDENCY_JOBS[key] = thread
        thread.start()


def _import_optional(name, base_dir, install=None, stop_event=None, timeout=180.0):
    if stop_event is not None and stop_event.is_set():
        return None
    if base_dir:
        _dependency_dir(base_dir)
        if name == "torch" and _dependency_job_named(base_dir, ("torch_cuda",)):
            return None
        if name in ("numpy", "dxcam") and _dependency_job_named(base_dir, ("dxcam_bundle",)):
            return None
    try:
        return importlib.import_module(name)
    except Exception:
        pass
    if not base_dir or not install or str(os.environ.get("ZMYX_AUTO_DEPS", "1")).strip().lower() in ("0", "false", "no"):
        return None
    _schedule_optional_install(name, base_dir, install, stop_event, timeout)
    return None


def _ensure_dxcam(base_dir, stop_event=None):
    np_mod = _import_optional("numpy", base_dir, None, stop_event, 120.0)
    dxcam_mod = _import_optional("dxcam", base_dir, None, stop_event, 120.0)
    if dxcam_mod is None or np_mod is None:
        if base_dir and (stop_event is None or not stop_event.is_set()) and str(os.environ.get("ZMYX_AUTO_DEPS", "1")).strip().lower() not in ("0", "false", "no"):
            _schedule_optional_install("dxcam_bundle", base_dir, ("numpy", "dxcam"), stop_event, 180.0)
        return None, None
    return dxcam_mod, np_mod


def _prepare_ai_dependencies(base_dir, profile, stop_event=None):
    if str(os.environ.get("ZMYX_AUTO_DEPS", "1")).strip().lower() in ("0", "false", "no"):
        return
    if stop_event is not None and stop_event.is_set():
        return
    _dependency_dir(base_dir)
    if bool(getattr(profile, "prefer_dxgi", False)):
        try:
            numpy_ready = importlib.util.find_spec("numpy") is not None
            dxcam_ready = importlib.util.find_spec("dxcam") is not None
        except Exception:
            numpy_ready = dxcam_ready = False
        if not numpy_ready or not dxcam_ready:
            _schedule_optional_install("dxcam_bundle", base_dir, ("numpy", "dxcam"), stop_event, 240.0)
    gpu_name = str(getattr(profile, "gpu_name", "") or "")
    vram = max(0.0, float(getattr(profile, "gpu_vram_gb", 0.0) or 0.0))
    disk_free = max(0.0, float(getattr(profile, "disk_free_gb", 0.0) or 0.0))
    cuda_candidate = "NVIDIA" in gpu_name.upper() and vram >= 4.0 and (disk_free <= 0.0 or disk_free >= 12.0) and not bool(getattr(profile, "on_battery", False))
    if cuda_candidate and not _cuda_marker_blocks(base_dir, profile):
        _schedule_optional_install("torch_cuda", base_dir, ("torch",), stop_event, 600.0)


class RuntimeGovernor:
    def __init__(self, profile):
        self.profile = profile
        self.process_ema = profile.loop_target * 0.55
        self.plan_ema = 0.0
        self.ocr_scale = 1.0
        self.overruns = 0
        self.healthy = 0
        self.cycles = 0
        self.cpu_load = 0.0
        self.memory_load = 0.0
        self.last_plan_depth = 1
        self.dynamic_input_scale = profile.input_scale
        self.dynamic_loop_target = profile.loop_target
        self.candidate_budget = max(6, 4 + max(1, int(profile.cores)) // 2 + int(max(0.0, float(profile.gpu_vram_gb)) / 2.0))
        self.mode = "电池节能" if profile.on_battery else "正常"
        self._last_system_sample = 0.0
        self._system_times = None
        try:
            self._kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            self._kernel32.GetSystemTimes.argtypes = [ctypes.POINTER(wintypes.FILETIME), ctypes.POINTER(wintypes.FILETIME), ctypes.POINTER(wintypes.FILETIME)]
            self._kernel32.GetSystemTimes.restype = wintypes.BOOL
        except Exception:
            self._kernel32 = None

    @staticmethod
    def _filetime_value(value):
        return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)

    def _sample_system(self):
        now = time.monotonic()
        if now - self._last_system_sample < 0.75:
            return
        self._last_system_sample = now
        status = _memory_status()
        if status:
            self.memory_load = max(0.0, min(1.0, float(status.dwMemoryLoad) / 100.0))
        if not self._kernel32:
            return
        idle = wintypes.FILETIME()
        kernel = wintypes.FILETIME()
        user = wintypes.FILETIME()
        try:
            if not self._kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
                return
            values = tuple(self._filetime_value(item) for item in (idle, kernel, user))
            if self._system_times is not None:
                di = values[0] - self._system_times[0]
                dk = values[1] - self._system_times[1]
                du = values[2] - self._system_times[2]
                total = max(1, dk + du)
                self.cpu_load = max(0.0, min(1.0, 1.0 - di / total))
            self._system_times = values
        except Exception:
            pass

    @property
    def ocr_interval(self):
        return self.profile.ocr_interval * self.ocr_scale

    @property
    def estimated_hz(self):
        return 1.0 / max(self.dynamic_loop_target, self.process_ema, 0.001)

    @property
    def planning_depth(self):
        return self.last_plan_depth

    @property
    def planning_budget(self):
        target = max(0.006, self.dynamic_loop_target)
        nonplan = max(0.0, self.process_ema - self.plan_ema)
        headroom = max(target * 0.16, target - min(target * 0.86, nonplan))
        load = max(self.cpu_load, self.memory_load)
        load_scale = 0.72 if load > 0.92 else 0.84 if load > 0.84 else 1.0
        if self.profile.on_battery:
            load_scale *= 0.78
        return max(0.0025, min(target * 0.62, headroom * 0.74 * load_scale))

    @property
    def input_scale(self):
        return self.dynamic_input_scale

    def note_planning(self, elapsed, depth, complete=True):
        elapsed = max(0.0, float(elapsed))
        self.plan_ema = elapsed if self.plan_ema <= 0.0 else self.plan_ema * 0.84 + elapsed * 0.16
        self.last_plan_depth = max(1, int(depth or 1))
        budget = max(0.0025, self.planning_budget)
        if not complete or elapsed > budget * 1.10:
            self.candidate_budget = max(5, self.candidate_budget - 1)
        elif self.last_plan_depth >= 3 and elapsed < budget * 0.88:
            self.candidate_budget = max(self.candidate_budget + 1, int(self.candidate_budget * 1.06))

    def finish(self, elapsed):
        elapsed = max(0.0, float(elapsed))
        self.cycles += 1
        self.process_ema = self.process_ema * 0.91 + elapsed * 0.09
        self._sample_system()
        base = max(self.profile.loop_target, 0.001)
        pressure = max(self.process_ema / max(self.dynamic_loop_target, 0.001), self.cpu_load / 0.84 if self.cpu_load else 0.0, self.memory_load / 0.88 if self.memory_load else 0.0)
        if pressure > 1.52:
            self.overruns += 2
            self.healthy = 0
        elif pressure > 1.18:
            self.overruns += 1
            self.healthy = max(0, self.healthy - 2)
        elif pressure < 0.74:
            self.overruns = max(0, self.overruns - 1)
            self.healthy += 1
        else:
            self.overruns = max(0, self.overruns - 1)
            self.healthy = max(0, self.healthy - 1)
        if self.overruns >= 8:
            severe = pressure > 1.48 or self.memory_load > 0.93
            self.ocr_scale = min(3.6, self.ocr_scale * (1.18 if severe else 1.10))
            self.candidate_budget = max(5, self.candidate_budget - (2 if severe else 1))
            self.dynamic_input_scale = min(1.16, self.dynamic_input_scale * 1.018)
            cap = base * (2.15 if severe else 1.72)
            self.dynamic_loop_target = min(cap, self.dynamic_loop_target * (1.14 if severe else 1.07))
            self.mode = "强降载" if severe else "降载"
            self.overruns = 0
        elif self.healthy >= 75:
            self.ocr_scale = max(0.84, self.ocr_scale * 0.94)
            self.candidate_budget = max(self.candidate_budget + 1, int(self.candidate_budget * 1.06))
            self.dynamic_input_scale += (self.profile.input_scale - self.dynamic_input_scale) * 0.38
            floor = base * (1.0 if not self.profile.on_battery else 1.08)
            self.dynamic_loop_target = max(floor, self.dynamic_loop_target * 0.94)
            self.mode = "提质"
            self.healthy = 0
        elif self.cycles % 140 == 0 and self.mode not in ("强降载", "电池节能"):
            self.mode = "正常"
        if self.profile.on_battery:
            self.dynamic_loop_target = max(self.dynamic_loop_target, base * 1.05)
        return max(0.004, self.dynamic_loop_target - elapsed)


def enable_dpi_awareness():

    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        if hasattr(user32, "SetProcessDpiAwarenessContext"):
            user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
            return
    except Exception:
        pass
    try:
        ctypes.WinDLL("shcore", use_last_error=True).SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.WinDLL("user32", use_last_error=True).SetProcessDPIAware()
        except Exception:
            pass


class GameState(Enum):
    LOADING = auto()
    HOME = auto()
    SELECT_STAGE = auto()
    COMBAT = auto()
    REWARD = auto()
    EQUIPMENT = auto()
    UPGRADE = auto()
    RETRY = auto()
    UNKNOWN = auto()


STATE_NAMES = {
    GameState.LOADING: "加载",
    GameState.HOME: "主城/主页",
    GameState.SELECT_STAGE: "选择关卡",
    GameState.COMBAT: "战斗",
    GameState.REWARD: "奖励",
    GameState.EQUIPMENT: "装备",
    GameState.UPGRADE: "强化",
    GameState.RETRY: "死亡/重试",
    GameState.UNKNOWN: "未知界面",
}


class RestartGame(RuntimeError):
    pass


class PersistenceMonitor:
    def __init__(self, send_status):
        self.send_status = send_status
        self.failures = set()
        self.lock = threading.RLock()

    def fail(self, source, exc):
        with self.lock:
            first = not self.failures
            self.failures.add(str(source))
        if first:
            self.send_status(f"经验保存失败：{exc}｜AI 继续运行并自动重试，不写日志")

    @property
    def failed(self):
        with self.lock:
            return bool(self.failures)

    def ok(self, source):
        with self.lock:
            had = bool(self.failures)
            self.failures.discard(str(source))
            recovered = had and not self.failures
        if recovered:
            self.send_status("经验保存已恢复")


@dataclass(frozen=True)
class OCRWord:
    text: str
    x: float
    y: float
    w: float
    h: float
    line: int = -1

    @property
    def cx(self):
        return self.x + self.w / 2.0

    @property
    def cy(self):
        return self.y + self.h / 2.0


@dataclass
class OCRSnapshot:
    text: str
    words: tuple
    width: int
    height: int
    captured_at: float


@dataclass
class PendingAction:
    kind: str
    state: GameState
    fingerprint: tuple
    at: float
    power_before: int
    completed: bool = False


@dataclass
class StageStats:
    attempts: int = 0
    wins: int = 0
    total_seconds: float = 0.0
    stuck_events: int = 0

    @property
    def success_rate(self):
        return self.wins / self.attempts if self.attempts else 0.0

    @property
    def average_seconds(self):
        return self.total_seconds / self.wins if self.wins else 9999.0


@dataclass
class ActionStats:
    attempts: int = 0
    successes: int = 0
    failures: int = 0
    total_power_delta: int = 0
    total_seconds: float = 0.0

    @property
    def success_rate(self):
        return self.successes / self.attempts if self.attempts else 0.0

    @property
    def average_delta(self):
        return self.total_power_delta / self.successes if self.successes else 0.0

    @property
    def average_seconds(self):
        return self.total_seconds / self.attempts if self.attempts else 5.0


@dataclass
class CombatObservation:
    hp_ratio: object = None
    mp_ratio: object = None
    boss_ratio: object = None
    player_x: object = None
    enemy_x: object = None
    motion: float = 0.0
    player_y: object = None
    enemy_y: object = None


@dataclass
class WorldState:
    hp: object = None
    mp: object = None
    boss: object = None
    player_x: object = None
    target_x: object = None
    distance: object = None
    target_side: float = 0.0
    motion: float = 0.0
    scene_change: float = 0.0
    novelty: float = 0.0
    flow_x: float = 0.0
    flow_y: float = 0.0
    crowd: float = 0.0
    edge_energy: float = 0.0
    active_x: float = 0.5
    active_y: float = 0.55
    threat: float = 0.0
    incoming: float = 0.0
    dealt: float = 0.0
    combo: float = 0.0
    engaged: float = 0.0
    advantage: float = 0.5
    progress: float = 0.0
    telegraph: float = 0.0
    escape_side: float = 0.0
    opening: float = 0.0
    phase_shift: float = 0.0
    risk_trend: float = 0.0
    impact_risk: float = 0.0
    latent: tuple = ()
    fingerprint: tuple = ()
    captured_at: float = 0.0


class CudaVisualEncoder:
    VERSION = 2
    PRIMITIVES = ("A", "D", "W", "S", "F", "H", "J", "K", "U", "I", "O", "L", "Z", "SPACE")

    def __init__(self, base_dir, profile, width, height, stop_event=None):
        self.active = False
        self.base_dir = os.path.abspath(base_dir)
        self.path = os.path.join(self.base_dir, ".ai_visual_encoder.pt")
        self.profile = profile
        self.width = int(width)
        self.height = int(height)
        self.stop_event = stop_event
        self.torch = None
        self.np = None
        self.device = None
        self.lock = threading.Lock()
        self.queue = queue.Queue(maxsize=512)
        self.shutdown = threading.Event()
        self.thread = None
        self.steps = 0
        self.loss_ema = 1.0
        self.effect_dim = 13
        self.action_dim = len(self.PRIMITIVES) + 6
        vram = max(0.0, float(getattr(profile, "gpu_vram_gb", 0.0) or 0.0))
        capacity = max(0.0, math.sqrt(vram) + vram * 0.28)
        self.latent_dim = max(18, min(72, int(round((18.0 + capacity * 4.2) / 6.0)) * 6))
        self.c1 = max(16, min(48, int(round((16.0 + capacity * 2.4) / 8.0)) * 8))
        self.c2 = max(self.c1 + 8, min(72, self.c1 + 8 + int(capacity * 1.7 // 8) * 8))
        self.c3 = max(self.c2 + 8, min(104, self.c2 + 8 + int(capacity * 1.8 // 8) * 8))
        base_input = max(64, min(192, int(round((64.0 + vram * 5.5 + math.sqrt(max(1.0, vram)) * 7.0) / 8.0)) * 8))
        self.input_w = min(self.width, base_input)
        self.input_h = max(36, min(self.height, int(round(self.input_w * self.height / max(1.0, float(self.width))))))
        gpu_name = str(getattr(profile, "gpu_name", "") or "")
        if "NVIDIA" not in gpu_name.upper() or vram < 4.0 or bool(getattr(profile, "on_battery", False)) or _cuda_marker_blocks(base_dir, profile):
            return
        torch = _import_optional("torch", base_dir, None, stop_event, 120.0)
        np = _import_optional("numpy", base_dir, None, stop_event, 120.0)
        if torch is None or np is None:
            return
        try:
            index = max(0, int(getattr(profile, "gpu_index", 0) or 0))
            if not torch.cuda.is_available():
                return
            if index >= int(torch.cuda.device_count()):
                index = 0
            self.torch = torch
            self.np = np
            self.device = torch.device(f"cuda:{index}")
            pool_h = 3 if vram < 10.0 else 4
            pool_w = 4 if vram < 10.0 else 5
            self.pool_h = pool_h
            self.pool_w = pool_w
            self.encoder = torch.nn.Sequential(
                torch.nn.Conv2d(3, self.c1, 5, stride=2, padding=2), torch.nn.SiLU(),
                torch.nn.Conv2d(self.c1, self.c2, 3, stride=2, padding=1), torch.nn.SiLU(),
                torch.nn.Conv2d(self.c2, self.c3, 3, stride=2, padding=1), torch.nn.SiLU(),
                torch.nn.AdaptiveAvgPool2d((pool_h, pool_w)), torch.nn.Flatten(),
                torch.nn.Linear(self.c3 * pool_h * pool_w, self.latent_dim), torch.nn.Sigmoid(),
            ).to(self.device)
            hidden = max(128, min(512, int(round((self.latent_dim * 5.0 + vram * 12.0) / 32.0)) * 32))
            self.predictor = torch.nn.Sequential(
                torch.nn.Linear(self.latent_dim + self.action_dim, hidden), torch.nn.SiLU(),
                torch.nn.Linear(hidden, hidden), torch.nn.SiLU(),
                torch.nn.Linear(hidden, self.latent_dim + self.effect_dim + 1),
            ).to(self.device)
            self.decoder = torch.nn.Sequential(
                torch.nn.Linear(self.latent_dim, hidden), torch.nn.SiLU(),
                torch.nn.Linear(hidden, 3 * 9 * 16), torch.nn.Sigmoid(),
            ).to(self.device)
            params = list(self.encoder.parameters()) + list(self.predictor.parameters()) + list(self.decoder.parameters())
            self.optimizer = torch.optim.AdamW(params, lr=max(1.5e-4, 4.5e-4 / math.sqrt(max(1.0, vram / 4.0))), weight_decay=1e-5)
            self.batch_size = max(8, min(64, int(8 + vram * 2.0)))
            self._tune_input_resolution()
            self.active = True
            self._load()
            self.thread = threading.Thread(target=self._train_loop, daemon=True)
            self.thread.start()
        except Exception:
            self.active = False
            self.torch = None
            self.np = None
            self.device = None

    def _tune_input_resolution(self):
        torch = self.torch
        if torch is None:
            return
        cap = min(self.width, 224)
        target = max(0.0015, min(0.006, float(getattr(self.profile, "loop_target", 0.06)) * 0.14))
        try:
            for _ in range(3):
                x = torch.zeros((1, 3, self.input_h, self.input_w), dtype=torch.float32, device=self.device)
                for _ in range(2):
                    self.encoder(x)
                torch.cuda.synchronize(self.device)
                samples = []
                for _ in range(5):
                    started = time.perf_counter()
                    self.encoder(x)
                    torch.cuda.synchronize(self.device)
                    samples.append(time.perf_counter() - started)
                elapsed = sorted(samples)[len(samples) // 2]
                if elapsed > target * 1.20 and self.input_w > 64:
                    self.input_w = max(64, int(self.input_w * 0.82) // 8 * 8)
                elif elapsed < target * 0.48 and self.input_w < cap:
                    self.input_w = min(cap, max(self.input_w + 8, int(self.input_w * 1.20) // 8 * 8))
                else:
                    break
                self.input_h = max(36, min(self.height, int(round(self.input_w * self.height / max(1.0, float(self.width))))))
        except Exception:
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass

    def _small_rgb(self, frame):
        np = self.np
        if np is None or not frame:
            return None
        try:
            image = np.frombuffer(frame, dtype=np.uint8).reshape(self.height, self.width, 4)
            ys = np.linspace(0, self.height - 1, self.input_h).astype(np.intp)
            xs = np.linspace(0, self.width - 1, self.input_w).astype(np.intp)
            bgr = image[ys[:, None], xs[None, :], :3]
            return np.ascontiguousarray(bgr[..., ::-1])
        except Exception:
            return None

    def _action_vector(self, action, components=None, timing=None):
        values = [0.0] * self.action_dim
        pieces = tuple(str(x) for x in (components or ()))
        text = str(action or "")
        for index, key in enumerate(self.PRIMITIVES):
            if key in pieces or text == key or key in re.findall(r"SPACE|[ADWSFHJKUIOLZ]", text):
                values[index] = 1.0
        base = len(self.PRIMITIVES)
        values[base] = 1.0 if "TOWARD" in text or "CHASE" in text else 0.0
        values[base + 1] = 1.0 if "RETREAT" in text else 0.0
        values[base + 2] = 1.0 if "EVADE" in text else 0.0
        values[base + 3] = min(1.0, max(0.0, (len(pieces) - 1) / 4.0)) if pieces else (1.0 if len(text) > 1 else 0.0)
        timing = timing or {}
        values[base + 4] = max(0.0, min(1.0, float(timing.get("down", 1.0)) / 1.8))
        values[base + 5] = max(0.0, min(1.0, float(timing.get("gap", 1.0)) / 1.8))
        return values

    def encode(self, frame):
        if not self.active or self.torch is None:
            return None
        small = self._small_rgb(frame)
        if small is None or not self.lock.acquire(blocking=False):
            return None
        try:
            torch = self.torch
            with torch.no_grad():
                x = torch.as_tensor(small, dtype=torch.float32, device=self.device).permute(2, 0, 1).unsqueeze(0) / 255.0
                latent = self.encoder(x).squeeze(0).detach().float().cpu().tolist()
            return tuple(max(0.0, min(1.0, float(v))) for v in latent)
        except Exception:
            return None
        finally:
            self.lock.release()

    def observe_transition(self, before_frame, after_frame, action, effect, value_target=0.0, components=None, timing=None):
        if not self.active or self.np is None or before_frame is None or after_frame is None:
            return
        before = self._small_rgb(before_frame)
        after = self._small_rgb(after_frame)
        if before is None or after is None:
            return
        action_vec = self.np.asarray(self._action_vector(action, components, timing), dtype=self.np.float32)
        effect_vec = self.np.asarray([max(-1.0, min(1.0, float(x))) for x in tuple(effect or ())[:self.effect_dim]], dtype=self.np.float32)
        if effect_vec.shape[0] < self.effect_dim:
            effect_vec = self.np.pad(effect_vec, (0, self.effect_dim - effect_vec.shape[0]))
        item = (before.copy(), after.copy(), action_vec, effect_vec, max(-1.0, min(1.0, float(value_target))))
        try:
            self.queue.put_nowait(item)
        except queue.Full:
            try:
                self.queue.get_nowait()
                self.queue.put_nowait(item)
            except Exception:
                pass

    def _load(self):
        if not os.path.isfile(self.path):
            return
        try:
            data = self.torch.load(self.path, map_location="cpu", weights_only=True)
            meta = data.get("meta") if isinstance(data, dict) else None
            if not isinstance(data, dict) or int(data.get("version", 0)) != self.VERSION or not isinstance(meta, dict):
                return
            expected = (self.latent_dim, self.c1, self.c2, self.c3, self.action_dim, self.effect_dim)
            loaded = tuple(int(meta.get(key, -1)) for key in ("latent", "c1", "c2", "c3", "action_dim", "effect_dim"))
            if loaded != expected:
                return
            self.encoder.load_state_dict(data.get("encoder") or {})
            self.predictor.load_state_dict(data.get("predictor") or {})
            self.decoder.load_state_dict(data.get("decoder") or {})
            optimizer = data.get("optimizer")
            if isinstance(optimizer, dict):
                self.optimizer.load_state_dict(optimizer)
                for state in self.optimizer.state.values():
                    for key, value in list(state.items()):
                        if self.torch.is_tensor(value):
                            state[key] = value.to(self.device)
            self.steps = max(0, int(data.get("steps", 0)))
            self.loss_ema = max(0.0, min(20.0, float(data.get("loss_ema", 1.0))))
        except Exception:
            try:
                os.replace(self.path, self.path + f".rejected.{int(time.time())}")
            except OSError:
                pass

    def _save(self):
        if not self.active or self.torch is None:
            return
        tmp = self.path + ".tmp"
        if not self.lock.acquire(timeout=0.5):
            return
        try:
            data = {
                "version": self.VERSION,
                "meta": {"latent": self.latent_dim, "c1": self.c1, "c2": self.c2, "c3": self.c3, "action_dim": self.action_dim, "effect_dim": self.effect_dim},
                "encoder": {k: v.detach().cpu() for k, v in self.encoder.state_dict().items()},
                "predictor": {k: v.detach().cpu() for k, v in self.predictor.state_dict().items()},
                "decoder": {k: v.detach().cpu() for k, v in self.decoder.state_dict().items()},
                "optimizer": self.optimizer.state_dict(),
                "steps": self.steps,
                "loss_ema": self.loss_ema,
            }
            self.torch.save(data, tmp)
            os.replace(tmp, self.path)
        except Exception:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass
        finally:
            self.lock.release()

    def _train_loop(self):
        batch = []
        while not self.shutdown.is_set() and (self.stop_event is None or not self.stop_event.is_set()):
            try:
                batch.append(self.queue.get(timeout=0.12))
            except queue.Empty:
                pass
            if len(batch) < self.batch_size:
                continue
            rows = batch[-min(self.batch_size * 2, len(batch)):]
            batch.clear()
            if not self.lock.acquire(timeout=0.02):
                continue
            try:
                torch = self.torch
                before = torch.as_tensor(self.np.stack([row[0] for row in rows]), dtype=torch.float32, device=self.device).permute(0, 3, 1, 2) / 255.0
                after = torch.as_tensor(self.np.stack([row[1] for row in rows]), dtype=torch.float32, device=self.device).permute(0, 3, 1, 2) / 255.0
                actions = torch.as_tensor(self.np.stack([row[2] for row in rows]), dtype=torch.float32, device=self.device)
                effects = torch.as_tensor(self.np.stack([row[3] for row in rows]), dtype=torch.float32, device=self.device)
                values = torch.as_tensor([row[4] for row in rows], dtype=torch.float32, device=self.device)
                latent = self.encoder(before)
                with torch.no_grad():
                    next_latent = self.encoder(after)
                output = self.predictor(torch.cat((latent, actions), dim=1))
                predicted_latent = torch.sigmoid(output[:, :self.latent_dim])
                predicted_effect = torch.tanh(output[:, self.latent_dim:self.latent_dim + self.effect_dim])
                predicted_value = torch.tanh(output[:, -1])
                future_loss = torch.nn.functional.smooth_l1_loss(predicted_latent, next_latent)
                effect_loss = torch.nn.functional.smooth_l1_loss(predicted_effect, effects)
                value_loss = torch.nn.functional.smooth_l1_loss(predicted_value, values)
                reconstruction = self.decoder(latent).reshape(len(rows), 3, 9, 16)
                target = torch.nn.functional.interpolate(before, size=(9, 16), mode="area")
                reconstruction_loss = torch.nn.functional.smooth_l1_loss(reconstruction, target)
                centered = latent - latent.mean(dim=0, keepdim=True)
                variance = torch.relu(0.030 - centered.pow(2).mean(dim=0)).mean()
                loss = future_loss + effect_loss * 0.80 + value_loss * 0.28 + reconstruction_loss * 0.08 + variance * 0.04
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                params = list(self.encoder.parameters()) + list(self.predictor.parameters()) + list(self.decoder.parameters())
                torch.nn.utils.clip_grad_norm_(params, 3.0)
                self.optimizer.step()
                value = float(loss.detach().item())
                self.loss_ema = value if self.steps == 0 else self.loss_ema * 0.95 + value * 0.05
                self.steps += 1
            except Exception:
                pass
            finally:
                self.lock.release()
            if self.steps and self.steps % 90 == 0:
                self._save()
            self.shutdown.wait(0.005)
        self._save()

    def close(self):
        if not self.active:
            return
        self.shutdown.set()
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(1.0)
        self._save()


class SceneUnderstanding:
    def __init__(self, vision, width, height, prototype_path=None, visual_encoder=None):
        self.vision = vision
        self.width = width
        self.height = height
        self.prototypes = []
        self.max_prototypes = 128
        self.prototype_path = prototype_path
        self.visual_encoder = visual_encoder
        self.last_grid = None
        self.last_hp = None
        self.last_boss = None
        self.last_distance = None
        self.last_at = 0.0
        self.incoming_ema = 0.0
        self.dealt_ema = 0.0
        self.closing_ema = 0.0
        self.threat_ema = 0.0
        self.combo_ema = 0.0
        self.last_telegraph = 0.0
        self.last_threat_sample = 0.0
        self.risk_at = 0.0
        self.impact_ema = 0.0
        try:
            self.np = importlib.import_module("numpy")
        except Exception:
            self.np = None
        self._load_prototypes()

    def _load_prototypes(self):
        if not self.prototype_path or not os.path.isfile(self.prototype_path):
            return
        try:
            with gzip.open(self.prototype_path, "rt", encoding="utf-8") as handle:
                data = json.load(handle)
            if str(data.get("game_id") or "") != "100072570" or int(data.get("schema", 0)) != 1:
                return
            rows = data.get("prototypes") or []
            clean = []
            for row in rows[-self.max_prototypes:]:
                if isinstance(row, list) and 20 <= len(row) <= 128:
                    clean.append(tuple(float(x) for x in row))
            self.prototypes = clean
        except Exception:
            pass

    def save_prototypes(self):
        if not self.prototype_path:
            return
        tmp = self.prototype_path + ".tmp"
        try:
            with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=5) as handle:
                json.dump({"game_id": "100072570", "schema": 1, "width": self.width, "height": self.height, "prototypes": [list(x) for x in self.prototypes[-self.max_prototypes:]]}, handle, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, self.prototype_path)
        except Exception:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    def reset_episode(self):
        self.last_grid = None
        self.last_hp = None
        self.last_boss = None
        self.last_distance = None
        self.last_at = 0.0
        self.incoming_ema = 0.0
        self.dealt_ema = 0.0
        self.closing_ema = 0.0
        self.threat_ema = 0.0
        self.combo_ema = 0.0
        self.last_telegraph = 0.0
        self.last_threat_sample = 0.0
        self.risk_at = 0.0
        self.impact_ema = 0.0

    @staticmethod
    def _clamp(value, lo=0.0, hi=1.0):
        return max(lo, min(hi, value))

    def _grid(self, frame, cols=20, rows=11):
        if not frame:
            return []
        x1 = int(self.width * 0.03)
        x2 = int(self.width * 0.97)
        y1 = int(self.height * 0.21)
        y2 = int(self.height * 0.91)
        if self.np is not None:
            try:
                np = self.np
                image = np.frombuffer(frame, dtype=np.uint8).reshape(self.height, self.width, 4)
                ys = np.minimum(y2 - 1, y1 + ((np.arange(rows, dtype=np.float32) + 0.5) * (y2 - y1) / rows).astype(np.intp))
                xs = np.minimum(x2 - 1, x1 + ((np.arange(cols, dtype=np.float32) + 0.5) * (x2 - x1) / cols).astype(np.intp))
                pixels = image[ys[:, None], xs[None, :], :3].astype(np.float32)
                b, g, r = pixels[..., 0], pixels[..., 1], pixels[..., 2]
                lum = (r * 3.0 + g * 6.0 + b) / 2550.0
                sat = (pixels.max(axis=2) - pixels.min(axis=2)) / 255.0
                return list(zip(lum.ravel().tolist(), sat.ravel().tolist()))
            except Exception:
                self.np = None
        values = []
        for gy in range(rows):
            y = min(y2 - 1, y1 + int((gy + 0.5) * (y2 - y1) / rows))
            for gx in range(cols):
                x = min(x2 - 1, x1 + int((gx + 0.5) * (x2 - x1) / cols))
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                lum = (r * 3 + g * 6 + b) / 2550.0
                sat = (max(r, g, b) - min(r, g, b)) / 255.0
                values.append((lum, sat))
        return values

    @staticmethod
    def _shift_error(current, previous, cols, rows, dx, dy):
        total = 0.0
        count = 0
        for y in range(rows):
            py = y + dy
            if py < 0 or py >= rows:
                continue
            for x in range(cols):
                px = x + dx
                if px < 0 or px >= cols:
                    continue
                a = current[y * cols + x]
                b = previous[py * cols + px]
                total += abs(a[0] - b[0]) + abs(a[1] - b[1]) * 0.28
                count += 1
        return total / max(count, 1)

    def _flow(self, current, previous, cols=20, rows=11):
        if not current or not previous or len(current) != len(previous):
            return 0.0, 0.0
        candidates = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                candidates.append((self._shift_error(current, previous, cols, rows, dx, dy), dx, dy))
        candidates.sort(key=lambda item: item[0])
        _, dx, dy = candidates[0]
        return float(dx), float(dy)

    def _visual_latent(self, grid, previous, cols=20, rows=11):
        if not grid:
            return (0.5, 0.25, 0.0) * 6
        latent = []
        for by in range(2):
            y0 = by * rows // 2
            y1 = (by + 1) * rows // 2
            for bx in range(3):
                x0 = bx * cols // 3
                x1 = (bx + 1) * cols // 3
                lum = sat = delta = 0.0
                count = 0
                for y in range(y0, y1):
                    for x in range(x0, x1):
                        idx = y * cols + x
                        l, st = grid[idx]
                        lum += l
                        sat += st
                        if previous and idx < len(previous):
                            pl, ps = previous[idx]
                            delta += abs(l - pl) + abs(st - ps) * 0.35
                        count += 1
                inv = 1.0 / max(count, 1)
                latent.extend((
                    self._clamp(lum * inv),
                    self._clamp(sat * inv),
                    self._clamp(delta * inv * 3.2),
                ))
        return tuple(latent)

    @staticmethod
    def _feature_distance(a, b):
        if not a or not b or len(a) != len(b):
            return 9.0
        return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)) / len(a))

    def _novelty(self, feature):
        if not self.prototypes:
            self.prototypes.append(tuple(feature))
            return 1.0
        distance = min(self._feature_distance(feature, item) for item in self.prototypes)
        novelty = self._clamp(distance / 0.26)
        if distance > 0.13:
            if len(self.prototypes) >= self.max_prototypes:
                self.prototypes.pop(0)
            self.prototypes.append(tuple(feature))
        return novelty

    def _temporal(self, hp, boss, distance, motion, crowd, near, scene_change, novelty, now):
        if not self.last_at:
            dt = 0.12
        else:
            dt = max(0.05, min(0.55, now - self.last_at))
        incoming = 0.0
        dealt = 0.0
        closing = 0.0
        if hp is not None and self.last_hp is not None:
            incoming = self._clamp(max(0.0, self.last_hp - hp) / dt * 4.5)
        if boss is not None and self.last_boss is not None:
            dealt = self._clamp(max(0.0, self.last_boss - boss) / dt * 4.2)
        if distance is not None and self.last_distance is not None:
            closing = max(-1.0, min(1.0, (self.last_distance - distance) / dt * 2.6))
        self.incoming_ema = self.incoming_ema * 0.68 + incoming * 0.32
        self.dealt_ema = self.dealt_ema * 0.66 + dealt * 0.34
        self.closing_ema = self.closing_ema * 0.72 + closing * 0.28
        motion_pressure = self._clamp((motion - 2.0) / 8.0)
        low_hp = 0.0 if hp is None else self._clamp((0.38 - hp) / 0.38)
        threat_sample = self._clamp(
            self.incoming_ema * 0.62
            + motion_pressure * near * 0.20
            + crowd * 0.08
            + max(0.0, self.closing_ema) * near * 0.06
            + low_hp * 0.16
        )
        self.threat_ema = max(threat_sample, self.threat_ema * 0.78)
        combo_sample = self._clamp(
            self.dealt_ema * 0.58
            + near * 0.22
            + (1.0 - self.threat_ema) * 0.10
            + self._clamp(scene_change / 2.0) * 0.05
            + novelty * 0.05
        )
        self.combo_ema = self.combo_ema * 0.62 + combo_sample * 0.38
        hp_term = 0.0 if hp is None else (hp - 0.5) * 0.34
        advantage = self._clamp(0.5 + hp_term + self.dealt_ema * 0.30 - self.incoming_ema * 0.42)
        progress = self._clamp(self._clamp(scene_change / 1.8) * 0.55 + novelty * 0.20 + abs(self.closing_ema) * 0.25)
        self.last_hp = hp if hp is not None else self.last_hp
        self.last_boss = boss if boss is not None else self.last_boss
        self.last_distance = distance if distance is not None else self.last_distance
        self.last_at = now
        return self.threat_ema, self.incoming_ema, self.dealt_ema, self.combo_ema, advantage, progress

    def _spatial_risk(self, grid, prior, player_x, target_x, flow_x):
        if not grid or not prior or len(grid) != len(prior):
            return 0.0, 0.0
        cols, rows = 20, 11
        px = 0.50 if player_x is None else self._clamp(player_x)
        left_risk = 0.0
        right_risk = 0.0
        center_risk = 0.0
        total = 0.0
        for y in range(rows):
            ny = (y + 0.5) / rows
            if ny < 0.18 or ny > 0.96:
                continue
            vertical = 0.45 + 0.55 * (1.0 - abs(ny - 0.62))
            for x in range(cols):
                i = y * cols + x
                lum, sat = grid[i]
                pl, ps = prior[i]
                delta = abs(lum - pl) + abs(sat - ps) * 0.42
                if delta < 0.045:
                    continue
                nx = (x + 0.5) / cols
                dist = abs(nx - px)
                proximity = max(0.0, 1.0 - dist / 0.34)
                if proximity <= 0.0:
                    continue
                weight = delta * proximity * vertical
                total += weight
                if nx < px - 0.035:
                    left_risk += weight
                elif nx > px + 0.035:
                    right_risk += weight
                else:
                    center_risk += weight * 1.25
        if total <= 1e-8:
            return 0.0, 0.0


        approach_bonus = 0.0
        if player_x is not None:
            if flow_x > 0.08 and left_risk > right_risk:
                approach_bonus = min(0.45, abs(flow_x) * 0.55)
            elif flow_x < -0.08 and right_risk > left_risk:
                approach_bonus = min(0.45, abs(flow_x) * 0.55)
        normalized = self._clamp((center_risk * 1.35 + min(left_risk, right_risk) * 0.45 + max(left_risk, right_risk) * 0.72) / 2.5)
        telegraph = self._clamp(normalized + approach_bonus)

        imbalance = left_risk - right_risk
        escape_side = 0.0
        if abs(imbalance) > 0.025:
            escape_side = 1.0 if imbalance > 0 else -1.0


        if target_x is not None and player_x is not None and telegraph > 0.48 and abs(imbalance) < 0.12:
            escape_side = -1.0 if target_x > player_x else 1.0
        return telegraph, escape_side

    def encode(self, frame, previous, obs, fingerprint, motion):
        now = time.monotonic()
        grid = self._grid(frame)
        prior = self.last_grid
        flow_x, flow_y = self._flow(grid, prior)
        latent = self.visual_encoder.encode(frame) if self.visual_encoder is not None else None
        if not latent:
            latent = self._visual_latent(grid, prior)
        active = []
        edge = 0.0
        cols, rows = 20, 11
        if grid:
            for y in range(rows):
                for x in range(cols):
                    index = y * cols + x
                    lum, sat = grid[index]
                    if x + 1 < cols:
                        edge += abs(lum - grid[index + 1][0])
                    if y + 1 < rows:
                        edge += abs(lum - grid[index + cols][0])
                    if prior and index < len(prior):
                        d = abs(lum - prior[index][0]) + abs(sat - prior[index][1]) * 0.35
                        if d > 0.10:
                            active.append((x, y, d))
        self.last_grid = grid
        if active:
            weight = sum(item[2] for item in active)
            active_x = sum((x + 0.5) / cols * w for x, _, w in active) / weight
            active_y = sum((y + 0.5) / rows * w for _, y, w in active) / weight
            crowd = self._clamp(len(active) / (cols * rows * 0.34))
        else:
            active_x, active_y, crowd = 0.5, 0.55, 0.0
        edge_energy = edge / max(cols * rows * 0.35, 1.0)
        player_x = obs.player_x
        player_y = obs.player_y
        target_x = obs.enemy_x
        target_y = obs.enemy_y
        if player_x is not None and target_x is None and crowd > 0.08 and abs(active_x - player_x) > 0.10:
            target_x = active_x
            target_y = active_y
        distance = None
        side = 0.0
        if player_x is not None and target_x is not None:
            if player_y is not None and target_y is not None:
                distance = math.hypot(target_x - player_x, (target_y - player_y) * 0.72)
            else:
                distance = abs(target_x - player_x)
            side = 1.0 if target_x > player_x else -1.0
        coarse = []
        if grid:
            for gy in (1, 3, 5, 7, 9):
                for gx in (1, 4, 7, 10, 13, 16, 19):
                    idx = min(len(grid) - 1, gy * cols + gx)
                    coarse.extend(grid[idx])
        coarse.extend((
            self._clamp((motion or 0.0) / 12.0),
            crowd,
            self._clamp(edge_energy),
            (flow_x + 1.0) / 2.0,
            (flow_y + 1.0) / 2.0,
        ))
        coarse.extend(latent)
        novelty = self._novelty(coarse)
        previous_fp = self.vision.combat_fingerprint(previous) if previous else ()
        scene_change = self.vision.fingerprint_distance(fingerprint, previous_fp)
        near = 0.35 if distance is None else 1.0 - self._clamp(distance / 0.42)
        threat, incoming, dealt, combo, advantage, progress = self._temporal(
            obs.hp_ratio, obs.boss_ratio, distance, motion or 0.0, crowd, near, scene_change, novelty, now
        )
        telegraph, escape_side = self._spatial_risk(grid, prior, player_x, target_x, flow_x)


        incoming = self._clamp(max(incoming, telegraph * (0.78 + crowd * 0.18)))
        threat = self._clamp(max(threat, telegraph * 0.90, incoming * 0.92))
        risk_dt = 0.10 if not self.risk_at else max(0.04, min(0.40, now - self.risk_at))
        telegraph_slope = max(-1.0, min(1.0, (telegraph - self.last_telegraph) / risk_dt * 0.72))
        threat_slope = max(-1.0, min(1.0, (threat - self.last_threat_sample) / risk_dt * 0.58))
        risk_trend = max(-1.0, min(1.0, telegraph_slope * 0.68 + threat_slope * 0.32))
        closing_pressure = max(0.0, self.closing_ema) * near
        impact_sample = self._clamp(
            telegraph * 0.48 + incoming * 0.28 + threat * 0.12
            + max(0.0, risk_trend) * 0.34 + closing_pressure * 0.14
        )
        self.impact_ema = max(impact_sample, self.impact_ema * (0.80 if risk_trend > 0 else 0.70))
        self.last_telegraph = telegraph
        self.last_threat_sample = threat
        self.risk_at = now
        opening = self._clamp(dealt * 0.58 + combo * 0.28 + advantage * 0.34 - incoming * 0.54 - telegraph * 0.36 - self.impact_ema * 0.22)
        phase_shift = self._clamp(scene_change * 0.36 + novelty * 0.44 + (0.24 if obs.boss_ratio is not None and scene_change > 0.72 else 0.0))
        engaged = self._clamp(max(near, crowd * 0.72, 0.62 if obs.boss_ratio is not None else 0.0))
        return WorldState(
            hp=obs.hp_ratio,
            mp=obs.mp_ratio,
            boss=obs.boss_ratio,
            player_x=player_x,
            target_x=target_x,
            distance=distance,
            target_side=side,
            motion=motion or 0.0,
            scene_change=scene_change,
            novelty=novelty,
            flow_x=flow_x,
            flow_y=flow_y,
            crowd=crowd,
            edge_energy=edge_energy,
            active_x=active_x,
            active_y=active_y,
            threat=threat,
            incoming=incoming,
            dealt=dealt,
            combo=combo,
            engaged=engaged,
            advantage=advantage,
            progress=progress,
            telegraph=telegraph,
            escape_side=escape_side,
            opening=opening,
            phase_shift=phase_shift,
            risk_trend=risk_trend,
            impact_risk=self.impact_ema,
            latent=latent,
            fingerprint=fingerprint,
            captured_at=now,
        )


class OnlineCudaLearner:
    MODEL_VERSION = 4

    def __init__(self, base_dir, profile, actions, feature_dim, effect_dim, stop_event=None):
        self.active = False
        self.backend = ""
        self.torch = None
        self.np = None
        self.device = None
        self.stop_event = stop_event
        self.base_dir = os.path.abspath(base_dir)
        self.model_path = os.path.join(self.base_dir, ".ai_cuda_model.pt")
        self.actions = tuple(actions)
        self.action_index = {name: i for i, name in enumerate(self.actions)}
        self.feature_dim = int(feature_dim)
        self.effect_dim = int(effect_dim)
        self.lock = threading.RLock()
        self.samples = 0
        self.steps = 0
        self.loss_ema = 1.0
        self.hidden = 0
        self.depth = 0
        self.batch_size = 0
        self.replay_limit = 0
        self.replay_size = 0
        self.replay_pos = 0
        self.replay_features = None
        self.replay_actions = None
        self.replay_effects = None
        self.replay_values = None
        self.last_save = 0.0
        self.last_saved_step = 0
        self.sample_queue = queue.Queue(maxsize=4096)
        self.save_event = threading.Event()
        self.trainer_stop = threading.Event()
        self.trainer = None
        gpu_name = str(getattr(profile, "gpu_name", "") or "")
        vram = max(0.0, float(getattr(profile, "gpu_vram_gb", 0.0) or 0.0))
        if "NVIDIA" not in gpu_name.upper() or vram < 4.0 or bool(getattr(profile, "on_battery", False)) or _cuda_marker_blocks(base_dir, profile):
            return
        torch = _import_optional("torch", base_dir, None, stop_event, 420.0)
        np = _import_optional("numpy", base_dir, None, stop_event, 120.0)
        if torch is None or np is None:
            return
        try:
            if not torch.cuda.is_available():
                return
            index = max(0, int(getattr(profile, "gpu_index", 0) or 0))
            if index >= int(torch.cuda.device_count()):
                index = 0
            self.torch = torch
            self.np = np
            self.device = torch.device(f"cuda:{index}")
            torch.cuda.set_device(index)
            benchmark_scale = self._device_benchmark_scale(vram)
            self.hidden = max(160, int((128.0 + vram * 21.0 + math.sqrt(vram) * 34.0) * math.sqrt(benchmark_scale) / 32.0) * 32)
            self.depth = max(2, 2 + int(math.log2(max(1.0, vram / 4.0))) + (1 if benchmark_scale >= 1.55 else 0))
            self.batch_size = max(64, int(vram * 20.0 * benchmark_scale))
            memory_gb = max(4.0, float(getattr(profile, "memory_gb", 8.0) or 8.0))
            self.replay_limit = max(24000, int(memory_gb * 1800.0 + vram * 2600.0))
            self.replay_features = np.empty((self.replay_limit, self.feature_dim), dtype=np.float32)
            self.replay_actions = np.empty((self.replay_limit,), dtype=np.int32)
            self.replay_effects = np.empty((self.replay_limit, self.effect_dim), dtype=np.float32)
            self.replay_values = np.empty((self.replay_limit,), dtype=np.float32)
            input_dim = self.feature_dim + len(self.actions)
            layers = []
            last = input_dim
            for _ in range(self.depth):
                layers.extend((torch.nn.Linear(last, self.hidden), torch.nn.SiLU()))
                last = self.hidden
            layers.append(torch.nn.Linear(last, self.effect_dim))
            self.transition = torch.nn.Sequential(*layers).to(self.device)
            value_layers = []
            last = self.feature_dim
            value_depth = max(2, self.depth - 1)
            value_hidden = max(96, self.hidden // 2)
            for _ in range(value_depth):
                value_layers.extend((torch.nn.Linear(last, value_hidden), torch.nn.SiLU()))
                last = value_hidden
            value_layers.append(torch.nn.Linear(last, 1))
            self.value = torch.nn.Sequential(*value_layers).to(self.device)
            self.optimizer = torch.optim.AdamW(
                list(self.transition.parameters()) + list(self.value.parameters()),
                lr=max(2.5e-4, 7.5e-4 / math.sqrt(max(1.0, vram / 4.0))), weight_decay=1e-5,
            )
            self._benchmark_batch(vram)
            self.train_every = max(1, int(round(7.0 / math.sqrt(max(1.0, vram / 4.0)))))
            self.updates_per_train = max(1, int(round(math.sqrt(max(1.0, vram / 4.0)))))
            self.min_samples = max(48, self.batch_size // 3)
            self.active = True
            self._load()
            self.backend = f"CUDA:{index}异步模型{self.hidden}/B{self.batch_size}"
            self.trainer = threading.Thread(target=self._trainer_loop, daemon=True)
            self.trainer.start()
        except Exception:
            self.active = False
            self.torch = None
            self.np = None
            self.device = None

    def _device_benchmark_scale(self, vram):
        torch = self.torch
        if torch is None:
            return 1.0
        side = 512 if vram < 8.0 else 768
        try:
            torch.cuda.reset_peak_memory_stats(self.device)
            a = torch.randn((side, side), dtype=torch.float16, device=self.device)
            b = torch.randn((side, side), dtype=torch.float16, device=self.device)
            for _ in range(2):
                torch.mm(a, b)
            torch.cuda.synchronize(self.device)
            samples = []
            for _ in range(5):
                started = time.perf_counter()
                torch.mm(a, b)
                torch.cuda.synchronize(self.device)
                samples.append(time.perf_counter() - started)
            elapsed = sorted(samples)[len(samples) // 2]
            target = 0.0038 if side == 512 else 0.0065
            speed = max(0.62, min(2.2, target / max(0.0002, elapsed)))
            total = max(1.0, float(torch.cuda.get_device_properties(self.device).total_memory))
            peak = float(torch.cuda.max_memory_allocated(self.device)) / total
            if peak > 0.10:
                speed *= max(0.65, 0.10 / peak)
            return max(0.62, min(2.2, speed))
        except Exception:
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass
            return 1.0

    def _benchmark_batch(self, vram):
        torch = self.torch
        if torch is None:
            return
        natural_limit = max(self.batch_size, int(max(4.0, vram) * 160.0))
        count = max(64, self.batch_size // 2)
        best = count
        target = 0.006
        try:
            while count <= natural_limit:
                features = torch.zeros((count, self.feature_dim), dtype=torch.float32, device=self.device)
                indices = torch.arange(count, device=self.device) % len(self.actions)
                onehot = torch.nn.functional.one_hot(indices, num_classes=len(self.actions)).to(dtype=torch.float32)
                inputs = torch.cat((features, onehot), dim=1)
                torch.cuda.synchronize(self.device)
                started = time.perf_counter()
                with torch.no_grad():
                    self.transition(inputs)
                    self.value(features)
                torch.cuda.synchronize(self.device)
                elapsed = time.perf_counter() - started
                if elapsed > target and best >= 64:
                    break
                best = count
                count = max(count + 1, int(count * 1.45))
        except Exception:
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass
        self.batch_size = max(64, best)

    def _append_ring(self, feature, action_index, effect, value_target):
        pos = self.replay_pos
        self.replay_features[pos] = feature
        self.replay_actions[pos] = int(action_index)
        self.replay_effects[pos] = effect
        self.replay_values[pos] = float(value_target)
        self.replay_pos = (pos + 1) % self.replay_limit
        self.replay_size = min(self.replay_limit, self.replay_size + 1)

    def _load(self):
        if not self.active or not os.path.isfile(self.model_path):
            return
        torch = self.torch
        try:
            data = torch.load(self.model_path, map_location="cpu", weights_only=True)
            if not isinstance(data, dict) or int(data.get("version", 0)) != self.MODEL_VERSION:
                return
            meta = data.get("meta") or {}
            if tuple(meta.get("actions") or ()) != self.actions:
                return
            if int(meta.get("feature_dim", -1)) != self.feature_dim or int(meta.get("effect_dim", -1)) != self.effect_dim:
                return
            if int(meta.get("hidden", -1)) != self.hidden or int(meta.get("depth", -1)) != self.depth:
                return
            self.transition.load_state_dict(data.get("transition") or {})
            self.value.load_state_dict(data.get("value") or {})
            optimizer = data.get("optimizer")
            if isinstance(optimizer, dict):
                self.optimizer.load_state_dict(optimizer)
                for state in self.optimizer.state.values():
                    for key, value in list(state.items()):
                        if torch.is_tensor(value):
                            state[key] = value.to(self.device)
            self.steps = max(0, int(data.get("steps", 0)))
            self.samples = max(0, int(data.get("samples", self.steps)))
            self.loss_ema = max(0.0, min(20.0, float(data.get("loss_ema", 1.0))))
            rf = data.get("replay_features")
            ra = data.get("replay_actions")
            reff = data.get("replay_effects")
            rv = data.get("replay_values")
            if all(torch.is_tensor(x) for x in (rf, ra, reff, rv)):
                features = rf.float().cpu().numpy()
                actions = ra.int().cpu().numpy()
                effects = reff.float().cpu().numpy()
                values = rv.float().cpu().numpy()
                count = min(len(features), len(actions), len(effects), len(values), self.replay_limit)
                for i in range(count):
                    if features[i].shape[0] == self.feature_dim and effects[i].shape[0] == self.effect_dim and 0 <= int(actions[i]) < len(self.actions):
                        self._append_ring(features[i], int(actions[i]), effects[i], float(values[i]))
            self.last_saved_step = self.steps
        except Exception:
            try:
                bad = self.model_path + f".rejected.{int(time.time())}"
                os.replace(self.model_path, bad)
            except OSError:
                pass

    def _ring_indices(self, count):
        count = min(max(0, int(count)), self.replay_size)
        if count <= 0:
            return self.np.empty((0,), dtype=self.np.intp)
        start = (self.replay_pos - count) % self.replay_limit
        return (start + self.np.arange(count, dtype=self.np.int64)) % self.replay_limit

    def _save_now(self, force=False):
        if not self.active or self.torch is None:
            return
        now = time.monotonic()
        if not force and now - self.last_save < 90.0 and self.steps - self.last_saved_step < max(32, self.batch_size // 2):
            return
        tmp = self.model_path + ".tmp"
        if not self.lock.acquire(timeout=2.0 if force else 0.05):
            return
        try:
            count = min(self.replay_size, max(self.batch_size * 8, 512))
            indices = self._ring_indices(count)
            data = {
                "version": self.MODEL_VERSION,
                "meta": {"actions": list(self.actions), "feature_dim": self.feature_dim, "effect_dim": self.effect_dim, "hidden": self.hidden, "depth": self.depth},
                "transition": {k: v.detach().cpu() for k, v in self.transition.state_dict().items()},
                "value": {k: v.detach().cpu() for k, v in self.value.state_dict().items()},
                "optimizer": self.optimizer.state_dict(),
                "steps": self.steps,
                "samples": self.samples,
                "loss_ema": self.loss_ema,
                "replay_features": self.torch.from_numpy(self.replay_features[indices].copy()),
                "replay_actions": self.torch.from_numpy(self.replay_actions[indices].copy()),
                "replay_effects": self.torch.from_numpy(self.replay_effects[indices].copy()),
                "replay_values": self.torch.from_numpy(self.replay_values[indices].copy()),
            }
            self.torch.save(data, tmp)
            os.replace(tmp, self.model_path)
            self.last_save = now
            self.last_saved_step = self.steps
        except Exception:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass
        finally:
            self.lock.release()

    def save(self, force=False):
        if not self.active:
            return
        if force:
            self.trainer_stop.set()
            if self.trainer is not None and self.trainer.is_alive() and threading.current_thread() is not self.trainer:
                self.trainer.join(1.5)
            self._save_now(True)
        else:
            self.save_event.set()

    def add(self, feature, action, effect, value_target):
        if not self.active or action not in self.action_index:
            return
        f = tuple(float(x) for x in feature[:self.feature_dim])
        e = tuple(float(x) for x in effect[:self.effect_dim])
        if len(f) != self.feature_dim or len(e) != self.effect_dim:
            return
        item = (f, self.action_index[action], e, max(-12.0, min(12.0, float(value_target))))
        self.samples += 1
        try:
            self.sample_queue.put_nowait(item)
        except queue.Full:
            try:
                self.sample_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self.sample_queue.put_nowait(item)
            except queue.Full:
                pass

    def _train_once(self):
        torch = self.torch
        np = self.np
        if torch is None or np is None or not self.active or self.replay_size < self.min_samples:
            return
        if not self.lock.acquire(timeout=0.02):
            return
        try:
            for _ in range(self.updates_per_train):
                count = min(self.batch_size, self.replay_size)
                indices_np = np.random.randint(0, self.replay_size, size=count, dtype=np.int64)
                if self.replay_size == self.replay_limit:
                    physical = (self.replay_pos + indices_np) % self.replay_limit
                else:
                    physical = indices_np
                features_np = self.replay_features[physical]
                actions_np = self.replay_actions[physical]
                effects_np = self.replay_effects[physical]
                values_np = self.replay_values[physical]
                features = torch.as_tensor(features_np, dtype=torch.float32, device=self.device)
                action_indices = torch.as_tensor(actions_np, dtype=torch.long, device=self.device)
                onehot = torch.nn.functional.one_hot(action_indices, num_classes=len(self.actions)).to(dtype=torch.float32)
                inputs = torch.cat((features, onehot), dim=1)
                effect_targets = torch.as_tensor(effects_np, dtype=torch.float32, device=self.device)
                value_targets = torch.as_tensor(values_np[:, None], dtype=torch.float32, device=self.device)
                predicted_effect = self.transition(inputs)
                predicted_value = self.value(features)
                effect_loss = torch.nn.functional.smooth_l1_loss(predicted_effect, effect_targets)
                value_loss = torch.nn.functional.smooth_l1_loss(predicted_value, value_targets)
                loss = effect_loss + value_loss * 0.28
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(list(self.transition.parameters()) + list(self.value.parameters()), 4.0)
                self.optimizer.step()
                value = float(loss.detach().item())
                self.loss_ema = value if self.steps <= 0 else self.loss_ema * 0.94 + value * 0.06
                self.steps += 1
        except Exception:
            self.loss_ema = min(8.0, self.loss_ema * 1.2 + 0.1)
        finally:
            self.lock.release()

    def _trainer_loop(self):
        appended = 0
        while not self.trainer_stop.is_set() and (self.stop_event is None or not self.stop_event.is_set()):
            try:
                item = self.sample_queue.get(timeout=0.05)
            except queue.Empty:
                item = None
            if item is not None:
                self._append_ring(*item)
                appended += 1
                if self.replay_size >= self.min_samples and appended % self.train_every == 0:
                    self._train_once()
            if self.save_event.is_set():
                self.save_event.clear()
                self._save_now(False)
        while True:
            try:
                item = self.sample_queue.get_nowait()
            except queue.Empty:
                break
            self._append_ring(*item)
        self._save_now(True)

    def predict_pairs(self, features, actions):
        if not self.active or self.steps < 3 or not features or len(features) != len(actions):
            return None
        indices = []
        clean = []
        for feature, action in zip(features, actions):
            if action not in self.action_index:
                return None
            row = tuple(float(x) for x in feature[:self.feature_dim])
            if len(row) != self.feature_dim:
                return None
            clean.append(row)
            indices.append(self.action_index[action])
        torch = self.torch
        if not self.lock.acquire(blocking=False):
            return None
        try:
            with torch.no_grad():
                ft = torch.tensor(clean, dtype=torch.float32, device=self.device)
                it = torch.tensor(indices, dtype=torch.long, device=self.device)
                onehot = torch.nn.functional.one_hot(it, num_classes=len(self.actions)).to(dtype=torch.float32)
                output = self.transition(torch.cat((ft, onehot), dim=1))
                values = self.value(ft).squeeze(1)
                effects = output.detach().float().cpu().tolist()
                vals = values.detach().float().cpu().tolist()
            maturity = min(1.0, math.log1p(self.steps) / math.log(4001.0))
            uncertainty = max(0.08, min(0.72, 0.62 * (1.0 - maturity) + min(0.26, self.loss_ema * 0.10)))
            return [(tuple(float(x) for x in effect), float(value), uncertainty, max(4, int(math.sqrt(max(1, self.samples))))) for effect, value in zip(effects, vals)]
        except Exception:
            return None
        finally:
            self.lock.release()


class CausalWorldModel:
    PRIMITIVES = ("A", "D", "W", "S", "F", "H", "J", "K", "U", "I", "O", "L", "Z", "SPACE")
    TACTICS = ("TOWARD", "RETREAT", "EVADE", "PARAM", "JJJ", "KJ", "CHASEJ", "UJ", "IJ", "OJ", "LJ", "SPACEJ")
    ACTIONS = PRIMITIVES + TACTICS
    EFFECT_DIM = 11
    COMPONENTS = {
        "JJJ": ("J",),
        "KJ": ("K", "J"),
        "CHASEJ": ("J",),
        "UJ": ("U", "J"),
        "IJ": ("I", "J"),
        "OJ": ("O", "J"),
        "LJ": ("L", "J"),
        "SPACEJ": ("SPACE", "J"),
        "EVADE": ("K",),
    }
    BASE_KEY_GAP = {
        "A": 0.10, "D": 0.10, "W": 0.10, "S": 0.10, "F": 0.30,
        "H": 1.15, "J": 0.11, "K": 0.16, "U": 0.58, "I": 0.58,
        "O": 0.58, "L": 0.58, "Z": 1.00, "SPACE": 1.05,
    }

    def __init__(self, path, profile=None, legacy_path=None, persistence=None, stop_event=None, latent_dim=18):
        self.path = path
        self.latent_dim = max(18, min(96, int(latent_dim or 18)))
        self.legacy_path = legacy_path
        self.profile = profile
        self.persistence = persistence
        self.stop_event = stop_event
        try:
            self.np = importlib.import_module("numpy")
        except Exception:
            self.np = None
        self.torch = None
        self.torch_checked = False
        self.cuda_device = f"cuda:{max(0, int(getattr(profile, 'gpu_index', 0) or 0))}"
        self.compute_backend = "NumPy" if self.np is not None else "Python"
        self.neural = None
        self.neural_cache_feature = None
        self.neural_cache = {}
        self.runtime_candidate_budget = max(6, 4 + max(1, int(getattr(profile, "cores", 4))) // 2)
        self.runtime_plan_budget = 0.004
        self.environment_fingerprint = {
            "game_id": "100072570", "model_schema": 10, "action_set": list(self.ACTIONS),
            "effect_dim": self.EFFECT_DIM, "latent_dim": self.latent_dim, "sample_w": int(getattr(profile, "sample_w", 0) or 0),
            "sample_h": int(getattr(profile, "sample_h", 0) or 0),
        }
        self.loaded_environment = {}
        self.memory = []
        self.max_memory = max(3000, int(getattr(profile, "model_memory_limit", 4200)))
        self.by_action = {key: [] for key in self.ACTIONS}
        self.by_action["WAIT"] = []
        self.by_context_action = {}
        self.neighbor_scan_cap = max(240, min(self.max_memory, 160 + max(1, int(getattr(profile, "cores", 4))) * 64 + int(max(0.0, float(getattr(profile, "gpu_vram_gb", 0.0) or 0.0)) * 96.0)))
        self.action_counts = {key: 0 for key in self.ACTIONS}
        self.action_counts["WAIT"] = 0
        self.retry_delay = {key: 0.16 for key in self.ACTIONS}
        for key in ("H", "U", "I", "O", "L", "Z", "SPACE", "UJ", "IJ", "OJ", "LJ", "SPACEJ"):
            self.retry_delay[key] = 0.58
        self.key_gap = dict(self.BASE_KEY_GAP)
        self.key_last_at = {key: -9999.0 for key in self.PRIMITIVES}
        self.last_action_at = {key: -9999.0 for key in self.ACTIONS}
        self.last_effective_at = {key: -9999.0 for key in self.ACTIONS}
        self.pair_stats = {}
        self.triple_stats = {}
        self.context_stats = {}
        self.context_effect_stats = {}
        self.max_contexts = max(500, int(getattr(profile, "model_context_limit", 640)))
        self.effect_latency = {key: 0.0 for key in self.ACTIONS}
        self.policy_defaults = {
            "critical_hp": 0.26, "critical_impact": 0.68, "critical_threat": 0.82,
            "survival_hp": 0.16, "evade_impact": 0.54, "evade_trend": 0.48,
            "evade_telegraph": 0.56, "evade_threat": 0.70, "evade_incoming": 0.48,
            "emergency_hp": 0.15, "emergency_impact": 0.54, "emergency_trend": 0.56,
            "emergency_telegraph": 0.62, "emergency_incoming": 0.58, "emergency_threat": 0.84,
            "opening": 0.68, "far_distance": 0.36, "mid_distance": 0.18,
            "low_mp": 0.12, "mid_mp": 0.24, "novelty_probe": 0.62,
            "probe_hp": 0.50, "probe_threat": 0.50,
        }
        self.policy_priors = dict(self.policy_defaults)
        self.policy_counts = {key: 0 for key in self.policy_defaults}
        self.context_policy_priors = {}
        self.context_policy_counts = {}
        self.active_policy_context = None
        self.terminal_stats = {key: {"w": 0, "l": 0} for key in self.ACTIONS}
        self.last_executed_action = None
        self.last_executed_at = -9999.0
        self.pending_pair = None
        self.pending_triple = None
        self.action_history = []
        self.total_updates = 0
        self.lifetime_updates = 0
        self.save_interval = max(90.0, float(getattr(profile, "model_save_interval", 180.0)))
        self.last_save = 0.0
        self.terminal_context_stats = {}
        self.credit_history = []
        self.timing_stats = {key: {"down": 1.0, "gap": 1.0, "n": 0} for key in self.ACTIONS}
        self.pending_timing = None
        self.save_event = threading.Event()
        self.save_stop = threading.Event()
        self.save_thread = None
        self._load()
        self.neural = OnlineCudaLearner(
            os.path.dirname(self.path) or ".", self.profile, self.ACTIONS + ("WAIT",),
            len(self._normalize_feature([0.5] * (26 + self.latent_dim))), self.EFFECT_DIM, self.stop_event,
        )
        if self.neural.active:
            self.compute_backend = self.neural.backend
        self.save_thread = threading.Thread(target=self._save_loop, daemon=True)
        self.save_thread.start()

    def set_runtime_budget(self, candidate_budget, planning_budget):
        self.runtime_candidate_budget = max(4, int(candidate_budget))
        self.runtime_plan_budget = max(0.001, float(planning_budget))
        cores = max(1, int(getattr(self.profile, "cores", 4)))
        vram = max(0.0, float(getattr(self.profile, "gpu_vram_gb", 0.0) or 0.0))
        dynamic = 160 + self.runtime_candidate_budget * 72 + cores * 36 + int(vram * 96.0) + int(self.runtime_plan_budget * 90000.0)
        self.neighbor_scan_cap = max(240, min(self.max_memory, dynamic))

    def set_environment_fingerprint(self, client_w, client_h, sample_w, sample_h):
        self.environment_fingerprint.update({
            "window_w": max(0, int(client_w or 0)), "window_h": max(0, int(client_h or 0)),
            "sample_w": max(0, int(sample_w or 0)), "sample_h": max(0, int(sample_h or 0)),
            "scale_x": round(float(sample_w) / max(1.0, float(client_w)), 6),
            "scale_y": round(float(sample_h) / max(1.0, float(client_h)), 6),
        })

    @staticmethod
    def _v(value, default=0.5):
        if value is None:
            return default
        return max(0.0, min(1.0, float(value)))

    def set_policy_context(self, state):
        self.active_policy_context = self._context_key(state) if state is not None else None

    def threshold(self, name, default=None, state=None):
        if default is None:
            default = self.policy_defaults.get(name, 0.5)
        default = float(default)
        count = max(0, int(self.policy_counts.get(name, 0)))
        learned = float(self.policy_priors.get(name, default))
        learned_weight = 1.0 - math.exp(-count / 24.0)
        value = default * (1.0 - learned_weight) + learned * learned_weight
        context = self._context_key(state) if state is not None else self.active_policy_context
        if context:
            bucket = self.context_policy_priors.get(context) or {}
            counts = self.context_policy_counts.get(context) or {}
            if name in bucket:
                local_count = max(0, int(counts.get(name, 0)))
                local_weight = 1.0 - math.exp(-local_count / 12.0)
                value = value * (1.0 - local_weight) + float(bucket[name]) * local_weight
        return max(0.02, min(0.98, value))

    def _adapt_threshold(self, name, target, low, high, weight=1.0):
        if name not in self.policy_priors:
            return
        count = max(0, int(self.policy_counts.get(name, 0)))
        rate = max(0.004, min(0.040, 0.105 / math.sqrt(count + 8.0))) * max(0.25, min(1.5, float(weight)))
        current = float(self.policy_priors.get(name, self.policy_defaults.get(name, 0.5)))
        target = max(float(low), min(float(high), float(target)))
        self.policy_priors[name] = max(float(low), min(float(high), current * (1.0 - rate) + target * rate))
        self.policy_counts[name] = count + 1
        context = self.active_policy_context
        if context:
            bucket = self.context_policy_priors.setdefault(context, {})
            counts = self.context_policy_counts.setdefault(context, {})
            local_count = max(0, int(counts.get(name, 0)))
            local_current = float(bucket.get(name, current))
            local_rate = max(0.008, min(0.080, 0.16 / math.sqrt(local_count + 4.0))) * max(0.25, min(1.5, float(weight)))
            bucket[name] = max(float(low), min(float(high), local_current * (1.0 - local_rate) + target * local_rate))
            counts[name] = local_count + 1
            if len(self.context_policy_priors) > self.max_contexts:
                weakest = min(self.context_policy_counts, key=lambda key: sum(self.context_policy_counts.get(key, {}).values()), default=None)
                if weakest is not None:
                    self.context_policy_priors.pop(weakest, None)
                    self.context_policy_counts.pop(weakest, None)

    def _learn_policy_priors(self, action, before, after, raw, effective):
        self.set_policy_context(before)
        hp = 0.70 if before.hp is None else float(before.hp)
        impact = max(0.0, min(1.0, float(before.impact_risk)))
        threat = max(0.0, min(1.0, float(before.threat)))
        telegraph = max(0.0, min(1.0, float(before.telegraph)))
        incoming = max(0.0, min(1.0, float(before.incoming)))
        trend = max(0.0, min(1.0, float(before.risk_trend)))
        hp_loss = max(0.0, -float(raw[0]))
        risk_worsened = float(raw[8]) < -0.06 or float(after.impact_risk) > impact + 0.08 or float(after.incoming) > incoming + 0.08
        bad = hp_loss >= 0.012 or risk_worsened
        if bad:
            self._adapt_threshold("critical_hp", hp + 0.045, 0.16, 0.45, 1.25)
            self._adapt_threshold("survival_hp", hp + 0.025, 0.10, 0.34, 1.10)
            self._adapt_threshold("critical_impact", impact * 0.90, 0.38, 0.82, 1.20)
            self._adapt_threshold("critical_threat", threat * 0.90, 0.45, 0.90, 1.20)
            self._adapt_threshold("evade_impact", impact * 0.88, 0.30, 0.76, 1.20)
            self._adapt_threshold("evade_trend", trend * 0.88, 0.24, 0.72, 1.10)
            self._adapt_threshold("evade_telegraph", telegraph * 0.88, 0.30, 0.78, 1.10)
            self._adapt_threshold("evade_threat", threat * 0.88, 0.38, 0.82, 1.20)
            self._adapt_threshold("evade_incoming", incoming * 0.88, 0.28, 0.76, 1.10)
            self._adapt_threshold("emergency_impact", impact * 0.90, 0.34, 0.78, 1.25)
            self._adapt_threshold("emergency_trend", trend * 0.90, 0.30, 0.76, 1.10)
            self._adapt_threshold("emergency_telegraph", telegraph * 0.90, 0.34, 0.82, 1.10)
            self._adapt_threshold("emergency_incoming", incoming * 0.90, 0.32, 0.80, 1.10)
            self._adapt_threshold("emergency_threat", threat * 0.90, 0.44, 0.90, 1.25)
            self._adapt_threshold("emergency_hp", hp + 0.020, 0.08, 0.30, 1.10)
            if max(before.novelty, before.phase_shift) >= self.threshold("novelty_probe"):
                self._adapt_threshold("novelty_probe", max(before.novelty, before.phase_shift) + 0.04, 0.38, 0.82, 1.05)
        elif effective:
            for name in ("critical_hp", "critical_impact", "critical_threat", "survival_hp", "evade_impact", "evade_trend", "evade_telegraph", "evade_threat", "evade_incoming", "emergency_hp", "emergency_impact", "emergency_trend", "emergency_telegraph", "emergency_incoming", "emergency_threat"):
                self._adapt_threshold(name, self.policy_defaults[name], 0.02, 0.98, 0.28)
            distance = before.distance
            if distance is not None and (float(raw[2]) > 0.002 or float(raw[10]) > 0.025) and action in ("J", "JJJ", "KJ", "CHASEJ", "U", "I", "O", "L", "UJ", "IJ", "OJ", "LJ", "SPACEJ"):
                distance = max(0.02, min(0.80, float(distance)))
                self._adapt_threshold("mid_distance", distance * 0.82, 0.10, 0.30, 0.85)
                self._adapt_threshold("far_distance", distance + 0.10, 0.24, 0.56, 0.85)
                if before.opening > 0.0:
                    self._adapt_threshold("opening", before.opening * 0.94, 0.40, 0.82, 0.70)
            discovery = max(float(raw[4]), float(raw[5]), float(raw[10]))
            if discovery > 0.08 and max(before.novelty, before.phase_shift) > 0.0:
                self._adapt_threshold("novelty_probe", max(before.novelty, before.phase_shift) * 0.96, 0.38, 0.82, 0.65)

    def feature(self, state):
        base = (
            self._v(state.hp), self._v(state.mp), self._v(state.boss), self._v(state.distance, 0.6),
            (state.target_side + 1.0) / 2.0,
            max(0.0, min(1.0, state.motion / 12.0)), self._v(state.novelty), self._v(state.crowd),
            max(0.0, min(1.0, state.edge_energy)),
            (max(-1.0, min(1.0, state.flow_x)) + 1.0) / 2.0,
            (max(-1.0, min(1.0, state.flow_y)) + 1.0) / 2.0,
            self._v(state.active_x), self._v(state.active_y), self._v(state.threat, 0.0),
            self._v(state.incoming, 0.0), self._v(state.dealt, 0.0), self._v(state.combo, 0.0),
            self._v(state.engaged, 0.0), self._v(state.advantage, 0.5), self._v(state.progress, 0.0),
            self._v(state.telegraph, 0.0), (max(-1.0, min(1.0, state.escape_side)) + 1.0) / 2.0,
            self._v(state.opening, 0.0), self._v(state.phase_shift, 0.0),
            (max(-1.0, min(1.0, state.risk_trend)) + 1.0) / 2.0,
            self._v(state.impact_risk, 0.0),
        )
        latent = tuple(max(0.0, min(1.0, float(x))) for x in tuple(state.latent or ())[:self.latent_dim])
        if len(latent) < self.latent_dim:
            pattern = (0.5, 0.25, 0.0)
            defaults = tuple(pattern[i % 3] for i in range(self.latent_dim))
            latent = latent + defaults[len(latent):]
        return base + latent

    def _normalize_feature(self, feature):
        if not feature:
            return None
        values = list(feature)
        if len(values) == 42:
            values = values[:24] + [0.5, 0.0] + values[24:]
        base_defaults = [
            0.5, 0.5, 0.5, 0.6, 0.5, 0.0, 0.5, 0.0, 0.0, 0.5, 0.5, 0.5,
            0.55, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.0, 0.0, 0.5, 0.0, 0.0,
            0.5, 0.0,
        ]
        pattern = (0.5, 0.25, 0.0)
        defaults = base_defaults + [pattern[i % 3] for i in range(self.latent_dim)]
        if len(values) < len(defaults):
            values.extend(defaults[len(values):])
        return tuple(float(x) for x in values[:len(defaults)])

    def _distance(self, a, b):
        a = self._normalize_feature(a)
        b = self._normalize_feature(b)
        if not a or not b:
            return 99.0
        base_weights = (
            1.8, 1.1, 2.0, 1.7, 1.0, 0.55, 0.42, 0.55, 0.30, 0.30,
            0.30, 0.28, 0.28, 1.70, 1.50, 1.65, 1.05, 0.85, 1.10, 0.65,
            1.62, 0.72, 1.15, 0.86, 1.30, 1.72,
        )
        latent_pattern = (0.34, 0.20, 0.46)
        weights = base_weights + tuple(latent_pattern[i % 3] for i in range(self.latent_dim))
        return math.sqrt(sum(w * (x - y) ** 2 for w, x, y in zip(weights, a, b)) / sum(weights))

    @staticmethod
    def _raw_effect(before, after):
        def delta(a, b):
            return 0.0 if a is None or b is None else float(b) - float(a)
        hp = delta(before.hp, after.hp)
        mp = delta(before.mp, after.mp)
        boss_damage = 0.0 if before.boss is None or after.boss is None else float(before.boss) - float(after.boss)
        approach = 0.0 if before.distance is None or after.distance is None else float(before.distance) - float(after.distance)
        scene = max(0.0, min(4.0, after.scene_change)) / 4.0
        novelty = max(-1.0, min(1.0, after.novelty - before.novelty))
        motion = max(-1.0, min(1.0, (after.motion - before.motion) / 10.0))
        lateral = 0.0
        if before.player_x is not None and after.player_x is not None:
            lateral = max(-0.5, min(0.5, float(after.player_x) - float(before.player_x)))
        threat_relief = max(-1.0, min(1.0, float(before.threat) - float(after.threat)))
        combo_gain = max(-1.0, min(1.0, float(after.combo) - float(before.combo)))
        advantage_gain = max(-1.0, min(1.0, float(after.advantage) - float(before.advantage)))
        return (hp, mp, boss_damage, approach, scene, novelty, motion, lateral, threat_relief, combo_gain, advantage_gain)

    def _context_key_from_feature(self, feature):
        feature = self._normalize_feature(feature)
        if not feature:
            feature = self._normalize_feature([0.5] * (26 + self.latent_dim))
        picks = (0, 2, 3, 4, 6, 7, 13, 20, 22, 23, 24, 25)
        parts = []
        for index in picks:
            value = max(0.0, min(0.999, float(feature[index])))
            parts.append(str(int(value * 4.0)))
        latent = feature[26:26 + self.latent_dim]
        for offset in range(0, len(latent), 3):
            chunk = list(latent[offset:offset + 3])
            while len(chunk) < 3:
                chunk.append((0.5, 0.25, 0.0)[len(chunk)])
            value = chunk[0] * 0.42 + chunk[1] * 0.20 + chunk[2] * 0.38
            parts.append(str(int(max(0.0, min(0.999, value)) * 4.0)))
        return "".join(parts)

    def _rebuild_index(self):
        self.by_action = {key: [] for key in self.ACTIONS}
        self.by_action["WAIT"] = []
        self.by_context_action = {}
        for item in self.memory:
            action = item.get("a")
            if action in self.by_action:
                self.by_action[action].append(item)
                feature = item.get("f")
                context = str(item.get("c") or self._context_key_from_feature(feature))[:18]
                item["c"] = context
                self.by_context_action.setdefault((context, action), []).append(item)

    @staticmethod
    def _bounded_candidates(items, cap=1200):
        items = list(items or ())
        if len(items) <= cap:
            return items
        newest = items[-min(360, cap // 3):]
        older = items[:-len(newest)]
        need = max(0, cap - len(newest))
        if not older or need <= 0:
            return newest
        step = max(1, len(older) // need)
        sampled = older[::step][:need]
        return sampled + newest

    def _maybe_cuda(self, row_count):
        if self.torch_checked or row_count < 800 or "NVIDIA" not in str(getattr(self.profile, "gpu_name", "")).upper():
            return self.torch
        base_dir = os.path.dirname(os.path.abspath(self.path)) or "."
        if _dependency_job_named(base_dir, ("torch_cuda",)):
            return None
        if _cuda_marker_blocks(base_dir, self.profile):
            self.torch_checked = True
            return None
        self.torch_checked = True
        try:
            torch = importlib.import_module("torch")
            if torch.cuda.is_available():
                index = max(0, int(getattr(self.profile, "gpu_index", 0) or 0))
                if index >= int(torch.cuda.device_count()):
                    index = 0
                self.cuda_device = f"cuda:{index}"
                self.torch = torch
                self.compute_backend = f"CUDA:{index}"
        except Exception:
            self.torch = None
        return self.torch

    def _nearest(self, action, feature, limit=18):
        context = self._context_key_from_feature(feature)[:18]
        local = self.by_context_action.get((context, action), ())
        if len(local) >= max(5, limit // 2):
            candidates = self._bounded_candidates(local, self.neighbor_scan_cap)
        else:
            global_items = self._bounded_candidates(self.by_action.get(action, ()), self.neighbor_scan_cap)
            if local:
                seen = {id(item) for item in local}
                candidates = list(local) + [item for item in global_items if id(item) not in seen]
            else:
                candidates = global_items
        normalized = self._normalize_feature(feature)
        if self.np is not None and normalized and len(candidates) >= 24:
            items = []
            features = []
            for item in candidates:
                f = item.get("f")
                if f:
                    items.append(item)
                    features.append(f)
            if features:
                try:
                    np = self.np
                    matrix = np.asarray(features, dtype=np.float32)
                    target = np.asarray(normalized, dtype=np.float32)
                    weights = np.asarray((1.8, 1.1, 2.0, 1.7, 1.0, 0.55, 0.42, 0.55, 0.30, 0.30, 0.30, 0.28, 0.28, 1.70, 1.50, 1.65, 1.05, 0.85, 1.10, 0.65, 1.62, 0.72, 1.15, 0.86, 1.30, 1.72) + (0.34, 0.20, 0.46) * 6, dtype=np.float32)
                    torch = self._maybe_cuda(len(items))
                    if torch is not None:
                        with torch.no_grad():
                            tm = torch.from_numpy(matrix).to(self.cuda_device)
                            tt = torch.from_numpy(target).to(self.cuda_device)
                            tw = torch.from_numpy(weights).to(self.cuda_device)
                            distances = torch.sqrt(((tm - tt) ** 2 * tw).sum(dim=1) / tw.sum())
                            count = min(max(1, int(limit)), len(items))
                            values, indices = torch.topk(distances, count, largest=False, sorted=True)
                            vals = values.cpu().tolist()
                            inds = indices.cpu().tolist()
                        return [(float(value), items[int(index)]) for value, index in zip(vals, inds)]
                    distances = np.sqrt(((matrix - target) ** 2 * weights).sum(axis=1) / weights.sum())
                    count = min(max(1, int(limit)), len(items))
                    if count < len(items):
                        indices = np.argpartition(distances, count - 1)[:count]
                        indices = indices[np.argsort(distances[indices])]
                    else:
                        indices = np.argsort(distances)
                    return [(float(distances[int(index)]), items[int(index)]) for index in indices[:count]]
                except Exception:
                    if str(self.compute_backend).startswith("CUDA"):
                        self.torch = None
                        self.compute_backend = "NumPy"
        rows = []
        for item in candidates:
            f = item.get("f")
            if not f:
                continue
            rows.append((self._distance(feature, f), item))
        return heapq.nsmallest(limit, rows, key=lambda pair: pair[0])

    def _prepare_neural_cache(self, state, actions):
        if self.neural is None or not self.neural.active:
            self.neural_cache_feature = None
            self.neural_cache = {}
            return
        feature = self._normalize_feature(self.feature(state))
        rows = self.neural.predict_pairs([feature] * len(actions), list(actions))
        self.neural_cache_feature = feature
        self.neural_cache = dict(zip(actions, rows)) if rows else {}

    def _neural_prediction(self, action, state):
        if self.neural is None or not self.neural.active:
            return None
        feature = self._normalize_feature(self.feature(state))
        if self.neural_cache_feature == feature and action in self.neural_cache:
            return self.neural_cache[action]
        rows = self.neural.predict_pairs([feature], [action])
        return rows[0] if rows else None

    def _blend_neural(self, result, uncertainty, n, action, state):
        neural = self._neural_prediction(action, state)
        if neural is None:
            return result, uncertainty, n
        learned, _, neural_uncertainty, neural_n = neural
        confidence = max(0.0, min(1.0, 1.0 - neural_uncertainty))
        blend = min(0.78, 0.18 + confidence * 0.56)
        if n <= 0:
            blend = min(0.88, blend + 0.16)
        result = tuple(float(result[i]) * (1.0 - blend) + float(learned[i]) * blend for i in range(self.EFFECT_DIM))
        uncertainty = min(1.0, float(uncertainty) * (1.0 - blend * 0.55) + neural_uncertainty * blend * 0.72)
        return result, uncertainty, max(int(n), int(neural_n))

    def _effect_context_key(self, state):
        return self._context_key(state)[:12]

    def _context_effect_predict(self, action, state):
        bucket = self.context_effect_stats.get(self._effect_context_key(state)) or {}
        row = bucket.get(action) or {}
        n = max(0, int(row.get("n", 0)))
        effect = list(row.get("e") or ())
        if n <= 0 or len(effect) < self.EFFECT_DIM:
            return None, 1.0, 0
        effect = tuple(float(x) for x in effect[:self.EFFECT_DIM])
        err = max(0.0, min(2.0, float(row.get("err", 0.0))))
        uncertainty = min(0.92, 0.50 / math.sqrt(n + 0.35) + err * 0.34)
        return effect, uncertainty, n

    def predict(self, action, state, causal=True):
        direct, direct_uncertainty, direct_n = self._context_effect_predict(action, state)
        if direct_n >= 2:
            result = direct
            if causal and action != "WAIT":
                baseline, _, baseline_n = self._context_effect_predict("WAIT", state)
                if baseline_n >= 2:
                    result = tuple(result[i] - baseline[i] for i in range(self.EFFECT_DIM))
            return self._blend_neural(result, direct_uncertainty, direct_n, action, state)
        feature = self.feature(state)
        rows = self._nearest(action, feature)
        if not rows:
            if direct_n:
                return self._blend_neural(direct, direct_uncertainty, direct_n, action, state)
            return self._blend_neural((0.0,) * self.EFFECT_DIM, 1.0, 0, action, state)
        accum = [0.0] * self.EFFECT_DIM
        total = 0.0
        distances = []
        for distance, item in rows:
            weight = 1.0 / (0.035 + distance * distance)
            effect = list(item.get("e") or ())
            if len(effect) < self.EFFECT_DIM:
                effect.extend([0.0] * (self.EFFECT_DIM - len(effect)))
            for i in range(self.EFFECT_DIM):
                accum[i] += float(effect[i]) * weight
            total += weight
            distances.append(distance)
        result = tuple(value / max(total, 1e-9) for value in accum)
        if direct_n:
            blend = min(0.45, direct_n / 5.0)
            result = tuple(result[i] * (1.0 - blend) + direct[i] * blend for i in range(self.EFFECT_DIM))
        if causal and action != "WAIT":
            baseline, _, baseline_n = self.predict("WAIT", state, causal=False)
            if baseline_n:
                result = tuple(result[i] - baseline[i] for i in range(self.EFFECT_DIM))
        uncertainty = min(1.0, (sum(distances) / len(distances)) * 1.75 + 0.88 / math.sqrt(len(rows) + 0.5))
        if direct_n:
            uncertainty = min(uncertainty, direct_uncertainty + 0.10)
        return self._blend_neural(result, uncertainty, max(len(rows), direct_n), action, state)

    def _plan_predict(self, action, state):
        effect, uncertainty, n = self._context_effect_predict(action, state)
        if n <= 0:
            return (0.0,) * self.EFFECT_DIM, 1.0, 0
        if action != "WAIT":
            baseline, _, baseline_n = self._context_effect_predict("WAIT", state)
            if baseline_n >= 2:
                effect = tuple(effect[i] - baseline[i] for i in range(self.EFFECT_DIM))
        return effect, uncertainty, n

    @staticmethod
    def _utility(state):
        hp = 0.62 if state.hp is None else state.hp
        value = (
            hp * 2.9 + state.advantage * 0.75 + state.opening * 0.42
            - state.threat * (1.0 + max(0.0, 0.35 - hp) * 3.0)
            - state.telegraph * (0.46 + max(0.0, 0.32 - hp) * 1.6)
            - state.impact_risk * (0.72 + max(0.0, 0.42 - hp) * 2.1)
            - max(0.0, state.risk_trend) * 0.28
            - state.phase_shift * 0.08
        )
        if state.boss is not None:
            value += (1.0 - state.boss) * 5.6
        if state.distance is not None:
            ideal = 0.13 if max(state.threat, state.impact_risk) < 0.55 else 0.25
            value -= abs(min(0.52, state.distance) - ideal) * 0.36
        value += state.combo * 0.32 + state.progress * 0.12
        return value

    def _simulate(self, state, effect):
        hp, mp, boss_damage, approach, scene, novelty, motion, lateral, threat_relief, combo_gain, advantage_gain = effect
        def clamp(v):
            return max(0.0, min(1.0, v))
        relief = max(0.0, threat_relief)
        injury = max(0.0, -hp)
        return WorldState(
            hp=None if state.hp is None else clamp(state.hp + hp),
            mp=None if state.mp is None else clamp(state.mp + mp),
            boss=None if state.boss is None else clamp(state.boss - boss_damage),
            player_x=None if state.player_x is None else clamp(state.player_x + lateral),
            target_x=state.target_x,
            distance=None if state.distance is None else clamp(state.distance - approach),
            target_side=state.target_side,
            motion=max(0.0, state.motion + motion * 10.0),
            scene_change=max(0.0, scene * 4.0), novelty=clamp(state.novelty + novelty),
            flow_x=state.flow_x, flow_y=state.flow_y, crowd=state.crowd, edge_energy=state.edge_energy,
            active_x=state.active_x, active_y=state.active_y,
            threat=clamp(state.threat - threat_relief), incoming=clamp(state.incoming - relief * 0.50 + injury * 0.55), dealt=state.dealt,
            combo=clamp(state.combo + combo_gain), engaged=state.engaged,
            advantage=clamp(state.advantage + advantage_gain), progress=state.progress,
            telegraph=clamp(state.telegraph - relief * 0.65),
            escape_side=state.escape_side,
            opening=clamp(state.opening + max(0.0, advantage_gain) * 0.35 + max(0.0, combo_gain) * 0.20 - injury * 0.45),
            phase_shift=state.phase_shift,
            risk_trend=max(-1.0, min(1.0, state.risk_trend * 0.62 - relief * 0.80 + injury * 0.70)),
            impact_risk=clamp(state.impact_risk * 0.76 - relief * 0.90 + injury * 0.82),
            latent=state.latent,
            fingerprint=state.fingerprint, captured_at=state.captured_at,
        )

    def _bootstrap_prior(self, action, state):
        hp = 0.7 if state.hp is None else state.hp
        mp = 0.7 if state.mp is None else state.mp
        distance = state.distance
        near = distance is None or distance < 0.24
        mid = distance is not None and 0.12 <= distance <= 0.38
        far = distance is not None and distance > 0.30
        threat = max(state.threat, state.impact_risk * 0.92)
        rising = max(0.0, state.risk_trend)
        boss_known = state.boss is not None
        prior = 0.0
        if action == "TOWARD":
            prior += 0.30 if far else (0.10 if mid else -0.10)
            prior -= threat * 0.30 + rising * 0.12
        elif action == "RETREAT":
            prior += threat * 0.48 + state.telegraph * 0.30 + state.impact_risk * 0.36 + rising * 0.24 + max(0.0, 0.34 - hp) * 0.75
            if hp > 0.72 and threat < 0.25 and state.telegraph < 0.25:
                prior -= 0.18
        elif action == "EVADE":
            prior += state.telegraph * 0.72 + threat * 0.42 + state.incoming * 0.34 + state.impact_risk * 0.62 + rising * 0.36
            if hp < 0.28:
                prior += 0.20
            if state.opening > 0.65 and state.telegraph < 0.30 and state.impact_risk < 0.32:
                prior -= 0.18
        elif action == "PARAM":
            prior += state.opening * 0.10 + state.combo * 0.07 + max(state.novelty, state.phase_shift) * 0.08
            prior += 0.05 if distance is not None else -0.02
            prior -= max(0.0, threat - 0.72) * 0.18
        elif action in ("J", "JJJ", "CHASEJ"):
            prior += (0.24 if near else (0.12 if mid else -0.10)) * (1.0 - threat * 0.55)
            prior += state.opening * 0.17 - state.telegraph * 0.15 - state.impact_risk * 0.16
            if action == "JJJ":
                prior += state.combo * 0.18 - threat * 0.10
            if action == "CHASEJ":
                prior += 0.18 if mid else -0.03
        elif action in ("U", "I", "O", "L", "UJ", "IJ", "OJ", "LJ"):
            prior += 0.25 if near or mid else -0.08
            prior += state.combo * 0.13 - state.impact_risk * 0.10
            if mp < 0.13:
                prior -= 0.36
            elif mp < 0.25:
                prior -= 0.10
            if hp < 0.20 and threat > 0.45:
                prior -= 0.18
        elif action in ("SPACE", "SPACEJ"):
            prior += (0.20 if boss_known else 0.04) + threat * 0.13 + state.combo * 0.12
            if action == "SPACEJ" and not near and not mid:
                prior -= 0.12
        elif action == "H":
            prior += max(0.0, 0.52 - hp) * 1.05 + threat * 0.24 + state.impact_risk * 0.14 - (0.12 if hp > 0.80 else 0.0)
        elif action in ("K", "KJ"):
            prior += threat * 0.28 + state.impact_risk * 0.28 + rising * 0.14 + (0.12 if near else 0.02)
            if action == "KJ" and near:
                prior += 0.08
        elif action in ("A", "D") and state.target_side:
            toward = (action == "D" and state.target_side > 0) or (action == "A" and state.target_side < 0)
            prior += (0.12 if toward else -0.05) - threat * (0.16 if toward else -0.05)
        elif action == "F":
            prior += 0.14 if state.engaged < 0.30 and state.motion < 2.8 else -0.05
        elif action in ("W", "S"):
            prior += 0.065 if state.engaged < 0.35 else -0.025
        elif action == "Z":
            prior += 0.045 if state.engaged < 0.25 and state.progress < 0.25 else -0.09
        return prior

    def _bootstrap_weight(self, action, state, model_uncertainty=None):
        context_bucket = self.context_stats.get(self._context_key(state)) or {}
        context_n = max(0, int((context_bucket.get(action) or {}).get("n", 0)))
        effect_bucket = self.context_effect_stats.get(self._effect_context_key(state)) or {}
        effect_n = max(0, int((effect_bucket.get(action) or {}).get("n", 0)))
        global_n = max(0, int(self.action_counts.get(action, 0)))
        _, context_uncertainty, _, _ = self._context_value(action, state)
        uncertainty = context_uncertainty if model_uncertainty is None else max(context_uncertainty, max(0.0, min(1.0, float(model_uncertainty))))
        evidence = context_n + effect_n + math.sqrt(global_n) * 0.45
        confidence = 1.0 - math.exp(-evidence / 7.5)
        return max(0.04, min(1.0, (1.0 - confidence) * (0.58 + uncertainty * 0.42) + uncertainty * 0.16))

    @staticmethod
    def _transition_reward(effect, state):
        hp, _, boss_damage, approach, scene, _, _, _, threat_relief, combo_gain, advantage_gain = effect
        low_hp = 0.7 if state.hp is None else max(0.0, 0.40 - state.hp) * 2.5
        return (
            boss_damage * 7.0 + hp * (2.2 + low_hp * 2.0) + max(0.0, approach) * 0.50
            + scene * 0.24 + threat_relief * (1.2 + low_hp) + combo_gain * 0.45 + advantage_gain * 0.65
        )

    def _pair_bonus(self, action):
        if not self.last_executed_action or time.monotonic() - self.last_executed_at > 1.5:
            return 0.0
        item = self.pair_stats.get(self.last_executed_action + ">" + action)
        if not item or item.get("n", 0) <= 0:
            return 0.0
        n = item["n"]
        mean = item.get("r", 0.0) / max(n, 1)
        return max(-0.28, min(0.42, mean * min(0.55, math.log1p(n) / 5.0)))

    def _sequence_bonus(self, action):
        now = time.monotonic()
        recent = [a for a, stamp in self.action_history if now - stamp <= 2.2]
        if len(recent) < 2:
            return 0.0
        key = recent[-2] + ">" + recent[-1] + ">" + action
        item = self.triple_stats.get(key)
        if not item or item.get("n", 0) <= 0:
            return 0.0
        n = item["n"]
        mean = item.get("r", 0.0) / max(n, 1)
        return max(-0.24, min(0.50, mean * min(0.62, math.log1p(n) / 4.5)))

    def learned_sequence_candidates(self, state, available, limit=3):
        ranked = []
        for action in available:
            pair = self._pair_bonus(action)
            triple = self._sequence_bonus(action)
            ctx_mean, _, ctx_n, ctx_bad = self._context_value(action, state)
            score = pair + triple + ctx_mean * min(0.36, math.log1p(ctx_n) * 0.11) - ctx_bad * 0.42
            if score > 0.055:
                ranked.append((score, action))
        ranked.sort(reverse=True)
        return [action for _, action in ranked[:max(0, int(limit))]]

    def adaptive_effect_delay(self, action, fallback):
        learned = float(self.effect_latency.get(action, 0.0) or 0.0)
        if learned <= 0.0:
            return fallback
        return max(0.14, min(0.95, fallback * 0.35 + learned * 0.65))

    def local_sample_count(self, action, state, radius=0.24):
        feature = self.feature(state)
        count = 0
        for distance, _ in self._nearest(action, feature, limit=18):
            if distance <= radius:
                count += 1
        return count

    def context_confidence(self, state, actions=None):
        actions = tuple(actions or self.ACTIONS)
        if not actions:
            return 0.0
        samples = [min(6, self.local_sample_count(action, state)) for action in actions]
        coverage = sum(1 for n in samples if n > 0) / len(samples)
        density = sum(samples) / (len(samples) * 6.0)
        context_samples = [min(6, self.context_sample_count(action, state)) for action in actions]
        context_density = sum(context_samples) / (len(context_samples) * 6.0)
        return max(0.0, min(1.0, coverage * 0.52 + density * 0.30 + context_density * 0.18))

    def _context_key(self, state):
        return self._context_key_from_feature(self.feature(state))

    def context_sample_count(self, action, state):
        bucket = self.context_stats.get(self._context_key(state)) or {}
        row = bucket.get(action) or {}
        return max(0, int(row.get("n", 0)))

    def _context_value(self, action, state):
        bucket = self.context_stats.get(self._context_key(state)) or {}
        row = bucket.get(action) or {}
        n = max(0, int(row.get("n", 0)))
        if n <= 0:
            return 0.0, 1.0, 0, 0.0
        mean = float(row.get("mean", 0.0))
        m2 = max(0.0, float(row.get("m2", 0.0)))
        variance = m2 / max(1, n - 1)
        uncertainty = min(1.0, 0.72 / math.sqrt(n) + min(0.55, math.sqrt(variance) * 0.22))
        bad = max(0, int(row.get("bad", 0)))
        ok = max(0, min(n, int(row.get("ok", 0))))
        failure_rate = (n - ok) / max(1, n)
        bad_rate = min(1.0, bad / max(1, n) * 0.82 + failure_rate * (0.24 if n >= 3 else 0.10))
        return math.tanh(mean * 0.55), uncertainty, n, bad_rate


    def _terminal_context_value(self, action, state):
        bucket = self.terminal_context_stats.get(self._context_key(state)) or {}
        row = bucket.get(action) or {}
        wins = max(0.0, float(row.get("w", 0.0)))
        losses = max(0.0, float(row.get("l", 0.0)))
        total = wins + losses
        if total <= 0.0:
            return 0.0, 0.0
        value = (wins - losses) / (total + 3.0)
        confidence = min(1.0, total / 7.0)
        return value, confidence


    @staticmethod
    def _probe_cost(action):
        return {
            "F": 0.02, "A": 0.03, "D": 0.03, "W": 0.04, "S": 0.04,
            "TOWARD": 0.04, "RETREAT": 0.03, "K": 0.06, "EVADE": 0.06, "PARAM": 0.11,
            "J": 0.08, "KJ": 0.10, "CHASEJ": 0.10, "JJJ": 0.12,
            "U": 0.16, "I": 0.16, "O": 0.16, "L": 0.16,
            "UJ": 0.20, "IJ": 0.20, "OJ": 0.20, "LJ": 0.20,
            "H": 0.26, "Z": 0.28, "SPACE": 0.32, "SPACEJ": 0.36,
        }.get(action, 0.12)

    def _mechanic_value(self, action, state):
        bucket = self.context_stats.get(self._context_key(state)) or {}
        row = bucket.get(action) or {}
        return (
            max(0.0, min(1.0, float(row.get("discover", 0.0)))),
            max(0.0, min(1.0, float(row.get("control", 0.0)))),
        )

    def probe_score(self, action, state):
        ctx_mean, ctx_uncertainty, ctx_n, ctx_bad = self._context_value(action, state)
        local = self.local_sample_count(action, state, radius=0.27)
        discovery, control = self._mechanic_value(action, state)
        hp = 0.7 if state.hp is None else state.hp
        safety = max(0.0, min(1.0, (hp - 0.22) / 0.58)) * max(0.0, 1.0 - max(state.threat, state.impact_risk))
        unknown = 1.0 / math.sqrt(ctx_n + local + 1.0)
        prior = self._bootstrap_prior(action, state) * self._bootstrap_weight(action, state, ctx_uncertainty)
        return (
            unknown * (0.56 + max(state.novelty, state.phase_shift) * 0.44) * safety
            + discovery * 0.42 + control * 0.24 + ctx_mean * 0.18 + prior * 0.14
            - ctx_bad * (0.85 + state.impact_risk * 0.55)
            - self._probe_cost(action) * (0.32 + max(0.0, 0.56 - hp) * 0.75)
            + ctx_uncertainty * safety * 0.08
        )

    def _update_context(self, action, before, after, reward, raw, effective):
        if action == "WAIT":
            return
        key = self._context_key(before)
        bucket = self.context_stats.setdefault(key, {})
        row = bucket.setdefault(action, {
            "n": 0, "mean": 0.0, "m2": 0.0, "bad": 0, "ok": 0,
            "discover": 0.0, "control": 0.0,
        })
        n0 = max(0, int(row.get("n", 0)))
        mean0 = float(row.get("mean", 0.0))
        m20 = max(0.0, float(row.get("m2", 0.0)))
        n1 = n0 + 1
        delta = reward - mean0
        mean1 = mean0 + delta / n1
        m21 = m20 + delta * (reward - mean1)
        row["n"] = n1
        row["mean"] = max(-6.0, min(6.0, mean1))
        row["m2"] = max(0.0, min(120.0, m21))
        if effective:
            row["ok"] = max(0, int(row.get("ok", 0))) + 1
        hp_loss = max(0.0, -float(raw[0]))
        danger_jump = max(0.0, float(after.threat) - float(before.threat))
        impact_jump = max(0.0, float(after.impact_risk) - float(before.impact_risk))
        crossed_critical = before.hp is not None and after.hp is not None and before.hp > 0.10 >= after.hp
        catastrophic = hp_loss >= 0.065 or danger_jump >= 0.30 or impact_jump >= 0.34 or crossed_critical
        if catastrophic:
            row["bad"] = max(0, int(row.get("bad", 0))) + 1
        discovery = max(0.0, min(1.0, raw[4] * 0.52 + max(0.0, raw[5]) * 0.18 + after.progress * 0.30))
        control = max(0.0, min(1.0,
            max(0.0, raw[2]) * 3.2 + abs(raw[3]) * 1.8 + raw[4] * 0.42
            + abs(raw[7]) * 2.2 + max(0.0, raw[8]) * 0.55 + max(0.0, raw[10]) * 0.45
        ))
        old_discover = max(0.0, min(1.0, float(row.get("discover", 0.0))))
        old_control = max(0.0, min(1.0, float(row.get("control", 0.0))))
        alpha = max(0.10, min(0.42, 1.6 / (n1 + 2.0)))
        row["discover"] = old_discover * (1.0 - alpha) + discovery * alpha
        row["control"] = old_control * (1.0 - alpha) + control * alpha
        if len(self.context_stats) > self.max_contexts:
            ranked = sorted(
                self.context_stats.items(),
                key=lambda pair: sum(max(0, int(v.get("n", 0))) for v in pair[1].values()),
            )
            for old_key, _ in ranked[:max(1, len(self.context_stats) - self.max_contexts)]:
                self.context_stats.pop(old_key, None)

    def _update_context_effect(self, action, before, raw):
        key = self._effect_context_key(before)
        bucket = self.context_effect_stats.setdefault(key, {})
        row = bucket.setdefault(action, {"n": 0, "e": [0.0] * self.EFFECT_DIM, "err": 0.0})
        n0 = max(0, int(row.get("n", 0)))
        old = list(row.get("e") or ())
        if len(old) < self.EFFECT_DIM:
            old.extend([0.0] * (self.EFFECT_DIM - len(old)))
        n1 = n0 + 1
        alpha = max(0.015, min(0.34, 1.0 / math.sqrt(n1)))
        delta_error = sum(abs(float(raw[i]) - float(old[i])) for i in range(self.EFFECT_DIM)) / self.EFFECT_DIM
        row["e"] = [float(old[i]) * (1.0 - alpha) + float(raw[i]) * alpha for i in range(self.EFFECT_DIM)]
        row["n"] = min(2000000, n1)
        row["err"] = max(0.0, min(2.0, float(row.get("err", 0.0)) * 0.94 + delta_error * 0.06))
        if len(self.context_effect_stats) > self.max_contexts * 2:
            ranked = sorted(
                self.context_effect_stats.items(),
                key=lambda pair: sum(max(0, int(v.get("n", 0))) for v in pair[1].values()),
            )
            remove = max(1, len(self.context_effect_stats) - self.max_contexts * 2)
            for old_key, _ in ranked[:remove]:
                self.context_effect_stats.pop(old_key, None)

    def _planning_subset(self, state, limit=8):
        ranked = []
        effect_bucket = self.context_effect_stats.get(self._effect_context_key(state)) or {}
        context_bucket = self.context_stats.get(self._context_key(state)) or {}
        for action in self.ACTIONS:
            prior = self._bootstrap_prior(action, state) * self._bootstrap_weight(action, state)
            effect_n = max(0, int((effect_bucket.get(action) or {}).get("n", 0)))
            context_n = max(0, int((context_bucket.get(action) or {}).get("n", 0)))
            learned = min(1.0, math.log1p(effect_n + context_n) / math.log(24.0))
            ranked.append((prior + learned * 0.095, action))
        ranked.sort(reverse=True)
        return [action for _, action in ranked[:max(4, limit)]]

    def _lookahead_value(self, state, depth, width, deadline=None):
        if depth <= 0 or (deadline is not None and time.perf_counter() >= deadline):
            return 0.0
        actions = self._planning_subset(state, max(4, width))
        neural_rows = {}
        if self.neural is not None and self.neural.active and actions:
            feature = self._normalize_feature(self.feature(state))
            rows = self.neural.predict_pairs([feature] * len(actions), actions)
            if rows:
                neural_rows = dict(zip(actions, rows))
        ranked = []
        for action in actions:
            if deadline is not None and ranked and time.perf_counter() >= deadline:
                break
            predicted, uncertainty, n = self._plan_predict(action, state)
            neural = neural_rows.get(action)
            if neural is not None:
                learned, learned_value, neural_uncertainty, neural_n = neural
                blend = 0.72 if n else 0.88
                predicted = tuple(float(predicted[i]) * (1.0 - blend) + float(learned[i]) * blend for i in range(self.EFFECT_DIM))
                uncertainty = min(uncertainty, neural_uncertainty + 0.06) if n else neural_uncertainty
                n = max(n, neural_n)
            else:
                learned_value = None
            if not n:
                continue
            future = self._simulate(state, predicted)
            step = self._utility(future) - self._utility(state)
            if learned_value is not None:
                step += max(-2.0, min(2.0, learned_value - self._utility(state))) * 0.18
            step -= uncertainty * (0.05 + state.impact_risk * 0.08 + state.threat * 0.04)
            ranked.append((step, future, n))
        if not ranked:
            return 0.0
        ranked.sort(key=lambda item: item[0], reverse=True)
        if depth <= 1:
            return ranked[0][0]
        beam = max(2, min(len(ranked), int(math.sqrt(max(4, width))) + (2 if self.neural is not None and self.neural.active else 0)))
        best = None
        next_width = max(4, width - 1 if self.neural is not None and self.neural.active else width - 2)
        for step, future, n in ranked[:beam]:
            continuation = 0.0
            if n >= 2:
                continuation = self._lookahead_value(future, depth - 1, next_width, deadline)
            total = step + continuation * 0.43
            if best is None or total > best:
                best = total
        return 0.0 if best is None else best

    def _batched_cuda_rollout(self, state, root_actions, depth, deadline=None):
        neural = self.neural
        if neural is None or not neural.active or neural.steps < 3 or depth <= 1 or not root_actions:
            return None
        if deadline is not None and time.perf_counter() >= deadline:
            return None
        roots = list(root_actions)
        root_feature = self._normalize_feature(self.feature(state))
        rows = neural.predict_pairs([root_feature] * len(roots), roots)
        if not rows:
            return None
        frontier = []
        for root, row in zip(roots, rows):
            effect, _, uncertainty, _ = row
            future = self._simulate(state, effect)
            frontier.append((root, future, -uncertainty * 0.03))
        best = {root: -1e18 for root in roots}
        width = max(4, int(math.sqrt(max(4, self.runtime_candidate_budget))) + depth)
        batch_limit = max(len(roots), neural.batch_size * max(1, int(math.sqrt(max(1, depth)))))
        discount = 0.43
        for level in range(1, max(1, depth)):
            if deadline is not None and time.perf_counter() >= deadline:
                break
            features = []
            actions = []
            metadata = []
            for root, current, cumulative in frontier:
                subset = self._planning_subset(current, width)
                for action in subset:
                    features.append(self._normalize_feature(self.feature(current)))
                    actions.append(action)
                    metadata.append((root, current, cumulative))
                    if len(metadata) >= batch_limit:
                        break
                if len(metadata) >= batch_limit:
                    break
            if not metadata:
                break
            rows = neural.predict_pairs(features, actions)
            if not rows:
                return None
            next_frontier = []
            for action, meta, row in zip(actions, metadata, rows):
                root, current, cumulative = meta
                effect, learned_value, uncertainty, n = row
                future = self._simulate(current, effect)
                step = self._utility(future) - self._utility(current)
                step += max(-2.0, min(2.0, learned_value - self._utility(current))) * 0.18
                step -= uncertainty * (0.05 + current.impact_risk * 0.08 + current.threat * 0.04)
                total = cumulative + step * (discount ** level)
                if total > best[root]:
                    best[root] = total
                if n >= 2 and level + 1 < depth:
                    next_frontier.append((root, future, total))
            if not next_frontier:
                break
            next_frontier.sort(key=lambda item: item[2], reverse=True)
            frontier = next_frontier[:batch_limit]
            width = max(4, width + max(1, int(math.sqrt(max(1, self.runtime_candidate_budget))) // 2))
        return {root: value for root, value in best.items() if value > -1e17}

    def action_score(self, action, state, depth=2, deadline=None, external_lookahead=None):
        effect, uncertainty, n = self.predict(action, state)
        future = self._simulate(state, effect)
        gain = self._utility(future) - self._utility(state)
        hp = 0.7 if state.hp is None else state.hp
        boss_damage = max(0.0, effect[2])
        threat_relief = effect[8]
        gain += boss_damage * 5.3 + effect[0] * (4.0 if hp < 0.32 else 1.4) + threat_relief * (2.0 if hp < 0.32 else 0.75)
        gain += self._bootstrap_prior(action, state) * self._bootstrap_weight(action, state, uncertainty) / math.sqrt(n + 1.0)
        gain += self._pair_bonus(action)
        gain += self._sequence_bonus(action)
        ctx_mean, ctx_uncertainty, ctx_n, ctx_bad = self._context_value(action, state)
        ctx_confidence = min(1.0, ctx_n / 6.0)
        gain += ctx_mean * (0.10 + ctx_confidence * 0.48)
        discovery, control = self._mechanic_value(action, state)
        novel = max(state.novelty, state.phase_shift)
        gain += discovery * (0.08 + novel * 0.42) + control * (0.05 + novel * 0.16)

        predicted_mp_cost = max(0.0, -effect[1])
        if state.mp is not None and predicted_mp_cost > state.mp * 0.72:
            gain -= (predicted_mp_cost - state.mp * 0.72) * 2.4
        terminal = self.terminal_stats.get(action, {})
        terminal_n = terminal.get("w", 0) + terminal.get("l", 0)
        if terminal_n:
            gain += (terminal.get("w", 0) - terminal.get("l", 0)) / (terminal_n + 4.0) * 0.24
        local_terminal, local_terminal_conf = self._terminal_context_value(action, state)
        gain += local_terminal * (0.18 + local_terminal_conf * 0.46)

        safety = max(0.0, min(1.0, (hp - 0.18) / 0.55)) * max(0.0, 1.0 - max(state.threat, state.impact_risk))
        novelty_drive = max(0.0, min(1.0, novel)) * safety
        information = (uncertainty + ctx_uncertainty * 0.72) / math.sqrt(ctx_n + n + 1.0)
        exploration = (0.08 + novelty_drive * 0.50) * uncertainty / math.sqrt(n + 1.0)
        exploration += information * novelty_drive * 0.28
        if n == 0 and novelty_drive > 0.35:
            exploration += 0.10 * novelty_drive
        probe_cost = self._probe_cost(action)
        exploration -= probe_cost * novelty_drive * (0.11 + max(0.0, 0.55 - hp) * 0.24)

        risk = uncertainty * (
            0.08 + state.threat * 0.18 + state.telegraph * 0.22 + state.impact_risk * 0.32
            + max(0.0, state.risk_trend) * 0.18 + state.phase_shift * 0.08 + max(0.0, 0.35 - hp) * 1.05
        )
        risk += ctx_bad * (0.18 + state.threat * 0.36 + state.impact_risk * 0.42 + max(0.0, 0.42 - hp) * 0.78)
        if ctx_n >= 2 and ctx_bad >= 0.48 and action not in ("EVADE", "RETREAT", "K", "KJ", "H"):
            risk += 0.34 + ctx_bad * 0.55
        score = gain + exploration - risk

        if depth > 1 and n >= 3:
            if external_lookahead is not None:
                score += float(external_lookahead.get(action, 0.0)) * 0.42
            else:
                width = max(5, 4 + depth + max(0, int(math.log2(max(1, n)))) + int(math.sqrt(max(1, self.runtime_candidate_budget))))
                score += self._lookahead_value(future, depth - 1, width, deadline) * 0.42
        return score, uncertainty, n

    def choose(self, state, available, depth=2, deadline=None):
        available = list(available)
        if not available:
            return None, 0.0
        hp = 0.7 if state.hp is None else state.hp
        critical = hp < self.threshold("critical_hp") or state.impact_risk >= self.threshold("critical_impact") or state.threat >= self.threshold("critical_threat")
        if critical:
            defensive = {"EVADE", "RETREAT", "K", "KJ", "H", "A", "D", "SPACE"}
            filtered = []
            for action in available:
                _, _, ctx_n, ctx_bad = self._context_value(action, state)
                if action in defensive or ctx_n < 2 or ctx_bad < 0.45:
                    filtered.append(action)
            if filtered:
                available = filtered
        self._prepare_neural_cache(state, available)
        cuda_rollout = self._batched_cuda_rollout(state, available, depth, deadline)
        scored = []
        for action in available:
            if deadline is not None and scored and time.perf_counter() >= deadline:
                break
            score, uncertainty, n = self.action_score(action, state, depth=depth, deadline=deadline, external_lookahead=cuda_rollout)
            scored.append((score, -uncertainty, n, action))
        if not scored:
            return None, 0.0
        scored.sort(reverse=True)
        best = scored[0]
        total = sum(self.action_counts.get(a, 0) for a in available)
        safety = max(0.0, min(1.0, (hp - 0.20) / 0.55)) * (1.0 - max(state.threat, state.impact_risk))
        context_conf = self.context_confidence(state, available)
        contextual = max(0.0, min(1.0, max(state.novelty, state.phase_shift))) * safety
        contextual *= 0.30 + 0.70 * (1.0 - context_conf)
        maturity = min(1.0, math.log1p(max(0, self.lifetime_updates)) / math.log(250001.0))
        epsilon = max(0.0025, 0.050 / math.sqrt(total / max(len(available), 1) + 1.0))
        epsilon *= 1.0 - 0.46 * maturity * context_conf
        epsilon = min(0.15, epsilon + contextual * (0.10 - 0.035 * maturity))
        if len(scored) > 1 and random.random() < epsilon:
            pool = scored[:min(6 if contextual > 0.45 else 3, len(scored))]
            if contextual > 0.30:
                ranked = sorted(pool, key=lambda item: self.probe_score(item[3], state), reverse=True)
                best = ranked[0]
            else:
                best = random.choice(pool)
        return best[3], best[0]

    def choose_iterative(self, state, available, budget_seconds):
        available = list(available)
        if not available:
            return None, 0.0, 1, True
        started = time.perf_counter()
        deadline = started + max(0.0015, float(budget_seconds))
        best_action = None
        best_score = 0.0
        completed_depth = 0
        depth = 1
        complete = True
        while time.perf_counter() < deadline:
            iteration_started = time.perf_counter()
            action, score = self.choose(state, available, depth=depth, deadline=deadline)
            ended = time.perf_counter()
            if action is not None:
                best_action, best_score = action, score
            if ended >= deadline:
                complete = False
                break
            completed_depth = depth
            remaining = deadline - ended
            iteration_cost = max(0.00005, ended - iteration_started)
            if iteration_cost * 1.30 >= remaining:
                break
            if depth >= 2 and not any(self.context_sample_count(action, state) >= 3 for action in available):
                break
            depth += 1
        return best_action, best_score, max(1, completed_depth), complete

    def _components(self, action):
        if action in self.PRIMITIVES:
            return (action,)
        return self.COMPONENTS.get(action, ())

    def available(self, now, skill_ready=None):
        skill_ready = skill_ready or {}
        result = []
        for action in self.ACTIONS:
            if now - self.last_action_at.get(action, -9999.0) < self.retry_delay.get(action, 0.16):
                continue
            blocked = False
            for key in self._components(action):
                if skill_ready.get(key) is False:
                    blocked = True
                    break
                if now - self.key_last_at.get(key, -9999.0) < self.key_gap.get(key, 0.10):
                    blocked = True
                    break
            if not blocked:
                result.append(action)
        return result

    def sample_timing(self, action):
        row = self.timing_stats.get(action) or {"down": 1.0, "gap": 1.0, "n": 0}
        n = max(0, int(row.get("n", 0)))
        sigma = max(0.018, 0.12 / math.sqrt(n / 5.0 + 1.0))
        down = max(0.58, min(1.52, random.gauss(float(row.get("down", 1.0)), sigma)))
        gap = max(0.58, min(1.58, random.gauss(float(row.get("gap", 1.0)), sigma)))
        sample = {"down": down, "gap": gap}
        self.pending_timing = (action, sample)
        return sample

    def timing_value(self, action, kind, base, sample=None):
        row = sample or (self.timing_stats.get(action) or {})
        scale = max(0.55, min(1.65, float(row.get(kind, 1.0))))
        return max(0.006, float(base) * scale)

    def _learn_timing(self, action, reward, effective):
        if not self.pending_timing or self.pending_timing[0] != action:
            return
        sample = self.pending_timing[1]
        self.pending_timing = None
        row = self.timing_stats.setdefault(action, {"down": 1.0, "gap": 1.0, "n": 0})
        n = max(0, int(row.get("n", 0)))
        quality = max(-1.0, min(1.0, float(reward) / 1.8 + (0.16 if effective else -0.10)))
        rate = max(0.012, min(0.11, 0.32 / math.sqrt(n + 9.0)))
        for kind in ("down", "gap"):
            mean = max(0.58, min(1.58, float(row.get(kind, 1.0))))
            trial = max(0.58, min(1.58, float(sample.get(kind, mean))))
            if quality >= 0.0:
                mean += (trial - mean) * rate * (0.35 + quality)
            else:
                mean -= (trial - mean) * rate * min(0.85, -quality)
            row[kind] = max(0.62, min(1.48, mean))
        row["n"] = min(2000000, n + 1)

    def note_execution(self, action, now, components=None, state=None, timing=None):
        if action in self.last_action_at:
            self.last_action_at[action] = now
        self.action_counts[action] = self.action_counts.get(action, 0) + 1
        keys = tuple(components or self._components(action))
        for key in keys:
            if key in self.key_last_at:
                self.key_last_at[key] = now
        history_recent = [(a, stamp) for a, stamp in self.action_history if now - stamp <= 8.0]
        sequence_recent = [(a, stamp) for a, stamp in history_recent if now - stamp <= 2.2]
        previous = sequence_recent[-1][0] if sequence_recent else None
        pair_key = previous + ">" + action if previous else None
        triple_key = None
        if len(sequence_recent) >= 2:
            triple_key = sequence_recent[-2][0] + ">" + sequence_recent[-1][0] + ">" + action
        self.pending_pair = (action, pair_key)
        self.pending_triple = (action, triple_key)
        self.action_history = (history_recent + [(action, now)])[-8:]
        self.last_executed_action = action
        self.last_executed_at = now
        if timing is not None:
            self.pending_timing = (action, dict(timing))
        if state is not None and action != "WAIT":
            context = self._context_key(state)
            self.credit_history = [(a, stamp, ctx) for a, stamp, ctx in self.credit_history if now - stamp <= 75.0]
            self.credit_history.append((action, now, context))
            self.credit_history = self.credit_history[-96:]

    def record(self, action, before, after, effective=None, raw_override=None, observed_latency=None):
        raw = tuple(raw_override) if raw_override is not None else self._raw_effect(before, after)
        feature = self._normalize_feature(self.feature(before))
        magnitude = abs(raw[0]) * 2.0 + max(0.0, raw[2]) * 6.0 + abs(raw[3]) + raw[4] * 0.35 + abs(raw[8]) + abs(raw[10])
        priority = max(0.0, min(4.0, float(before.novelty) * 1.15 + magnitude + (0.55 if effective else 0.0)))
        context = self._context_key_from_feature(feature)[:18]
        item = {"a": action, "c": context, "f": list(feature), "e": list(raw), "q": priority}
        self.memory.append(item)
        if action in self.by_action:
            self.by_action[action].append(item)
            self.by_context_action.setdefault((context, action), []).append(item)
        self._update_context_effect(action, before, raw)
        if len(self.memory) > self.max_memory + max(160, self.max_memory // 30):

            recent_start = max(0, len(self.memory) - 700)
            old = self.memory[:recent_start]
            recent = self.memory[recent_start:]
            old.sort(key=lambda item: float(item.get("q", 0.0)), reverse=True)
            self.memory = old[:max(0, self.max_memory - len(recent))] + recent
            self._rebuild_index()
        self.action_counts[action] = max(self.action_counts.get(action, 0), 1)
        self.total_updates += 1
        self.lifetime_updates += 1
        neural_reward = self._transition_reward(raw, before)
        if self.neural is not None and self.neural.active:
            self.neural.add(feature, action, raw, neural_reward + self._utility(after) * 0.82)
            self.compute_backend = self.neural.backend
        if action != "WAIT":
            if effective is None:
                effective = raw[2] > 0.003 or abs(raw[3]) > 0.012 or raw[4] > 0.10 or raw[0] > 0.01 or raw[8] > 0.04
            old = self.retry_delay.get(action, 0.16)
            stamp = after.captured_at or time.monotonic()
            if effective:
                self.last_effective_at[action] = stamp
                self.retry_delay[action] = max(0.11, old * 0.82)
                latency_value = observed_latency
                if latency_value is None:
                    latency_value = (after.captured_at or stamp) - (before.captured_at or stamp)
                latency = max(0.10, min(1.20, float(latency_value)))
                learned = self.effect_latency.get(action, 0.0)
                self.effect_latency[action] = latency if learned <= 0.0 else learned * 0.82 + latency * 0.18
            else:
                since_effective = stamp - self.last_effective_at.get(action, -9999.0)
                if 0.0 <= since_effective < max(1.0, old * 2.8):
                    self.retry_delay[action] = min(8.0, old * 1.20 + 0.04)
                else:
                    self.retry_delay[action] = max(0.11, old * 0.99)
            for key in self._components(action):
                if key in ("U", "I", "O", "L", "H", "SPACE", "Z"):
                    base = self.BASE_KEY_GAP[key]
                    old_gap = self.key_gap.get(key, base)
                    if effective:
                        self.key_gap[key] = max(base, old_gap * 0.97)
                    else:
                        self.key_gap[key] = min(9.0, old_gap * 1.045 + 0.012)
            reward = self._transition_reward(raw, before)
            self._learn_timing(action, reward, bool(effective))
            self._update_context(action, before, after, reward, raw, bool(effective))
            self._learn_policy_priors(action, before, after, raw, bool(effective))
            if self.pending_pair and self.pending_pair[0] == action and self.pending_pair[1]:
                key = self.pending_pair[1]
                item = self.pair_stats.setdefault(key, {"n": 0, "r": 0.0})
                item["n"] += 1
                item["r"] += reward
                if len(self.pair_stats) > 720:
                    weakest = sorted(self.pair_stats, key=lambda k: self.pair_stats[k].get("n", 0))[:90]
                    for name in weakest:
                        self.pair_stats.pop(name, None)
            if self.pending_triple and self.pending_triple[0] == action and self.pending_triple[1]:
                key = self.pending_triple[1]
                item = self.triple_stats.setdefault(key, {"n": 0, "r": 0.0})
                item["n"] += 1
                item["r"] += reward
                if len(self.triple_stats) > 900:
                    weakest = sorted(self.triple_stats, key=lambda k: self.triple_stats[k].get("n", 0))[:120]
                    for name in weakest:
                        self.triple_stats.pop(name, None)
            self.pending_pair = None
            self.pending_triple = None
        if self.total_updates % 64 == 0:
            self.save()
        return raw

    def note_terminal(self, won):
        now = time.monotonic()
        if won is None:
            self.credit_history = []
            self.pending_pair = None
            self.pending_triple = None
            return
        recent = [(action, stamp) for action, stamp in self.action_history if action in self.terminal_stats and now - stamp <= 12.0]
        field = "w" if won else "l"
        for reverse_index, (action, stamp) in enumerate(reversed(recent[-8:])):
            temporal = math.exp(-max(0.0, now - stamp) / 7.0)
            weight = (0.76 ** reverse_index) * temporal
            if weight < 0.04:
                continue
            self.terminal_stats[action][field] += weight
        credited = [(a, stamp, ctx) for a, stamp, ctx in self.credit_history if now - stamp <= 60.0]
        for reverse_index, (action, stamp, context) in enumerate(reversed(credited[-40:])):
            temporal = math.exp(-max(0.0, now - stamp) / 24.0)
            weight = (0.92 ** reverse_index) * temporal
            if weight < 0.025:
                continue
            bucket = self.terminal_context_stats.setdefault(context, {})
            row = bucket.setdefault(action, {"w": 0.0, "l": 0.0})
            row[field] = min(5000.0, max(0.0, float(row.get(field, 0.0))) + weight)
        self.credit_history = []
        if len(self.terminal_context_stats) > self.max_contexts:
            ranked = sorted(
                self.terminal_context_stats.items(),
                key=lambda pair: sum(float(v.get("w", 0.0)) + float(v.get("l", 0.0)) for v in pair[1].values()),
            )
            for old_key, _ in ranked[:max(1, len(self.terminal_context_stats) - self.max_contexts)]:
                self.terminal_context_stats.pop(old_key, None)

    def needs_baseline(self):
        wait_samples = sum(1 for item in self.memory if item.get("a") == "WAIT")
        action_samples = sum(1 for item in self.memory if item.get("a") != "WAIT")
        return wait_samples < 3 or wait_samples * 18 < action_samples

    def model_confidence(self):
        action_samples = sum(min(10, self.action_counts.get(a, 0)) for a in self.ACTIONS)
        pair_samples = min(80, sum(item.get("n", 0) for item in self.pair_stats.values()))
        triple_samples = min(90, sum(item.get("n", 0) for item in self.triple_stats.values()))
        context_samples = min(180, sum(
            max(0, int(row.get("n", 0)))
            for bucket in self.context_stats.values() for row in bucket.values()
        ))
        lifetime = min(1.0, math.log1p(max(0, self.lifetime_updates)) / math.log(120001.0))
        return min(1.0,
            action_samples / (len(self.ACTIONS) * 7.0) * 0.54
            + pair_samples / 80.0 * 0.12
            + triple_samples / 90.0 * 0.08
            + context_samples / 180.0 * 0.18
            + lifetime * 0.08
        )

    def _save_loop(self):
        while not self.save_stop.is_set():
            self.save_event.wait(0.5)
            if self.save_stop.is_set():
                break
            if not self.save_event.is_set():
                continue
            self.save_event.clear()
            self._save_now(False)

    def save(self, force=False):
        if force:
            self.save_stop.set()
            self.save_event.set()
            if self.save_thread is not None and self.save_thread.is_alive() and threading.current_thread() is not self.save_thread:
                self.save_thread.join(1.5)
            self._save_now(True)
        else:
            self.save_event.set()

    def _save_now(self, force=False):
        now = time.monotonic()
        if not force and now - self.last_save < self.save_interval:
            return
        _, free_gb = _storage_status(os.path.dirname(self.path) or ".")
        if free_gb > 0.0 and free_gb < 0.08:
            if self.persistence is not None:
                self.persistence.fail("world", "所选数据盘剩余空间不足")
            return
        if self.neural is not None and self.neural.active:
            self.neural.save(force=force)
        data = {
            "version": 9, "memory": self.memory[-self.max_memory:], "counts": self.action_counts,
            "retry_delay": self.retry_delay, "key_gap": self.key_gap, "pair_stats": self.pair_stats,
            "triple_stats": self.triple_stats, "context_stats": self.context_stats,
            "context_effect_stats": self.context_effect_stats,
            "effect_latency": self.effect_latency, "policy_priors": self.policy_priors,
            "policy_counts": self.policy_counts, "context_policy_priors": self.context_policy_priors,
            "context_policy_counts": self.context_policy_counts, "timing_stats": self.timing_stats, "terminal_stats": self.terminal_stats,
            "terminal_context_stats": self.terminal_context_stats, "environment": self.environment_fingerprint,
            "lifetime_updates": self.lifetime_updates,
        }
        tmp = self.path + ".tmp"
        backup = self.path + ".bak"
        try:
            with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=5) as handle:
                json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
            with gzip.open(tmp, "rt", encoding="utf-8") as handle:
                check = json.load(handle)
            if not isinstance(check, dict) or check.get("version") != 9:
                raise ValueError("世界模型保存校验失败")
            if os.path.isfile(self.path):
                try:
                    shutil.copy2(self.path, backup)
                except OSError:
                    pass
            os.replace(tmp, self.path)
            self.last_save = now
            if self.persistence is not None:
                self.persistence.ok("world")
        except (OSError, ValueError, TypeError, json.JSONDecodeError, EOFError) as exc:
            if self.persistence is not None:
                self.persistence.fail("world", exc)
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    def _load(self):
        data = None
        loaded_from_legacy = False
        try:
            sources = []
            if os.path.isfile(self.path):
                sources.append((self.path, False, True))
            backup = self.path + ".bak"
            if os.path.isfile(backup):
                sources.append((backup, False, False))
            if self.legacy_path and os.path.isfile(self.legacy_path):
                sources.append((self.legacy_path, True, False))
            for source, legacy, quarantine in sources:
                try:
                    if legacy:
                        with open(source, "r", encoding="utf-8") as handle:
                            candidate = json.load(handle)
                    else:
                        with gzip.open(source, "rt", encoding="utf-8") as handle:
                            candidate = json.load(handle)
                    if not isinstance(candidate, dict) or candidate.get("version") not in (2, 3, 4, 5, 6, 7, 8, 9):
                        raise ValueError("世界模型版本或结构无效")
                    data = candidate
                    loaded_from_legacy = legacy
                    break
                except (OSError, ValueError, TypeError, json.JSONDecodeError, EOFError):
                    if quarantine:
                        try:
                            bad = self.path + f".corrupt.{int(time.time())}"
                            os.replace(self.path, bad)
                        except OSError:
                            pass
            if data is None:
                return
            environment = data.get("environment") or {}
            self.loaded_environment = environment if isinstance(environment, dict) else {}
            compatible = True
            if self.loaded_environment:
                if str(self.loaded_environment.get("game_id") or "100072570") != str(self.environment_fingerprint["game_id"]):
                    compatible = False
                saved_actions = tuple(self.loaded_environment.get("action_set") or ())
                if saved_actions and not set(saved_actions).issubset(set(self.ACTIONS)):
                    compatible = False
                if int(self.loaded_environment.get("effect_dim", self.EFFECT_DIM) or self.EFFECT_DIM) != self.EFFECT_DIM:
                    compatible = False
                saved_schema = int(self.loaded_environment.get("model_schema", 9) or 9)
                if abs(saved_schema - int(self.environment_fingerprint["model_schema"])) > 1:
                    compatible = False
            memory = (data.get("memory") or []) if compatible else []
            loaded = []
            for item in memory[-self.max_memory:]:
                if item.get("a") not in self.action_counts and item.get("a") != "WAIT":
                    continue
                f = self._normalize_feature(item.get("f"))
                e = list(item.get("e") or ())
                if len(e) < self.EFFECT_DIM:
                    e.extend([0.0] * (self.EFFECT_DIM - len(e)))
                context = str(item.get("c") or self._context_key_from_feature(f))[:18]
                loaded.append({
                    "a": item.get("a"), "c": context, "f": list(f) if f else [], "e": e[:self.EFFECT_DIM],
                    "q": max(0.0, min(4.0, float(item.get("q", 0.0)))),
                })
            self.memory = loaded
            self._rebuild_index()
            counts = data.get("counts") or {}
            for key in self.action_counts:
                if key in counts:
                    self.action_counts[key] = max(0, int(counts[key]))
            delays = data.get("retry_delay") or {}
            for key in self.retry_delay:
                if key in delays:
                    self.retry_delay[key] = max(0.11, min(8.0, float(delays[key])))
            gaps = data.get("key_gap") or {}
            for key, base in self.BASE_KEY_GAP.items():
                if key in gaps:
                    self.key_gap[key] = max(base, min(9.0, float(gaps[key])))
            pairs = data.get("pair_stats") or {}
            for key, item in pairs.items():
                if isinstance(item, dict):
                    n = max(0, int(item.get("n", 0)))
                    r = float(item.get("r", 0.0))
                    if n:
                        self.pair_stats[str(key)] = {"n": n, "r": r}
            triples = data.get("triple_stats") or {}
            for key, item in triples.items():
                if isinstance(item, dict):
                    n = max(0, int(item.get("n", 0)))
                    r = float(item.get("r", 0.0))
                    if n:
                        self.triple_stats[str(key)] = {"n": n, "r": r}
            contexts = data.get("context_stats") or {}
            if isinstance(contexts, dict):
                for context_key, bucket in list(contexts.items())[-self.max_contexts:]:
                    if not isinstance(bucket, dict):
                        continue
                    clean_bucket = {}
                    for action, row in bucket.items():
                        if action not in self.ACTIONS or not isinstance(row, dict):
                            continue
                        n = max(0, int(row.get("n", 0)))
                        if not n:
                            continue
                        clean_bucket[action] = {
                            "n": min(2000000, n),
                            "mean": max(-6.0, min(6.0, float(row.get("mean", 0.0)))),
                            "m2": max(0.0, min(120.0, float(row.get("m2", 0.0)))),
                            "bad": max(0, min(n, int(row.get("bad", 0)))),
                            "ok": max(0, min(n, int(row.get("ok", 0)))),
                            "discover": max(0.0, min(1.0, float(row.get("discover", 0.0)))),
                            "control": max(0.0, min(1.0, float(row.get("control", 0.0)))),
                        }
                    if clean_bucket:
                        self.context_stats[str(context_key)[:32]] = clean_bucket
            context_effects = data.get("context_effect_stats") or {}
            if isinstance(context_effects, dict):
                for context_key, bucket in list(context_effects.items())[-self.max_contexts * 2:]:
                    if not isinstance(bucket, dict):
                        continue
                    clean_bucket = {}
                    for action, row in bucket.items():
                        if action not in self.by_action or not isinstance(row, dict):
                            continue
                        n = max(0, int(row.get("n", 0)))
                        effect = list(row.get("e") or ())
                        if n <= 0 or len(effect) < self.EFFECT_DIM:
                            continue
                        clean_bucket[action] = {
                            "n": min(2000000, n),
                            "e": [max(-4.0, min(4.0, float(x))) for x in effect[:self.EFFECT_DIM]],
                            "err": max(0.0, min(2.0, float(row.get("err", 0.0)))),
                        }
                    if clean_bucket:
                        self.context_effect_stats[str(context_key)[:16]] = clean_bucket
            latencies = data.get("effect_latency") or {}
            for key in self.effect_latency:
                if key in latencies:
                    self.effect_latency[key] = max(0.0, min(1.2, float(latencies[key])))
            timing = data.get("timing_stats") or {}
            for key in self.timing_stats:
                row = timing.get(key)
                if isinstance(row, dict):
                    self.timing_stats[key] = {
                        "down": max(0.62, min(1.48, float(row.get("down", 1.0)))),
                        "gap": max(0.62, min(1.48, float(row.get("gap", 1.0)))),
                        "n": max(0, min(2000000, int(row.get("n", 0)))),
                    }
            priors = data.get("policy_priors") or {}
            counts_prior = data.get("policy_counts") or {}
            for key, default in self.policy_defaults.items():
                if key in priors:
                    self.policy_priors[key] = max(0.02, min(0.98, float(priors[key])))
                if key in counts_prior:
                    self.policy_counts[key] = max(0, min(100000000, int(counts_prior[key])))
            context_priors = data.get("context_policy_priors") or {}
            context_counts = data.get("context_policy_counts") or {}
            if isinstance(context_priors, dict):
                for context, bucket in list(context_priors.items())[-self.max_contexts:]:
                    if not isinstance(bucket, dict):
                        continue
                    clean = {name: max(0.02, min(0.98, float(value))) for name, value in bucket.items() if name in self.policy_defaults}
                    if clean:
                        key = str(context)[:32]
                        self.context_policy_priors[key] = clean
                        raw_counts = context_counts.get(context) if isinstance(context_counts, dict) else {}
                        self.context_policy_counts[key] = {name: max(0, min(100000000, int((raw_counts or {}).get(name, 0)))) for name in clean}
            terminal = data.get("terminal_stats") or {}
            for key in self.terminal_stats:
                item = terminal.get(key)
                if isinstance(item, dict):
                    self.terminal_stats[key] = {"w": max(0.0, float(item.get("w", 0.0))), "l": max(0.0, float(item.get("l", 0.0)))}
            terminal_contexts = data.get("terminal_context_stats") or {}
            if isinstance(terminal_contexts, dict):
                for context_key, bucket in list(terminal_contexts.items())[-self.max_contexts:]:
                    if not isinstance(bucket, dict):
                        continue
                    clean = {}
                    for action, row in bucket.items():
                        if action not in self.ACTIONS or not isinstance(row, dict):
                            continue
                        wins = max(0.0, min(5000.0, float(row.get("w", 0.0))))
                        losses = max(0.0, min(5000.0, float(row.get("l", 0.0))))
                        if wins + losses > 0.0:
                            clean[action] = {"w": wins, "l": losses}
                    if clean:
                        self.terminal_context_stats[str(context_key)[:32]] = clean
            self.lifetime_updates = max(0, int(data.get("lifetime_updates", sum(self.action_counts.values()))))
            if loaded_from_legacy:
                self.last_save = -9999.0
        except (OSError, ValueError, TypeError, json.JSONDecodeError, EOFError):
            pass


class HumanInputMonitor:
    WH_KEYBOARD_LL = 13
    WH_MOUSE_LL = 14
    WM_KEYDOWN = 0x0100
    WM_KEYUP = 0x0101
    WM_SYSKEYDOWN = 0x0104
    WM_SYSKEYUP = 0x0105
    WM_MOUSEMOVE = 0x0200
    WM_LBUTTONDOWN = 0x0201
    WM_LBUTTONUP = 0x0202
    WM_RBUTTONDOWN = 0x0204
    WM_RBUTTONUP = 0x0205
    WM_MBUTTONDOWN = 0x0207
    WM_MBUTTONUP = 0x0208
    WM_MOUSEWHEEL = 0x020A
    WM_XBUTTONDOWN = 0x020B
    WM_XBUTTONUP = 0x020C
    WM_MOUSEHWHEEL = 0x020E
    WM_QUIT = 0x0012

    def __init__(self, io, abort_event=None):
        self.io = io
        self.abort_event = abort_event
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.lock = threading.RLock()
        self.active = False
        self.reason = ""
        self.triggered = threading.Event()
        self.shutdown = threading.Event()
        self.ready = threading.Event()
        self.mode = "starting"
        self.thread_id = 0
        self.last_point = None
        self.initial_mouse_buttons = set()
        self.keyboard_hook = 0
        self.mouse_hook = 0
        self.proc_type = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
        self.keyboard_proc = self.proc_type(self._keyboard)
        self.mouse_proc = self.proc_type(self._mouse)
        self.user32.SetWindowsHookExW.argtypes = [ctypes.c_int, self.proc_type, wintypes.HANDLE, wintypes.DWORD]
        self.user32.SetWindowsHookExW.restype = wintypes.HANDLE
        self.user32.UnhookWindowsHookEx.argtypes = [wintypes.HANDLE]
        self.user32.UnhookWindowsHookEx.restype = wintypes.BOOL
        self.user32.CallNextHookEx.argtypes = [wintypes.HANDLE, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
        self.user32.CallNextHookEx.restype = ctypes.c_ssize_t
        self.user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
        self.user32.GetMessageW.restype = wintypes.BOOL
        self.user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        self.user32.PostThreadMessageW.restype = wintypes.BOOL
        self.user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user32.GetAsyncKeyState.restype = ctypes.c_short
        self.user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
        self.user32.GetCursorPos.restype = wintypes.BOOL
        self.kernel32.GetCurrentThreadId.restype = wintypes.DWORD
        self.kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
        self.kernel32.GetModuleHandleW.restype = wintypes.HANDLE
        self.release_event = threading.Event()
        self.release_thread = threading.Thread(target=self._release_loop, daemon=True)
        self.release_thread.start()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _release_loop(self):
        while not self.shutdown.is_set():
            self.release_event.wait(0.25)
            if self.shutdown.is_set():
                break
            if self.release_event.is_set():
                self.release_event.clear()
                self.io.release_all()

    def wait_ready(self, timeout=1.5):
        return self.ready.wait(max(0.0, float(timeout)))

    def arm(self):
        point = POINT()
        cursor = (int(point.x), int(point.y)) if self.user32.GetCursorPos(ctypes.byref(point)) else None
        with self.lock:
            self.reason = ""
            self.triggered.clear()
            self.last_point = cursor
            self.initial_mouse_buttons = {vk for vk in (1, 2, 4, 5, 6) if self.user32.GetAsyncKeyState(vk) & 0x8000}
            self.active = True

    def disarm(self):
        with self.lock:
            self.active = False
            self.reason = ""
            self.initial_mouse_buttons.clear()
            self.triggered.clear()

    def take_trigger(self):
        if not self.triggered.is_set():
            return ""
        with self.lock:
            reason = self.reason or "键鼠"
            self.active = False
            self.triggered.clear()
            return reason

    def _trigger(self, reason):
        with self.lock:
            if not self.active or self.triggered.is_set():
                return
            self.reason = reason
            self.active = False
            if self.abort_event is not None:
                self.abort_event.set()
            self.release_event.set()
            self.triggered.set()

    def _keyboard(self, code, wparam, lparam):
        try:
            if code >= 0 and int(wparam) in (self.WM_KEYDOWN, self.WM_KEYUP, self.WM_SYSKEYDOWN, self.WM_SYSKEYUP):
                item = ctypes.cast(lparam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                if int(item.dwExtraInfo) != int(self.io.input_tag):
                    self._trigger("键盘")
        except Exception:
            try:
                self._trigger("键盘")
            except Exception:
                pass
        finally:
            try:
                return self.user32.CallNextHookEx(self.keyboard_hook, code, wparam, lparam)
            except Exception:
                return 0

    def _mouse(self, code, wparam, lparam):
        try:
            if code >= 0:
                item = ctypes.cast(lparam, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                if int(item.dwExtraInfo) != int(self.io.input_tag):
                    message = int(wparam)
                    point = (int(item.pt.x), int(item.pt.y))
                    if message == self.WM_MOUSEMOVE:
                        old = self.last_point
                        self.last_point = point
                        if old is not None and abs(point[0] - old[0]) + abs(point[1] - old[1]) >= 1:
                            self._trigger("鼠标")
                    else:
                        if message == self.WM_XBUTTONUP:
                            release_vk = 5 if ((int(item.mouseData) >> 16) & 0xFFFF) == 1 else 6
                        else:
                            release_vk = {self.WM_LBUTTONUP: 1, self.WM_RBUTTONUP: 2, self.WM_MBUTTONUP: 4}.get(message)
                        if release_vk in self.initial_mouse_buttons:
                            self.initial_mouse_buttons.discard(release_vk)
                        elif message in (self.WM_LBUTTONDOWN, self.WM_LBUTTONUP, self.WM_RBUTTONDOWN, self.WM_RBUTTONUP, self.WM_MBUTTONDOWN, self.WM_MBUTTONUP, self.WM_MOUSEWHEEL, self.WM_MOUSEHWHEEL, self.WM_XBUTTONDOWN, self.WM_XBUTTONUP):
                            self._trigger("鼠标")
        except Exception:
            try:
                self._trigger("鼠标")
            except Exception:
                pass
        finally:
            try:
                return self.user32.CallNextHookEx(self.mouse_hook, code, wparam, lparam)
            except Exception:
                return 0

    def _run(self):
        self.thread_id = int(self.kernel32.GetCurrentThreadId())
        module = self.kernel32.GetModuleHandleW(None)
        self.keyboard_hook = self.user32.SetWindowsHookExW(self.WH_KEYBOARD_LL, self.keyboard_proc, module, 0)
        self.mouse_hook = self.user32.SetWindowsHookExW(self.WH_MOUSE_LL, self.mouse_proc, module, 0)
        if not self.keyboard_hook or not self.mouse_hook:
            if self.keyboard_hook:
                self.user32.UnhookWindowsHookEx(self.keyboard_hook)
                self.keyboard_hook = 0
            if self.mouse_hook:
                self.user32.UnhookWindowsHookEx(self.mouse_hook)
                self.mouse_hook = 0
            self.mode = "fallback"
            self.ready.set()
            self._poll_fallback()
            return
        self.mode = "hook"
        self.ready.set()
        msg = wintypes.MSG()
        while not self.shutdown.is_set():
            value = self.user32.GetMessageW(ctypes.byref(msg), 0, 0, 0)
            if value <= 0:
                break
        if self.keyboard_hook:
            self.user32.UnhookWindowsHookEx(self.keyboard_hook)
            self.keyboard_hook = 0
        if self.mouse_hook:
            self.user32.UnhookWindowsHookEx(self.mouse_hook)
            self.mouse_hook = 0

    def _poll_fallback(self):
        point = POINT()
        last = None
        while not self.shutdown.is_set():
            if self.user32.GetCursorPos(ctypes.byref(point)):
                current = (int(point.x), int(point.y))
                if last is not None and abs(current[0] - last[0]) + abs(current[1] - last[1]) >= 1:
                    if not self.io.ai_mouse_recent(current, 0.15, 3):
                        self._trigger("鼠标")
                last = current
            for vk in (1, 2, 4, 5, 6):
                down = bool(self.user32.GetAsyncKeyState(vk) & 0x8000)
                if vk in self.initial_mouse_buttons:
                    if not down:
                        self.initial_mouse_buttons.discard(vk)
                    continue
                if down and not self.io.ai_mouse_button_active() and not self.io.ai_mouse_recent(None, 0.15, 3):
                    self._trigger("鼠标")
                    break
            for vk in range(8, 256):
                if self.user32.GetAsyncKeyState(vk) & 0x8000 and not self.io.ai_key_held(vk) and not self.io.ai_key_recent(vk, 0.15):
                    self._trigger("键盘")
                    break
            self.shutdown.wait(0.018)

    def close(self):
        self.disarm()
        self.shutdown.set()
        self.release_event.set()
        if self.thread_id:
            self.user32.PostThreadMessageW(self.thread_id, self.WM_QUIT, 0, 0)
        if self.thread.is_alive():
            self.thread.join(0.6)
        if self.release_thread.is_alive():
            self.release_thread.join(0.4)


class WinIO:
    INPUT_MOUSE = 0
    INPUT_KEYBOARD = 1
    KEYEVENTF_KEYUP = 0x0002
    MOUSEEVENTF_MOVE = 0x0001
    MOUSEEVENTF_LEFTDOWN = 0x0002
    MOUSEEVENTF_LEFTUP = 0x0004
    MOUSEEVENTF_VIRTUALDESK = 0x4000
    MOUSEEVENTF_ABSOLUTE = 0x8000
    SW_MAXIMIZE = 3
    WM_CLOSE = 0x0010
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

    def __init__(self):
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
        try:
            self.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except Exception:
            try:
                self.user32.SetProcessDPIAware()
            except Exception:
                pass
        self.user32.IsWindowVisible.argtypes = [wintypes.HWND]
        self.user32.IsWindowVisible.restype = wintypes.BOOL
        self.user32.IsWindow.argtypes = [wintypes.HWND]
        self.user32.IsWindow.restype = wintypes.BOOL
        self.user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        self.user32.GetWindowTextLengthW.restype = ctypes.c_int
        self.user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user32.GetForegroundWindow.restype = wintypes.HWND
        self.user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        self.user32.BringWindowToTop.argtypes = [wintypes.HWND]
        self.user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        self.user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
        self.user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
        self.user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
        self.user32.GetDC.restype = wintypes.HDC
        self.user32.GetDC.argtypes = [wintypes.HWND]
        self.user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        self.user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
        self.user32.SendInput.restype = wintypes.UINT
        self.user32.GetSystemMetrics.argtypes = [ctypes.c_int]
        self.user32.GetSystemMetrics.restype = ctypes.c_int
        self.user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user32.GetAsyncKeyState.restype = ctypes.c_short
        self.user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
        self.user32.GetCursorPos.restype = wintypes.BOOL
        self.user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        self.user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
        self.user32.MonitorFromWindow.restype = wintypes.HANDLE
        self.user32.GetMonitorInfoW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MONITORINFOEXW)]
        self.user32.GetMonitorInfoW.restype = wintypes.BOOL
        self.user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel32.OpenProcess.restype = wintypes.HANDLE
        self.kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        self.kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
        self.kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel32.CloseHandle.restype = wintypes.BOOL
        self.gdi32.CreateCompatibleDC.restype = wintypes.HDC
        self.gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
        self.gdi32.CreateDIBSection.restype = wintypes.HANDLE
        self.gdi32.CreateDIBSection.argtypes = [
            wintypes.HDC,
            ctypes.POINTER(BITMAPINFO),
            wintypes.UINT,
            ctypes.POINTER(ctypes.c_void_p),
            wintypes.HANDLE,
            wintypes.DWORD,
        ]
        self.gdi32.SelectObject.restype = wintypes.HANDLE
        self.gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HANDLE]
        self.gdi32.SetStretchBltMode.argtypes = [wintypes.HDC, ctypes.c_int]
        self.gdi32.StretchBlt.argtypes = [
            wintypes.HDC,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.HDC,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.DWORD,
        ]
        self.gdi32.DeleteObject.argtypes = [wintypes.HANDLE]
        self.gdi32.DeleteDC.argtypes = [wintypes.HDC]
        self._held = set()
        self._lock = threading.RLock()
        self._guard = None
        self.input_tag = AI_INPUT_TAG
        self._last_ai_mouse_point = None
        self._ai_mouse_button_depth = 0
        self._last_ai_key_event = {}
        self._last_ai_mouse_event = 0.0

    def bind_input_guard(self, guard):
        self._guard = guard

    def last_ai_mouse_point(self):
        with self._lock:
            return self._last_ai_mouse_point

    def ai_mouse_button_active(self):
        with self._lock:
            return self._ai_mouse_button_depth > 0

    def ai_key_recent(self, vk, grace=0.13):
        with self._lock:
            return time.monotonic() - float(self._last_ai_key_event.get(int(vk), -9999.0)) <= max(0.0, float(grace))

    def ai_mouse_recent(self, point=None, grace=0.13, tolerance=3):
        with self._lock:
            if time.monotonic() - self._last_ai_mouse_event > max(0.0, float(grace)):
                return False
            if point is None or self._last_ai_mouse_point is None:
                return True
            return abs(int(point[0]) - int(self._last_ai_mouse_point[0])) <= int(tolerance) and abs(int(point[1]) - int(self._last_ai_mouse_point[1])) <= int(tolerance)

    def _input_allowed(self):
        try:
            return bool(self._guard is None or self._guard())
        except Exception:
            return False

    def ai_key_held(self, vk):
        with self._lock:
            return int(vk) in self._held

    def _process_path(self, pid):
        if not pid:
            return ""
        handle = self.kernel32.OpenProcess(self.PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
        if not handle:
            return ""
        try:
            size = wintypes.DWORD(32768)
            buffer = ctypes.create_unicode_buffer(size.value)
            if self.kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)):
                return os.path.abspath(buffer.value)
        finally:
            self.kernel32.CloseHandle(handle)
        return ""

    def firefox_windows(self):
        found = []
        foreground = int(self.user32.GetForegroundWindow() or 0)
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        self.user32.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]

        @callback_type
        def visit(hwnd, _):
            if not self.user32.IsWindowVisible(hwnd):
                return True
            class_name = ctypes.create_unicode_buffer(128)
            self.user32.GetClassNameW(hwnd, class_name, 128)
            if class_name.value != "MozillaWindowClass":
                return True
            title_len = self.user32.GetWindowTextLengthW(hwnd)
            title = ctypes.create_unicode_buffer(max(2, title_len + 1))
            self.user32.GetWindowTextW(hwnd, title, len(title))
            rect = RECT()
            if self.user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                width = max(0, rect.right - rect.left)
                height = max(0, rect.bottom - rect.top)
                pid = self.window_pid(hwnd)
                found.append((int(hwnd), title.value, width, height, pid, self._process_path(pid), int(hwnd) == foreground))
            return True

        self.user32.EnumWindows(visit, 0)
        return found

    @staticmethod
    def _game_title_ok(title):
        text = title or ""
        return "造梦西游" in text or "黎尤浩劫" in text or ("造梦" in text and "4399" in text.lower())

    @staticmethod
    def _strong_game_title_ok(title):
        text = title or ""
        return "造梦西游" in text or "黎尤浩劫" in text or ("造梦" in text and "西游" in text)

    @staticmethod
    def _portable_process_ok(process_path, firefox_path):
        if not process_path:
            return False
        process_path = os.path.normcase(os.path.abspath(process_path))
        firefox_path = os.path.normcase(os.path.abspath(firefox_path or "")) if firefox_path else ""
        if firefox_path and process_path == firefox_path:
            return True
        if firefox_path:
            root = os.path.normcase(os.path.dirname(firefox_path)).rstrip("\\/") + os.sep
            if process_path.startswith(root):
                return True
        return False

    def _window_score(self, row, firefox_path):
        hwnd, title, width, height, pid, process_path, foreground = row
        if width < 640 or height < 360:
            return None
        aspect = width / max(height, 1)
        path_ok = self._portable_process_ok(process_path, firefox_path)
        strong_title = self._strong_game_title_ok(title)
        title_ok = self._game_title_ok(title)
        score = 0.0
        if path_ok:
            score += 7.5
        if strong_title:
            score += 5.5
        elif title_ok:
            score += 3.5
        if foreground:
            score += 2.6
        if 1.25 <= aspect <= 2.45:
            score += 1.7
        elif 1.05 <= aspect <= 2.90:
            score += 0.6
        score += min(2.2, (width * height) / 1200000.0)
        if score < 6.0:
            return None
        return score

    def choose_existing_firefox(self, firefox_path="", exclude_hwnds=None):
        excluded = {int(x) for x in (exclude_hwnds or ())}
        candidates = []
        for row in self.firefox_windows():
            if int(row[0]) in excluded:
                continue
            score = self._window_score(row, firefox_path)
            if score is not None:
                candidates.append((score, row[2] * row[3], row[0]))
        if not candidates:
            return 0
        candidates.sort(reverse=True)
        return candidates[0][2]

    def choose_firefox(self, previous, firefox_path="", exclude_hwnds=None, require_new=False):
        excluded = {int(x) for x in (exclude_hwnds or ())}
        candidates = []
        for row in self.firefox_windows():
            if int(row[0]) in excluded:
                continue
            score = self._window_score(row, firefox_path)
            if score is None:
                continue
            hwnd, title, width, height = row[:4]
            old = previous.get(hwnd)
            is_new = old is None
            if require_new and not is_new:
                continue
            title_changed = old is not None and old != title
            candidates.append(((3 if is_new else 2 if title_changed else 1), score, width * height, hwnd))
        if not candidates:
            return 0
        candidates.sort(reverse=True)
        return candidates[0][3]

    def window_pid(self, hwnd):
        pid = wintypes.DWORD(0)
        try:
            self.user32.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
            return int(pid.value)
        except Exception:
            return 0

    def window_title(self, hwnd):
        if not self.valid_window(hwnd):
            return ""
        title_len = self.user32.GetWindowTextLengthW(hwnd)
        title = ctypes.create_unicode_buffer(max(2, title_len + 1))
        self.user32.GetWindowTextW(hwnd, title, len(title))
        return title.value

    def valid_window(self, hwnd):
        return bool(hwnd and self.user32.IsWindow(hwnd) and self.user32.IsWindowVisible(hwnd))

    def foreground(self, hwnd):
        if not self.valid_window(hwnd):
            return False
        self.user32.ShowWindow(hwnd, self.SW_MAXIMIZE)
        self.user32.BringWindowToTop(hwnd)
        self.user32.SetForegroundWindow(hwnd)
        return int(self.user32.GetForegroundWindow()) == int(hwnd)

    def is_foreground(self, hwnd):
        return int(self.user32.GetForegroundWindow()) == int(hwnd)

    def close_owned_game_window(self, hwnd, expected_pid):
        if not self.valid_window(hwnd):
            return False
        if expected_pid and self.window_pid(hwnd) != int(expected_pid):
            return False
        self.user32.PostMessageW(hwnd, self.WM_CLOSE, 0, 0)
        return True

    def monitor_info(self, hwnd):
        monitor = self.user32.MonitorFromWindow(wintypes.HWND(hwnd), 2)
        if not monitor:
            return None
        info = MONITORINFOEXW()
        info.cbSize = ctypes.sizeof(info)
        if not self.user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            return None
        rect = info.rcMonitor
        return {"left": int(rect.left), "top": int(rect.top), "right": int(rect.right), "bottom": int(rect.bottom), "width": int(rect.right - rect.left), "height": int(rect.bottom - rect.top), "primary": bool(info.dwFlags & 1), "device": str(info.szDevice)}

    def client_rect(self, hwnd):
        rect = RECT()
        if not self.user32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        point = POINT(0, 0)
        if not self.user32.ClientToScreen(hwnd, ctypes.byref(point)):
            return None
        width = rect.right - rect.left
        height = rect.bottom - rect.top
        if width < 640 or height < 360:
            return None
        return point.x, point.y, width, height

    def _send_key(self, vk, key_up=False):
        item = INPUT(type=self.INPUT_KEYBOARD)
        item.ki = KEYBDINPUT(int(vk), 0, self.KEYEVENTF_KEYUP if key_up else 0, 0, self.input_tag)
        ok = self.user32.SendInput(1, ctypes.byref(item), ctypes.sizeof(INPUT)) == 1
        if ok:
            self._last_ai_key_event[int(vk)] = time.monotonic()
        return ok

    def _send_mouse(self, flags, dx=0, dy=0, data=0):
        item = INPUT(type=self.INPUT_MOUSE)
        item.mi = MOUSEINPUT(int(dx), int(dy), int(data), int(flags), 0, self.input_tag)
        ok = self.user32.SendInput(1, ctypes.byref(item), ctypes.sizeof(INPUT)) == 1
        if ok:
            self._last_ai_mouse_event = time.monotonic()
        return ok

    def _move_cursor(self, x, y):
        left = self.user32.GetSystemMetrics(76)
        top = self.user32.GetSystemMetrics(77)
        width = max(1, self.user32.GetSystemMetrics(78))
        height = max(1, self.user32.GetSystemMetrics(79))
        x = max(left, min(left + width - 1, int(x)))
        y = max(top, min(top + height - 1, int(y)))
        nx = int(round((x - left) * 65535.0 / max(1, width - 1)))
        ny = int(round((y - top) * 65535.0 / max(1, height - 1)))
        self._last_ai_mouse_point = (x, y)
        return self._send_mouse(self.MOUSEEVENTF_MOVE | self.MOUSEEVENTF_ABSOLUTE | self.MOUSEEVENTF_VIRTUALDESK, nx, ny)

    def key_down(self, key):
        if not self._input_allowed():
            return False
        vk = self._vk(key)
        with self._lock:
            if not self._input_allowed():
                return False
            if vk in self._held:
                return True
            self._held.add(vk)
            if not self._send_key(vk, False):
                self._held.discard(vk)
                return False
            return True

    def key_up(self, key):
        vk = self._vk(key)
        with self._lock:
            if vk in self._held:
                self._send_key(vk, True)
                self._held.discard(vk)

    def tap(self, key, duration=0.03):
        if not self._input_allowed() or not self.key_down(key):
            return False
        deadline = time.monotonic() + max(0.0, duration)
        try:
            while time.monotonic() < deadline:
                if not self._input_allowed():
                    return False
                time.sleep(min(0.008, max(0.0, deadline - time.monotonic())))
            return self._input_allowed()
        finally:
            self.key_up(key)

    def release_all(self):
        with self._lock:
            keys = list(self._held)
            for vk in keys:
                self._send_key(vk, True)
            self._held.clear()

    def click(self, x, y):
        if not self._input_allowed():
            return False
        with self._lock:
            if not self._input_allowed() or not self._move_cursor(x, y):
                return False
            if not self._input_allowed():
                return False
            self._ai_mouse_button_depth += 1
            down = self._send_mouse(self.MOUSEEVENTF_LEFTDOWN)
            try:
                if not down:
                    return False
                deadline = time.monotonic() + 0.035
                while time.monotonic() < deadline:
                    if not self._input_allowed():
                        return False
                    time.sleep(0.006)
            finally:
                self._send_mouse(self.MOUSEEVENTF_LEFTUP)
                self._ai_mouse_button_depth = max(0, self._ai_mouse_button_depth - 1)
            return self._input_allowed()

    def _vk(self, key):
        if isinstance(key, int):
            return key
        if key == "SPACE":
            return 0x20
        return ord(key.upper())


class GameViewportDetector:
    def __init__(self, width, height):
        self.width = max(1, int(width))
        self.height = max(1, int(height))
        self.previous = None
        self.norm = (0.0, 0.0, 1.0, 1.0)
        self.confidence = 0.0
        self.last_probe = 0.0
        self.last_candidate = None

    def locked(self):
        return self.confidence >= 0.34

    def should_probe(self, now):
        return not self.locked() or now - self.last_probe >= (0.65 if self.confidence < 0.72 else 1.25)

    @staticmethod
    def _bounds(scores, minimum_span, pad, max_index):
        if not scores:
            return None
        ordered = sorted(scores)
        q = ordered[max(0, min(len(ordered) - 1, int(len(ordered) * 0.70)))]
        peak = max(scores)
        threshold = min(peak * 0.62, max(q * 0.82, peak * 0.12, 1.0))
        active = [i for i, value in enumerate(scores) if value >= threshold]
        if not active:
            return None
        lo, hi = min(active), max(active)
        if hi - lo + 1 < minimum_span:
            center = (lo + hi) // 2
            half = minimum_span // 2
            lo, hi = center - half, center + half
        lo = max(0, lo - pad)
        hi = min(max_index - 1, hi + pad)
        return lo, hi

    def observe(self, frame, client_rect, now):
        self.last_probe = now
        if not frame or self.previous is None or len(frame) != len(self.previous):
            self.previous = frame
            return self.rect(client_rect)
        w, h = self.width, self.height
        row = [0.0] * h
        col = [0.0] * w
        prev = self.previous
        stride = 2 if w * h >= 28000 else 1
        for y in range(0, h, stride):
            ro = 0.0
            base = y * w * 4
            for x in range(0, w, stride):
                i = base + x * 4
                db = abs(frame[i] - prev[i])
                dg = abs(frame[i + 1] - prev[i + 1])
                dr = abs(frame[i + 2] - prev[i + 2])
                motion = (dr * 0.30 + dg * 0.55 + db * 0.15) / 255.0
                if motion < 0.018:
                    continue
                weight = min(1.0, motion * 4.0)
                ro += weight
                col[x] += weight
            row[y] = ro
        if stride > 1:
            for y in range(1, h, 2):
                row[y] = (row[y - 1] + (row[y + 1] if y + 1 < h else row[y - 1])) * 0.5
            for x in range(1, w, 2):
                col[x] = (col[x - 1] + (col[x + 1] if x + 1 < w else col[x - 1])) * 0.5
        yb = self._bounds(row, max(12, int(h * 0.42)), max(2, int(h * 0.025)), h)
        xb = self._bounds(col, max(20, int(w * 0.50)), max(2, int(w * 0.025)), w)
        self.previous = frame
        if not yb or not xb:
            self.confidence *= 0.96
            return self.rect(client_rect)
        x0, x1 = xb
        y0, y1 = yb
        span_w = (x1 - x0 + 1) / max(1.0, float(w))
        span_h = (y1 - y0 + 1) / max(1.0, float(h))
        if span_w < 0.50 or span_h < 0.42:
            self.confidence *= 0.94
            return self.rect(client_rect)
        nx0 = max(0.0, min(0.98, x0 / w))
        ny0 = max(0.0, min(0.98, y0 / h))
        nx1 = max(nx0 + 0.02, min(1.0, (x1 + 1) / w))
        ny1 = max(ny0 + 0.02, min(1.0, (y1 + 1) / h))
        aspect = (nx1 - nx0) * max(1.0, float(client_rect[2])) / max(1.0, (ny1 - ny0) * float(client_rect[3]))
        if aspect < 1.10 or aspect > 2.55:
            self.confidence *= 0.95
            return self.rect(client_rect)
        candidate = (nx0, ny0, nx1, ny1)
        old = self.norm
        delta = sum(abs(a - b) for a, b in zip(candidate, old))
        alpha = 0.34 if self.confidence < 0.40 else 0.18
        self.norm = tuple(old[i] * (1.0 - alpha) + candidate[i] * alpha for i in range(4))
        stable = self.last_candidate is not None and sum(abs(a - b) for a, b in zip(candidate, self.last_candidate)) < 0.16
        self.last_candidate = candidate
        self.confidence = min(1.0, self.confidence + (0.16 if stable else 0.09))
        if delta > 0.80:
            self.confidence *= 0.88
        return self.rect(client_rect)

    def rect(self, client_rect):
        if not client_rect:
            return None
        x, y, width, height = client_rect
        if not self.locked():
            return client_rect
        nx0, ny0, nx1, ny1 = self.norm
        left = int(round(x + width * nx0))
        top = int(round(y + height * ny0))
        right = int(round(x + width * nx1))
        bottom = int(round(y + height * ny1))
        out_w = max(1, right - left)
        out_h = max(1, bottom - top)
        if out_w < 640 or out_h < 320:
            return client_rect
        return left, top, out_w, out_h


class FrameGrabber:
    def __init__(self, winio, width, height, base_dir=None, profile=None, stop_event=None, hwnd=0):
        self.io = winio
        self.width = width
        self.height = height
        self.backend_name = "GDI"
        self.base_dir = base_dir
        self.profile = profile
        self.stop_event = stop_event
        self.hwnd = int(hwnd or 0)
        self.dxcam = None
        self.dxcam_mod = None
        self.np = None
        self.dxcam_errors = 0
        self.dxcam_retry_at = 0.0
        self.dxcam_backoff = 2.0
        self.dxcam_origin = (0, 0)
        self.dxcam_output_idx = 0
        if base_dir and profile is not None and profile.prefer_dxgi:
            self.dxcam_mod, self.np = _ensure_dxcam(base_dir, stop_event)
            self._try_dxgi()
        self.screen_dc = self.io.user32.GetDC(0)
        self.memory_dc = self.io.gdi32.CreateCompatibleDC(self.screen_dc)
        self.info = self._make_info(width, height)
        self.bits = ctypes.c_void_p()
        self.bitmap = self.io.gdi32.CreateDIBSection(
            self.screen_dc,
            ctypes.byref(self.info),
            0,
            ctypes.byref(self.bits),
            None,
            0,
        )
        if not self.bitmap or not self.bits.value:
            raise RuntimeError("无法读取游戏画面")
        self.old_bitmap = self.io.gdi32.SelectObject(self.memory_dc, self.bitmap)
        self.io.gdi32.SetStretchBltMode(self.memory_dc, 4)
        self.closed = False

    def _try_dxgi(self):
        if self.dxcam is not None or self.dxcam_mod is None or self.np is None:
            return self.dxcam is not None
        if self.stop_event is not None and self.stop_event.is_set():
            return False
        now = time.monotonic()
        if now < self.dxcam_retry_at:
            return False
        try:
            monitor = self.io.monitor_info(self.hwnd) if self.hwnd else None
            output_idx = 0
            origin = (0, 0)
            if monitor:
                origin = (int(monitor["left"]), int(monitor["top"]))
                infos = []
                try:
                    infos = list(self.dxcam_mod.output_info() or ())
                except Exception:
                    infos = []
                matches = []
                for idx, text in enumerate(infos):
                    raw = str(text)
                    match = re.search(r"Res:\((\d+)\s*,\s*(\d+)\)", raw)
                    if match and int(match.group(1)) == int(monitor["width"]) and int(match.group(2)) == int(monitor["height"]):
                        primary_match = ("Primary:True" in raw.replace(" ", "")) == bool(monitor["primary"])
                        matches.append((1 if primary_match else 0, idx))
                if matches:
                    matches.sort(reverse=True)
                    output_idx = int(matches[0][1])
            self.dxcam = self.dxcam_mod.create(output_idx=output_idx, output_color="BGRA")
            self.dxcam_origin = origin
            self.dxcam_output_idx = output_idx
            self.dxcam_errors = 0
            self.dxcam_backoff = 2.0
            self.backend_name = f"DXGI/GPU#{output_idx}"
            return True
        except Exception:
            self.dxcam = None
            self.dxcam_retry_at = now + self.dxcam_backoff
            self.dxcam_backoff = min(30.0, self.dxcam_backoff * 1.8)
            self.backend_name = "GDI/DXGI冷却"
            return False

    @staticmethod
    def _make_info(width, height):
        info = BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        info.bmiHeader.biWidth = width
        info.bmiHeader.biHeight = -height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        return info

    def capture(self, rect):
        x, y, width, height = rect
        if self.dxcam is None and self.dxcam_mod is not None and self.np is not None and time.monotonic() >= self.dxcam_retry_at:
            self._try_dxgi()
        if self.dxcam is not None and self.np is not None:
            try:
                ox, oy = self.dxcam_origin
                image = self.dxcam.grab(region=(int(x - ox), int(y - oy), int(x - ox + width), int(y - oy + height)))
                if image is not None and getattr(image, "ndim", 0) == 3 and image.shape[0] > 1 and image.shape[1] > 1:
                    if image.shape[2] == 3:
                        alpha = self.np.full((image.shape[0], image.shape[1], 1), 255, dtype=image.dtype)
                        image = self.np.concatenate((image, alpha), axis=2)
                    ys = self.np.linspace(0, image.shape[0] - 1, self.height).astype(self.np.intp)
                    xs = self.np.linspace(0, image.shape[1] - 1, self.width).astype(self.np.intp)
                    small = image[ys[:, None], xs[None, :], :4]
                    self.dxcam_errors = 0
                    return small.tobytes(order="C")
                if image is not None:
                    self.dxcam_errors += 1
            except Exception:
                self.dxcam_errors += 1
            if self.dxcam_errors >= 4:
                try:
                    self.dxcam.stop()
                except Exception:
                    pass
                self.dxcam = None
                self.dxcam_retry_at = time.monotonic() + self.dxcam_backoff
                self.dxcam_backoff = min(30.0, self.dxcam_backoff * 1.8)
                self.backend_name = "GDI/DXGI冷却"
        ok = self.io.gdi32.StretchBlt(
            self.memory_dc,
            0,
            0,
            self.width,
            self.height,
            self.screen_dc,
            x,
            y,
            width,
            height,
            0x00CC0020,
        )
        if not ok:
            return None
        return ctypes.string_at(self.bits.value, self.width * self.height * 4)

    def capture_bmp(self, rect, path, max_width=1280):
        x, y, width, height = rect
        scale = min(1.0, max_width / max(width, 1))
        out_w = max(640, int(width * scale))
        out_h = max(360, int(height * scale))
        mem = self.io.gdi32.CreateCompatibleDC(self.screen_dc)
        info = self._make_info(out_w, out_h)
        bits = ctypes.c_void_p()
        bitmap = self.io.gdi32.CreateDIBSection(
            self.screen_dc,
            ctypes.byref(info),
            0,
            ctypes.byref(bits),
            None,
            0,
        )
        if not mem or not bitmap or not bits.value:
            if bitmap:
                self.io.gdi32.DeleteObject(bitmap)
            if mem:
                self.io.gdi32.DeleteDC(mem)
            return None
        old = self.io.gdi32.SelectObject(mem, bitmap)
        try:
            self.io.gdi32.SetStretchBltMode(mem, 4)
            ok = self.io.gdi32.StretchBlt(
                mem,
                0,
                0,
                out_w,
                out_h,
                self.screen_dc,
                x,
                y,
                width,
                height,
                0x00CC0020,
            )
            if not ok:
                return None
            raw = ctypes.string_at(bits.value, out_w * out_h * 4)
            file_size = 14 + 40 + len(raw)
            file_header = struct.pack("<2sIHHI", b"BM", file_size, 0, 0, 54)
            dib_header = struct.pack(
                "<IiiHHIIiiII",
                40,
                out_w,
                -out_h,
                1,
                32,
                0,
                len(raw),
                0,
                0,
                0,
                0,
            )
            try:
                with open(path, "wb") as handle:
                    handle.write(file_header)
                    handle.write(dib_header)
                    handle.write(raw)
            except OSError:
                return None
            return out_w, out_h
        finally:
            if old:
                self.io.gdi32.SelectObject(mem, old)
            self.io.gdi32.DeleteObject(bitmap)
            self.io.gdi32.DeleteDC(mem)

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.dxcam is not None:
            try:
                self.dxcam.stop()
            except Exception:
                pass
        self.dxcam = None
        self.np = None
        if self.old_bitmap:
            self.io.gdi32.SelectObject(self.memory_dc, self.old_bitmap)
        if self.bitmap:
            self.io.gdi32.DeleteObject(self.bitmap)
        if self.memory_dc:
            self.io.gdi32.DeleteDC(self.memory_dc)
        if self.screen_dc:
            self.io.user32.ReleaseDC(0, self.screen_dc)


class WindowsOCR:
    CHECK_SCRIPT = r'''
$ErrorActionPreference = 'Stop'
$OutputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$engine = $null
try {
    $zh = New-Object Windows.Globalization.Language -ArgumentList 'zh-CN'
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($zh)
} catch { $engine = $null }
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
}
if ($null -eq $engine) { throw 'Windows OCR unavailable' }
Write-Output $engine.RecognizerLanguage.LanguageTag
'''

    SCRIPT = r'''
$ErrorActionPreference = 'Stop'
$OutputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType=WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 })[0]
function Await($op, $type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    $task.Wait()
    return $task.Result
}
$engine = $null
try {
    $zh = New-Object Windows.Globalization.Language -ArgumentList 'zh-CN'
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($zh)
} catch { $engine = $null }
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
}
if ($null -eq $engine) { throw 'Windows OCR unavailable' }
$path = $env:AI_OCR_PATH
if ([string]::IsNullOrWhiteSpace($path)) { throw 'OCR image path missing' }
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
try {
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $lines = @()
    foreach ($line in $result.Lines) {
        $words = @()
        foreach ($word in $line.Words) {
            $r = $word.BoundingRect
            $words += [pscustomobject]@{ t=$word.Text; x=$r.X; y=$r.Y; w=$r.Width; h=$r.Height }
        }
        $lines += [pscustomobject]@{ t=$line.Text; words=$words }
    }
    [pscustomobject]@{ text=$result.Text; lines=$lines } | ConvertTo-Json -Depth 6 -Compress
} finally {
    $stream.Dispose()
}
'''

    SERVER_SCRIPT = r'''
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::InputEncoding = $utf8
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType=WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 })[0]
function Await($op, $type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    $task.Wait()
    return $task.Result
}
$engine = $null
try {
    $zh = New-Object Windows.Globalization.Language -ArgumentList 'zh-CN'
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($zh)
} catch { $engine = $null }
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
}
if ($null -eq $engine) { throw 'Windows OCR unavailable' }
[Console]::Out.WriteLine(([pscustomobject]@{ready=$true; lang=$engine.RecognizerLanguage.LanguageTag} | ConvertTo-Json -Compress))
[Console]::Out.Flush()
while (($line = [Console]::In.ReadLine()) -ne $null) {
    try {
        $req = $line | ConvertFrom-Json
        $path = [string]$req.path
        if ([string]::IsNullOrWhiteSpace($path)) { throw 'OCR image path missing' }
        $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
        $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        try {
            $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
            $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
            $lines = @()
            foreach ($ocrLine in $result.Lines) {
                $words = @()
                foreach ($word in $ocrLine.Words) {
                    $r = $word.BoundingRect
                    $words += [pscustomobject]@{t=$word.Text; x=$r.X; y=$r.Y; w=$r.Width; h=$r.Height}
                }
                $lines += [pscustomobject]@{t=$ocrLine.Text; words=$words}
            }
            $response = [pscustomobject]@{ok=$true; text=$result.Text; lines=$lines}
        } finally { $stream.Dispose() }
    } catch {
        $response = [pscustomobject]@{ok=$false; error=$_.Exception.Message}
    }
    [Console]::Out.WriteLine(($response | ConvertTo-Json -Depth 6 -Compress))
    [Console]::Out.Flush()
}
'''

    def __init__(self, base_dir, stop_event, max_width=1280):
        self.base_dir = base_dir
        self.max_width = max(800, int(max_width))
        self.stop_event = stop_event
        self.cancel_event = threading.Event()
        self.disabled = False
        self.failure_count = 0
        self.cooldown_until = 0.0
        self.cooldown_seconds = 10.0
        self.recovery_count = 0
        self.counter = 0
        self.last_error = ""
        self.server = None
        self.server_lines = queue.Queue()
        self.server_stderr = []
        self.server_reader = None
        self.server_error_reader = None
        self.language = ""

    def cancel(self):
        self.cancel_event.set()
        self._stop_server()

    def _cancelled(self):
        return self.stop_event.is_set() or self.cancel_event.is_set()

    def _powershell(self, script, env_extra=None, timeout=4.5):
        if self._cancelled():
            return None
        env = os.environ.copy()
        if env_extra:
            env.update(env_extra)
        flags = 0x08000000 if os.name == "nt" else 0
        proc = subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", script],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=flags,
            env=env,
        )
        deadline = time.monotonic() + timeout
        while proc.poll() is None:
            if self._cancelled():
                proc.terminate()
                try:
                    proc.wait(0.4)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    try:
                        proc.wait(0.4)
                    except subprocess.TimeoutExpired:
                        pass
                return None
            if time.monotonic() >= deadline:
                proc.kill()
                proc.communicate()
                raise TimeoutError("Windows OCR 超时")
            self.stop_event.wait(0.05)
        stdout, stderr = proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(stderr.decode("utf-8", errors="replace")[-500:])
        return stdout.decode("utf-8", errors="replace").strip()

    @staticmethod
    def _reader_loop(stream, output_queue, error_buffer):
        try:
            while True:
                line = stream.readline()
                if not line:
                    break
                output_queue.put(line)
        except Exception as exc:
            error_buffer.append(repr(exc))

    @staticmethod
    def _stderr_loop(stream, error_buffer):
        try:
            while True:
                line = stream.readline()
                if not line:
                    break
                text = line.decode("utf-8", errors="replace").strip()
                if text:
                    error_buffer.append(text)
                    del error_buffer[:-8]
        except Exception:
            pass

    def _read_server_line(self, timeout):
        deadline = time.monotonic() + timeout
        while not self._cancelled() and time.monotonic() < deadline:
            if self.server is not None and self.server.poll() is not None and self.server_lines.empty():
                detail = " | ".join(self.server_stderr[-3:]) or f"exit={self.server.returncode}"
                raise RuntimeError(f"OCR 子进程退出：{detail}")
            try:
                raw = self.server_lines.get(timeout=0.05)
                return raw.decode("utf-8", errors="replace").strip()
            except queue.Empty:
                pass
        if self._cancelled():
            return None
        raise TimeoutError("Windows OCR 子进程响应超时")

    def _start_server(self):
        if self.server is not None and self.server.poll() is None:
            return
        self._stop_server()
        flags = 0x08000000 if os.name == "nt" else 0
        self.server_lines = queue.Queue()
        self.server_stderr = []
        self.server = subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", self.SERVER_SCRIPT],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=flags,
        )
        output_queue = self.server_lines
        error_buffer = self.server_stderr
        self.server_reader = threading.Thread(target=self._reader_loop, args=(self.server.stdout, output_queue, error_buffer), daemon=True)
        self.server_error_reader = threading.Thread(target=self._stderr_loop, args=(self.server.stderr, error_buffer), daemon=True)
        self.server_reader.start()
        self.server_error_reader.start()
        try:
            line = self._read_server_line(5.5)
            data = json.loads(line or "{}")
            language = str(data.get("lang") or "").strip()
            if not data.get("ready") or not language:
                raise RuntimeError("常驻 Windows OCR 初始化失败")
            self.language = language
        except Exception:
            self._stop_server()
            raise

    def _stop_server(self):
        proc = self.server
        self.server = None
        if proc is None:
            return
        try:
            if proc.stdin:
                proc.stdin.close()
        except Exception:
            pass
        if proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(0.45)
            except Exception:
                try:
                    proc.kill()
                    proc.wait(0.45)
                except Exception:
                    pass

    def _server_recognize(self, path, timeout=4.5):
        self._start_server()
        if self._cancelled():
            return None
        payload = (json.dumps({"path": os.path.abspath(path)}, ensure_ascii=False) + "\n").encode("utf-8")
        try:
            self.server.stdin.write(payload)
            self.server.stdin.flush()
        except Exception as exc:
            self._stop_server()
            raise RuntimeError(f"OCR 子进程写入失败：{exc}")
        line = self._read_server_line(timeout)
        if not line:
            return None
        data = json.loads(line)
        if not data.get("ok"):
            raise RuntimeError(str(data.get("error") or "Windows OCR 识别失败"))
        return data

    def self_test(self):
        if self._cancelled():
            return False
        try:
            self._stop_server()
            self._start_server()
            self.last_error = ""
            self.failure_count = 0
            self.cooldown_until = 0.0
            return True
        except Exception as exc:
            self.last_error = repr(exc)
            try:
                output = self._powershell(self.CHECK_SCRIPT, timeout=4.0)
                if not output:
                    raise RuntimeError("未检测到 Windows OCR 引擎")
                self.language = output.splitlines()[-1].strip()
                self.failure_count = 0
                self.cooldown_until = 0.0
                return bool(self.language)
            except Exception as fallback_exc:
                self.last_error = repr(fallback_exc)
                return False

    def _temp_path(self):
        self.counter += 1
        prefix = f".ai_ocr_{os.getpid()}_{self.counter}_"
        try:
            fd, path = tempfile.mkstemp(prefix=prefix, suffix=".bmp", dir=self.base_dir)
        except OSError as exc:
            self.disabled = True
            self.last_error = repr(exc)
            raise RuntimeError(f"所选数据目录不可写，OCR 已禁用：{exc}")
        os.close(fd)
        return path

    def recognize(self, grabber, rect):
        if self.disabled or self._cancelled():
            return None
        now = time.monotonic()
        if now < self.cooldown_until:
            return None
        if self.cooldown_until > 0.0:
            self._stop_server()
            if not self.self_test():
                self.recovery_count += 1
                self.cooldown_until = now + min(120.0, self.cooldown_seconds * (1.7 ** min(6, self.recovery_count)))
                return None
            self.recovery_count = 0
            self.cooldown_seconds = 10.0
        path = self._temp_path()
        try:
            size = grabber.capture_bmp(rect, path, max_width=self.max_width)
            if not size or self._cancelled():
                return None
            try:
                data = self._server_recognize(path, timeout=4.5)
            except Exception as server_exc:
                self._stop_server()
                output = self._powershell(self.SCRIPT, {"AI_OCR_PATH": os.path.abspath(path)}, timeout=4.5)
                if not output:
                    raise server_exc
                data = json.loads(output)
            words = []
            for line_index, line in enumerate(data.get("lines") or []):
                for item in line.get("words") or []:
                    text = str(item.get("t") or "").strip()
                    if text:
                        words.append(
                            OCRWord(
                                text,
                                float(item.get("x") or 0),
                                float(item.get("y") or 0),
                                float(item.get("w") or 0),
                                float(item.get("h") or 0),
                                line_index,
                            )
                        )
            self.failure_count = 0
            self.recovery_count = 0
            self.cooldown_until = 0.0
            self.cooldown_seconds = max(10.0, self.cooldown_seconds * 0.75)
            self.last_error = ""
            return OCRSnapshot(str(data.get("text") or ""), tuple(words), size[0], size[1], time.monotonic())
        except Exception as exc:
            if not self._cancelled():
                self.failure_count += 1
                self.last_error = repr(exc)
                if self.failure_count >= 3:
                    self._stop_server()
                    self.failure_count = 0
                    self.recovery_count += 1
                    self.cooldown_until = time.monotonic() + min(120.0, self.cooldown_seconds * (1.7 ** min(6, self.recovery_count - 1)))
            return None
        finally:
            try:
                os.remove(path)
            except OSError:
                pass


class AsyncOCR:
    def __init__(self, winio, stop_event, base_dir, max_width=1280):
        self.io = winio
        self.stop_event = stop_event
        self.worker = WindowsOCR(base_dir, stop_event, max_width=max_width)
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.thread = None
        self.pending_rect = None
        self.busy = False
        self.latest = None
        self.generation = 0
        self.seen_generation = 0

    @property
    def disabled(self):
        return self.worker.disabled

    @property
    def cooling_down(self):
        return time.monotonic() < self.worker.cooldown_until

    @property
    def retry_at(self):
        return self.worker.cooldown_until

    def self_test(self):
        return self.worker.self_test()

    def start(self):
        if self.thread is None:
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()

    def request(self, rect):
        if self.disabled or self.stop_event.is_set() or self.cooling_down:
            return False
        with self.lock:
            if self.busy or self.pending_rect is not None:
                return False
            self.pending_rect = tuple(rect)
        self.wake.set()
        return True

    def take_latest(self):
        with self.lock:
            if self.generation == self.seen_generation:
                return False, None
            self.seen_generation = self.generation
            return True, self.latest

    def _run(self):
        grabber = None
        try:
            grabber = FrameGrabber(self.io, 64, 36)
            while not self.stop_event.is_set() and not self.worker.cancel_event.is_set():
                self.wake.wait(0.15)
                self.wake.clear()
                with self.lock:
                    rect = self.pending_rect
                    self.pending_rect = None
                    if rect is not None:
                        self.busy = True
                if rect is None:
                    continue
                snapshot = self.worker.recognize(grabber, rect)
                with self.lock:
                    self.latest = snapshot
                    self.generation += 1
                    self.busy = False
        except Exception as exc:
            self.worker.last_error = repr(exc)
            self.worker.recovery_count += 1
            self.worker.cooldown_until = time.monotonic() + min(120.0, 10.0 * (1.7 ** min(6, self.worker.recovery_count - 1)))
        finally:
            if grabber:
                grabber.close()
            with self.lock:
                self.busy = False

    def close(self):
        self.worker.cancel()
        self.wake.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(1.0)


class Vision:
    DANGER_WORDS = ("购买", "充值", "支付", "花费", "商城", "退出", "删除", "兑换", "续费")
    GLOBAL_DANGER_WORDS = ("确认购买", "购买", "充值", "支付", "花费", "续费", "删除角色", "退出游戏")
    SAFE_FORWARD_WORDS = (
        "继续游戏", "继续", "下一步", "下一关", "领取", "收下", "完成", "提交", "接取",
        "前往", "传送", "跳过", "挑战", "进入", "开始", "免费", "装备", "穿戴", "使用",
        "确认", "确定", "关闭", "返回",
    )
    SAFE_ABORT_WORDS = ("取消", "关闭", "返回", "以后再说", "稍后", "我知道了")

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.hp_max_run = 0
        self.mp_max_run = 0
        self.boss_max_run = 0
        self.hp_ratio = None
        self.mp_ratio = None
        self.boss_ratio = None
        self.hp_missing = 0
        self.mp_missing = 0
        self.boss_missing = 0
        self.player_x = None
        self.enemy_x = None
        self.player_y = None
        self.enemy_y = None
        self.hud_regions = {}
        self.hud_votes = {"hp": 0, "mp": 0, "boss": 0}

    def reset_combat_calibration(self):
        self.hp_max_run = 0
        self.mp_max_run = 0
        self.boss_max_run = 0
        self.hp_ratio = None
        self.mp_ratio = None
        self.boss_ratio = None
        self.hp_missing = 0
        self.mp_missing = 0
        self.boss_missing = 0
        self.player_x = None
        self.enemy_x = None
        self.player_y = None
        self.enemy_y = None
        self.hud_regions = {}
        self.hud_votes = {"hp": 0, "mp": 0, "boss": 0}

    def metrics(self, frame, previous):
        if not frame:
            return 0.0, 0.0, 1.0, 0.0
        total = 0
        dark = 0
        vivid = 0
        motion = 0
        count = self.width * self.height
        for i in range(0, len(frame), 4):
            b = frame[i]
            g = frame[i + 1]
            r = frame[i + 2]
            value = (r * 3 + g * 6 + b) // 10
            total += value
            if value < 16:
                dark += 1
            if max(r, g, b) - min(r, g, b) > 55 and max(r, g, b) > 105:
                vivid += 1
            if previous:
                pb = previous[i]
                pg = previous[i + 1]
                pr = previous[i + 2]
                pvalue = (pr * 3 + pg * 6 + pb) // 10
                motion += abs(value - pvalue)
        return total / count, motion / count if previous else 0.0, dark / count, vivid / count

    def fingerprint(self, frame, cols=12, rows=7):
        if not frame:
            return ()
        result = []
        for gy in range(rows):
            y = min(self.height - 1, int((gy + 0.5) * self.height / rows))
            for gx in range(cols):
                x = min(self.width - 1, int((gx + 0.5) * self.width / cols))
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                result.append(((r * 3 + g * 6 + b) // 10) // 16)
        return tuple(result)

    @staticmethod
    def fingerprint_distance(a, b):
        if not a or not b or len(a) != len(b):
            return 99.0
        return sum(abs(x - y) for x, y in zip(a, b)) / len(a)

    def hud_score(self, frame):
        if not frame:
            return 0
        max_x = int(self.width * 0.48)
        max_y = int(self.height * 0.28)
        best = 0
        for y in range(3, max_y, 3):
            run = 0
            for x in range(2, max_x):
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                high = max(r, g, b)
                low = min(r, g, b)
                colored = high > 115 and high - low > 48 and (r > 120 or b > 120 or g > 120)
                if colored:
                    run += 1
                    best = max(best, run)
                else:
                    run = 0
        if best >= int(self.width * 0.16):
            return 3
        if best >= int(self.width * 0.10):
            return 2
        if best >= int(self.width * 0.06):
            return 1
        return 0

    @staticmethod
    def _red_pixel(r, g, b):
        return r >= 88 and r - g >= 28 and r - b >= 24 and r >= int(g * 1.20)

    @staticmethod
    def _blue_pixel(r, g, b):
        return b >= 82 and b - r >= 22 and b - g >= 10 and b >= int(r * 1.16)

    def _longest_color_run(self, frame, x1, y1, x2, y2, color):
        if not frame:
            return 0
        predicate = self._red_pixel if color == "red" else self._blue_pixel
        best = 0
        for y in range(max(0, y1), min(self.height, y2)):
            run = 0
            gap = 0
            for x in range(max(0, x1), min(self.width, x2)):
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                if predicate(r, g, b):
                    run += 1 + gap
                    gap = 0
                    if run > best:
                        best = run
                elif run and gap < 2:
                    gap += 1
                else:
                    run = 0
                    gap = 0
        return best

    def _scan_color_runs(self, frame, color):
        predicate = self._red_pixel if color == "red" else self._blue_pixel
        rows = []
        y2 = int(self.height * 0.48)
        minimum = max(5, int(self.width * 0.035))
        for y in range(2, max(3, y2), 2):
            start = None
            gap = 0
            for x in range(1, self.width - 1):
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                if predicate(r, g, b):
                    if start is None:
                        start = x
                    gap = 0
                elif start is not None and gap < 2:
                    gap += 1
                elif start is not None:
                    end = x - gap
                    if end - start >= minimum:
                        rows.append((start, y, end, y + 1, end - start))
                    start = None
                    gap = 0
            if start is not None:
                end = self.width - 1
                if end - start >= minimum:
                    rows.append((start, y, end, y + 1, end - start))
        rows.sort(key=lambda row: row[4], reverse=True)
        return rows[:32]

    def _update_hud_region(self, name, candidate):
        if candidate is None:
            self.hud_votes[name] = max(0, self.hud_votes.get(name, 0) - 1)
            return
        old = self.hud_regions.get(name)
        if old is None:
            self.hud_regions[name] = tuple(candidate[:4])
            self.hud_votes[name] = 1
            return
        ox1, oy1, ox2, oy2 = old
        x1, y1, x2, y2 = candidate[:4]
        center_old = ((ox1 + ox2) * 0.5 / self.width, (oy1 + oy2) * 0.5 / self.height)
        center_new = ((x1 + x2) * 0.5 / self.width, (y1 + y2) * 0.5 / self.height)
        length_old = max(1, ox2 - ox1)
        length_new = max(1, x2 - x1)
        close = abs(center_old[0] - center_new[0]) < 0.075 and abs(center_old[1] - center_new[1]) < 0.055 and abs(length_old - length_new) / max(length_old, length_new) < 0.38
        if close:
            alpha = 0.34
            self.hud_regions[name] = (
                int(ox1 * (1.0 - alpha) + x1 * alpha), int(oy1 * (1.0 - alpha) + y1 * alpha),
                int(ox2 * (1.0 - alpha) + x2 * alpha), int(oy2 * (1.0 - alpha) + y2 * alpha),
            )
            self.hud_votes[name] = min(12, self.hud_votes.get(name, 0) + 1)
        else:
            self.hud_votes[name] = max(0, self.hud_votes.get(name, 0) - 2)
            if self.hud_votes[name] == 0:
                self.hud_regions[name] = tuple(candidate[:4])
                self.hud_votes[name] = 1

    def _calibrate_hud(self, frame):
        if not frame:
            return
        red = self._scan_color_runs(frame, "red")
        blue = self._scan_color_runs(frame, "blue")
        hp_candidates = [row for row in red if row[0] < self.width * 0.48 and row[1] < self.height * 0.34 and row[4] < self.width * 0.42]
        mp_candidates = [row for row in blue if row[0] < self.width * 0.52 and row[1] < self.height * 0.38 and row[4] < self.width * 0.46]
        boss_candidates = [row for row in red if row[4] >= self.width * 0.18 and row[1] < self.height * 0.32]
        hp = max(hp_candidates, key=lambda row: row[4], default=None)
        mp = max(mp_candidates, key=lambda row: row[4], default=None)
        boss = max(boss_candidates, key=lambda row: row[4] + row[0] * 0.12, default=None)
        if boss is not None and hp is not None and abs(boss[0] - hp[0]) < self.width * 0.05 and abs(boss[1] - hp[1]) < self.height * 0.04:
            alternatives = [row for row in boss_candidates if row is not hp and row[4] > hp[4] * 1.35]
            boss = max(alternatives, key=lambda row: row[4], default=None)
        self._update_hud_region("hp", hp)
        self._update_hud_region("mp", mp)
        self._update_hud_region("boss", boss)

    def _calibrated_run(self, frame, name, color, fallback, minimum_votes=3):
        region = self.hud_regions.get(name)
        if region is not None and self.hud_votes.get(name, 0) >= minimum_votes:
            x1, y1, x2, y2 = region
            pad_x = max(3, int(self.width * 0.025))
            pad_y = max(2, int(self.height * 0.025))
            return self._longest_color_run(frame, x1 - pad_x, y1 - pad_y, x2 + pad_x, y2 + pad_y, color)
        return self._longest_color_run(frame, *fallback, color)

    def _bar_ratio(self, run, name, minimum=5):
        max_name = f"{name}_max_run"
        ratio_name = f"{name}_ratio"
        missing_name = f"{name}_missing"
        maximum = getattr(self, max_name)
        previous = getattr(self, ratio_name)
        missing = getattr(self, missing_name)
        if run >= minimum:
            maximum = max(maximum, run)
            raw = min(1.0, run / max(maximum, 1))
            value = raw if previous is None else previous * 0.55 + raw * 0.45
            setattr(self, max_name, maximum)
            setattr(self, ratio_name, value)
            setattr(self, missing_name, 0)
            return value
        missing += 1
        setattr(self, missing_name, missing)
        if previous is not None and missing <= 4:
            return previous
        if maximum >= minimum * 2:
            setattr(self, ratio_name, 0.0)
            return 0.0
        return None

    def _motion_regions(self, frame, previous, cols=24, rows=14):
        if not frame or not previous or len(frame) != len(previous):
            return []
        scores = [[0.0 for _ in range(cols)] for _ in range(rows)]
        warm = [[0.0 for _ in range(cols)] for _ in range(rows)]
        y1, y2 = int(self.height * 0.20), int(self.height * 0.92)
        x1, x2 = int(self.width * 0.02), int(self.width * 0.98)
        for gy in range(rows):
            ya = y1 + int(gy * (y2 - y1) / rows)
            yb = y1 + int((gy + 1) * (y2 - y1) / rows)
            for gx in range(cols):
                xa = x1 + int(gx * (x2 - x1) / cols)
                xb = x1 + int((gx + 1) * (x2 - x1) / cols)
                total = 0.0
                hot = 0.0
                for y in range(ya, max(ya + 1, yb), 2):
                    for x in range(xa, max(xa + 1, xb), 2):
                        i = (y * self.width + x) * 4
                        b, g, r = frame[i], frame[i + 1], frame[i + 2]
                        pb, pg, pr = previous[i], previous[i + 1], previous[i + 2]
                        diff = abs(r - pr) + abs(g - pg) + abs(b - pb)
                        if diff < 36:
                            continue
                        sat = max(r, g, b) - min(r, g, b)
                        total += diff + sat * 0.18
                        if r > 90 and r - g > 18 and r - b > 14:
                            hot += diff
                scores[gy][gx] = total
                warm[gy][gx] = hot
        values = [scores[y][x] for y in range(rows) for x in range(cols)]
        mean = sum(values) / max(1, len(values))
        threshold = max(125.0, mean * 1.55)
        active = {(x, y) for y in range(rows) for x in range(cols) if scores[y][x] >= threshold}
        regions = []
        while active:
            seed = active.pop()
            stack = [seed]
            cells = [seed]
            while stack:
                cx, cy = stack.pop()
                for ny in range(max(0, cy - 1), min(rows, cy + 2)):
                    for nx in range(max(0, cx - 1), min(cols, cx + 2)):
                        if (nx, ny) in active:
                            active.remove((nx, ny))
                            stack.append((nx, ny))
                            cells.append((nx, ny))
            weight = sum(scores[y][x] for x, y in cells)
            if weight <= 0.0:
                continue
            cx = sum((x + 0.5) / cols * scores[y][x] for x, y in cells) / weight
            cy = 0.20 + sum((y + 0.5) / rows * scores[y][x] for x, y in cells) / weight * 0.72
            hot = sum(warm[y][x] for x, y in cells)
            regions.append((cx, cy, weight, hot, len(cells)))
        regions.sort(key=lambda row: row[2] + row[3] * 0.30, reverse=True)
        return regions[:10]

    def _locate_entities(self, frame, previous):
        regions = self._motion_regions(frame, previous)
        if not regions:
            return self.player_x, self.player_y, self.enemy_x, self.enemy_y
        if self.player_x is None or self.player_y is None:
            candidates = [item for item in regions if item[0] <= 0.68 and item[1] >= 0.30] or regions
            player = min(candidates, key=lambda item: abs(item[0] - 0.34) * 2.0 + abs(item[1] - 0.63) * 0.9 - min(item[2], 6000.0) / 30000.0)
        else:
            player = min(regions, key=lambda item: math.hypot(item[0] - self.player_x, (item[1] - self.player_y) * 0.72) * 3.4 - min(item[2], 7000.0) / 26000.0)
        px, py = player[0], player[1]
        self.player_x = px if self.player_x is None else self.player_x * 0.64 + px * 0.36
        self.player_y = py if self.player_y is None else self.player_y * 0.64 + py * 0.36
        others = [item for item in regions if math.hypot(item[0] - self.player_x, (item[1] - self.player_y) * 0.72) >= 0.10]
        if others:
            if self.enemy_x is not None and self.enemy_y is not None:
                enemy = max(others, key=lambda item: item[2] * 0.65 + item[3] * 0.65 - math.hypot(item[0] - self.enemy_x, item[1] - self.enemy_y) * 2600.0)
            else:
                enemy = max(others, key=lambda item: item[2] + item[3] * 0.55 + abs(item[0] - self.player_x) * item[2] * 0.18)
            ex, ey = enemy[0], enemy[1]
            self.enemy_x = ex if self.enemy_x is None else self.enemy_x * 0.60 + ex * 0.40
            self.enemy_y = ey if self.enemy_y is None else self.enemy_y * 0.60 + ey * 0.40
        return self.player_x, self.player_y, self.enemy_x, self.enemy_y

    def combat_fingerprint(self, frame, cols=10, rows=5):
        if not frame:
            return ()
        result = []
        x1, x2 = int(self.width * 0.05), int(self.width * 0.95)
        y1, y2 = int(self.height * 0.26), int(self.height * 0.88)
        for gy in range(rows):
            y = min(y2 - 1, y1 + int((gy + 0.5) * (y2 - y1) / rows))
            for gx in range(cols):
                x = min(x2 - 1, x1 + int((gx + 0.5) * (x2 - x1) / cols))
                i = (y * self.width + x) * 4
                b, g, r = frame[i], frame[i + 1], frame[i + 2]
                result.append(((r * 3 + g * 6 + b) // 10) // 16)
        return tuple(result)

    def combat_observation(self, frame, previous, motion=0.0):
        self._calibrate_hud(frame)
        hp_run = self._calibrated_run(frame, "hp", "red", (2, 3, int(self.width * 0.62), int(self.height * 0.40)))
        mp_run = self._calibrated_run(frame, "mp", "blue", (2, 3, int(self.width * 0.62), int(self.height * 0.42)))
        boss_run = self._calibrated_run(frame, "boss", "red", (int(self.width * 0.18), 2, int(self.width * 0.99), int(self.height * 0.34)))
        hp = self._bar_ratio(hp_run, "hp", 5)
        mp = self._bar_ratio(mp_run, "mp", 5)
        boss = self._bar_ratio(boss_run, "boss", max(12, int(self.width * 0.045)))
        player_x, player_y, enemy_x, enemy_y = self._locate_entities(frame, previous)
        return CombatObservation(hp, mp, boss, player_x, enemy_x, motion, player_y, enemy_y)

    @staticmethod
    def _compact(text):
        return re.sub(r"\s+", "", text or "")

    def semantic_state(self, snapshot):
        if not snapshot:
            return GameState.UNKNOWN, 0.0
        text = self._compact(snapshot.text)
        if not text:
            return GameState.UNKNOWN, 0.0
        if any(word in text for word in ("确认购买", "充值中心", "支付", "退出游戏", "删除角色")):
            return GameState.UNKNOWN, 0.98
        retry_score = sum(word in text for word in ("挑战失败", "重试", "再次挑战", "重新挑战", "战斗失败"))
        reward_score = sum(word in text for word in ("通关", "胜利", "奖励", "战利品", "领取", "获得"))
        equip_score = sum(word in text for word in ("背包", "穿戴", "更换装备", "装备属性", "一键装备", "一键穿戴"))
        upgrade_score = sum(word in text for word in ("强化", "升级", "锻造", "强化等级", "成功率"))
        stage_score = sum(word in text for word in ("推荐战力", "挑战", "关卡", "副本", "进入关卡"))
        home_score = sum(word in text for word in ("主城", "冒险", "开始游戏", "任务", "角色"))
        if retry_score >= 1:
            return GameState.RETRY, 0.95
        if reward_score >= 2 or ("领取" in text and "奖励" in text):
            return GameState.REWARD, 0.94
        if equip_score >= 2 or ("背包" in text and "装备" in text):
            return GameState.EQUIPMENT, 0.91
        if upgrade_score >= 2 or ("强化" in text and ("等级" in text or "成功率" in text)):
            return GameState.UPGRADE, 0.91
        if stage_score >= 2 and ("挑战" in text or "进入" in text):
            return GameState.SELECT_STAGE, 0.90
        if home_score >= 2 or "主城" in text:
            return GameState.HOME, 0.86
        return GameState.UNKNOWN, 0.0

    def classify(self, frame, previous, snapshot, combat_hint=False):
        brightness, motion, darkness, _ = self.metrics(frame, previous)
        if brightness < 9 or darkness > 0.965:
            return GameState.LOADING, 0.99, motion
        hud = self.hud_score(frame)
        if hud >= 2 and motion >= 1.25:
            return GameState.COMBAT, min(0.96, 0.72 + hud * 0.07 + min(motion, 8.0) * 0.015), motion
        semantic = GameState.UNKNOWN
        confidence = 0.0
        if snapshot and time.monotonic() - snapshot.captured_at <= 4.0:
            semantic, confidence = self.semantic_state(snapshot)
        if hud >= 2 and combat_hint and semantic not in (GameState.REWARD, GameState.RETRY):
            return GameState.COMBAT, 0.76, motion
        if combat_hint and semantic == GameState.UNKNOWN and motion >= 0.72 and brightness >= 15 and darkness < 0.90:


            return GameState.COMBAT, min(0.82, 0.72 + min(motion, 7.0) * 0.014), motion
        if semantic != GameState.UNKNOWN:
            return semantic, confidence, motion
        return GameState.UNKNOWN, 0.25 if hud else 0.0, motion

    def has_danger(self, snapshot):
        if not snapshot:
            return False
        text = self._compact(snapshot.text)
        return any(word in text for word in self.GLOBAL_DANGER_WORDS)

    def _line_candidates(self, snapshot):
        candidates = list(snapshot.words)
        by_line = {}
        for word in snapshot.words:
            by_line.setdefault(word.line, []).append(word)
        for line_id, words in by_line.items():
            if line_id < 0 or len(words) < 2:
                continue
            words = sorted(words, key=lambda item: item.x)
            for start in range(len(words)):
                left = words[start]
                text = self._compact(left.text)
                x1, y1 = left.x, left.y
                x2, y2 = left.x + left.w, left.y + left.h
                previous = left
                for stop in range(start + 1, min(len(words), start + 4)):
                    item = words[stop]
                    gap = item.x - (previous.x + previous.w)
                    if gap > max(46.0, max(previous.h, item.h) * 2.2):
                        break
                    if abs(item.cy - previous.cy) > max(previous.h, item.h) * 0.9:
                        break
                    text += self._compact(item.text)
                    x1, y1 = min(x1, item.x), min(y1, item.y)
                    x2, y2 = max(x2, item.x + item.w), max(y2, item.y + item.h)
                    candidates.append(OCRWord(text, x1, y1, x2 - x1, y2 - y1, line_id))
                    previous = item
        return candidates

    def generic_safe_action_word(self, snapshot):
        if not snapshot:
            return None
        danger = self.has_danger(snapshot)
        priorities = self.SAFE_ABORT_WORDS if danger else self.SAFE_FORWARD_WORDS
        candidates = self._line_candidates(snapshot)
        for wanted in priorities:
            matches = []
            for word in candidates:
                text = self._compact(word.text)
                if wanted not in text:
                    continue
                nx = word.cx / max(snapshot.width, 1)
                ny = word.cy / max(snapshot.height, 1)
                if not (0.02 <= nx <= 0.98 and 0.04 <= ny <= 0.98):
                    continue
                if not danger and self._danger_near(snapshot, word, GameState.UNKNOWN):
                    continue

                penalty = max(0, len(text) - len(wanted)) * 0.03
                center_bias = abs(nx - 0.5) * 0.08 + abs(ny - 0.62) * 0.04
                matches.append((penalty + center_bias, word))
            if matches:
                matches.sort(key=lambda item: item[0])
                return matches[0][1]
        return None

    def safe_growth_action_word(self, snapshot):
        if not snapshot or self.has_danger(snapshot):
            return None
        growth_terms = ("强化", "升级", "升星", "进阶", "培养", "镶嵌", "洗炼", "穿戴", "装备", "法宝", "坐骑")
        candidates = self._line_candidates(snapshot)
        matches = []
        for word in candidates:
            text = self._compact(word.text)
            if "免费" not in text or not any(term in text for term in growth_terms):
                continue
            if self._danger_near(snapshot, word, GameState.UNKNOWN):
                continue
            nx = word.cx / max(snapshot.width, 1)
            ny = word.cy / max(snapshot.height, 1)
            if 0.02 <= nx <= 0.98 and 0.04 <= ny <= 0.98:
                matches.append((len(text), abs(nx - 0.5) + abs(ny - 0.62) * 0.4, word))
        if not matches:
            return None
        matches.sort(key=lambda item: (item[0], item[1]))
        return matches[0][2]

    def action_word(self, snapshot, state, priorities):
        if not snapshot or self.has_danger(snapshot):
            return None
        if state not in (
            GameState.HOME, GameState.SELECT_STAGE, GameState.REWARD,
            GameState.EQUIPMENT, GameState.UPGRADE, GameState.RETRY,
        ):
            return None
        candidates = self._line_candidates(snapshot)
        for wanted in priorities:
            for word in candidates:
                text = self._compact(word.text)
                if wanted not in text:
                    continue
                nx = word.cx / max(snapshot.width, 1)
                ny = word.cy / max(snapshot.height, 1)
                if not (0.02 <= nx <= 0.98 and 0.04 <= ny <= 0.98):
                    continue
                if state == GameState.UPGRADE and "免费" not in text:
                    continue
                if self._danger_near(snapshot, word, state):
                    continue
                return word
        return None

    def _danger_near(self, snapshot, target, state):
        if state == GameState.UPGRADE and "免费" in self._compact(target.text):
            strong = ("购买", "充值", "支付", "花费", "商城", "退出", "删除", "兑换")
        else:
            strong = self.DANGER_WORDS
        radius = max(120.0, snapshot.width * 0.14)
        for word in snapshot.words:
            text = self._compact(word.text)
            if not any(danger in text for danger in strong):
                continue
            if abs(word.cx - target.cx) <= radius and abs(word.cy - target.cy) <= radius * 0.72:
                return True
        return False

    @staticmethod
    def _parse_power_number(number, unit):
        try:
            base = float(number.replace(",", ""))
        except (TypeError, ValueError):
            return None
        if unit == "万":
            base *= 10000
        elif unit == "亿":
            base *= 100000000
        value = int(base)
        return value if 1 <= value <= 10_000_000_000 else None

    def extract_power(self, snapshot):
        if not snapshot:
            return None
        text = self._compact(snapshot.text).replace("，", ",")
        values = []
        for number, unit in re.findall(
            r"(?:当前战力|角色战力|总战力|战斗力)[：:]?([0-9][0-9,.]{0,12})(万|亿)?",
            text,
        ):
            value = self._parse_power_number(number, unit)
            if value:
                values.append(value)
        if values:
            return max(values)

        blockers = ("推荐", "所需", "需求", "敌方", "怪物", "BOSS")
        for match in re.finditer(r"战力[：:]?([0-9][0-9,.]{0,12})(万|亿)?", text):
            prefix = text[max(0, match.start() - 6):match.start()].upper()
            if any(word.upper() in prefix for word in blockers):
                continue
            value = self._parse_power_number(match.group(1), match.group(2))
            if value:
                values.append(value)
        return max(values) if values else None


class SkillHUDTracker:
    KEYS = ("U", "I", "O", "L", "H", "SPACE", "Z")

    def __init__(self, width, height):
        self.width = int(width)
        self.height = int(height)
        self.latest = None
        self.pending = {}
        self.mapping_votes = {key: {} for key in self.KEYS}
        self.mapping = {}
        self.ready_baseline = {}
        self.mapping_confidence = {}
        self._centers = []
        self.discovered = False

    def _discover_centers(self, frame):
        if not frame:
            return
        w, h = self.width, self.height
        step_x = max(3, w // 36)
        step_y = max(3, h // 24)
        rx = max(2, w // 90)
        ry = max(2, h // 55)
        candidates = []
        for y in range(max(ry, int(h * 0.50)), h - ry, step_y):
            for x in range(rx, w - rx, step_x):
                values = []
                sats = []
                for px, py in ((x, y), (x-rx, y), (x+rx, y), (x, y-ry), (x, y+ry)):
                    i = (py * w + px) * 4
                    b, g, r = frame[i], frame[i + 1], frame[i + 2]
                    hi, lo = max(r, g, b), min(r, g, b)
                    values.append((r * 0.30 + g * 0.59 + b * 0.11) / 255.0)
                    sats.append((hi - lo) / max(hi, 32))
                contrast = max(values) - min(values)
                sat = sum(sats) / len(sats)
                score = contrast * 0.62 + sat * 0.38
                if score >= 0.22:
                    candidates.append((score, x, y))
        candidates.sort(reverse=True)
        chosen = []
        sep_x = max(5, int(w * 0.035))
        sep_y = max(4, int(h * 0.055))
        for score, x, y in candidates:
            if any(abs(x - ox) < sep_x and abs(y - oy) < sep_y for ox, oy in chosen):
                continue
            chosen.append((x, y))
            if len(chosen) >= 32:
                break
        if len(chosen) < 10:
            chosen = [(int(w * (0.18 + col * 0.07)), int(h * row_y)) for row_y in (0.76, 0.88) for col in range(12)]
        chosen.sort(key=lambda item: (item[1], item[0]))
        self._centers = [(x / max(1.0, float(w)), y / max(1.0, float(h))) for x, y in chosen]
        self.discovered = True

    def _tile_features(self, frame):
        if not frame:
            return None
        features = []
        rx = max(2, int(self.width * 0.018))
        ry = max(2, int(self.height * 0.030))
        for nx, ny in self._centers:
            cx = max(rx, min(self.width - rx - 1, int(nx * self.width)))
            cy = max(ry, min(self.height - ry - 1, int(ny * self.height)))
            lum = sat = count = 0.0
            step_x = max(1, rx // 2)
            step_y = max(1, ry // 2)
            for y in range(cy - ry, cy + ry + 1, step_y):
                for x in range(cx - rx, cx + rx + 1, step_x):
                    i = (y * self.width + x) * 4
                    b, g, r = frame[i], frame[i + 1], frame[i + 2]
                    hi, lo = max(r, g, b), min(r, g, b)
                    lum += (r * 0.30 + g * 0.59 + b * 0.11) / 255.0
                    sat += (hi - lo) / max(hi, 32)
                    count += 1.0
            features.append((lum / max(count, 1.0), sat / max(count, 1.0)))
        return tuple(features)

    @staticmethod
    def _score(feature):
        return feature[0] * 0.58 + feature[1] * 0.42

    def observe(self, frame, now):
        if not self.discovered:
            self._discover_centers(frame)
        current = self._tile_features(frame)
        if current is None:
            return
        self.latest = current
        for key, pending in list(self.pending.items()):
            age = now - pending["at"]
            if age < 0.10:
                continue
            if age <= 0.62 and not pending.get("voted"):
                before = pending["before"]
                ranked = []
                for index, (old, new) in enumerate(zip(before, current)):
                    old_score = self._score(old)
                    new_score = self._score(new)
                    drop = old_score - new_score
                    feature_shift = abs(old[0] - new[0]) * 0.55 + abs(old[1] - new[1]) * 0.45
                    ranked.append((drop * 0.72 + feature_shift * 0.28, index, old_score))
                ranked.sort(reverse=True)
                best = ranked[0]
                second = ranked[1][0] if len(ranked) > 1 else 0.0
                if best[0] >= 0.075 and best[0] >= second * 1.15:
                    pending["voted"] = True
                    votes = self.mapping_votes[key]
                    row = votes.setdefault(best[1], [0.0, 0])
                    row[0] += best[0]
                    row[1] += 1
                    candidates = sorted(((v[0], v[1], idx) for idx, v in votes.items()), reverse=True)
                    top = candidates[0]
                    runner = candidates[1][0] if len(candidates) > 1 else 0.0
                    if top[1] >= 2 and top[0] >= max(0.18, runner * 1.22):
                        self.mapping[key] = top[2]
                        self.mapping_confidence[key] = min(1.0, top[0] / 0.42)
                        baseline = pending["before"][top[2]]
                        score = self._score(baseline)
                        old_base = self.ready_baseline.get(key)
                        self.ready_baseline[key] = score if old_base is None else old_base * 0.72 + score * 0.28
            if age > 0.62:
                self.pending.pop(key, None)

    def note_action(self, key, now):
        if key not in self.KEYS or self.latest is None:
            return
        mapped = self.mapping.get(key)
        if mapped is not None:
            score = self._score(self.latest[mapped])
            old = self.ready_baseline.get(key)
            self.ready_baseline[key] = score if old is None else old * 0.82 + score * 0.18
        self.pending[key] = {"at": now, "before": self.latest, "voted": False}

    def readiness(self):
        result = {}
        if self.latest is None:
            return result
        for key in self.KEYS:
            index = self.mapping.get(key)
            baseline = self.ready_baseline.get(key)
            confidence = self.mapping_confidence.get(key, 0.0)
            if index is None or baseline is None or baseline < 0.12 or confidence < 0.45:
                continue
            current = self._score(self.latest[index])
            ratio = current / max(baseline, 1e-6)
            if ratio <= 0.79:
                result[key] = False
            elif ratio >= 0.90:
                result[key] = True
        return result


class StateDetector:
    def __init__(self):
        self.stable = GameState.UNKNOWN
        self.candidate = GameState.UNKNOWN
        self.count = 0
        self.confidence = 0.0

    def update(self, state, confidence):
        if state == GameState.LOADING:
            self.stable = state
            self.candidate = state
            self.count = 1
            self.confidence = confidence
            return self.stable
        needed = 2 if state == GameState.COMBAT else 3
        if confidence < (0.70 if state == GameState.COMBAT else 0.82):
            state = GameState.UNKNOWN
            needed = 3
        if state == self.candidate:
            self.count += 1
        else:
            self.candidate = state
            self.count = 1
        self.confidence = confidence
        if self.count >= needed:
            self.stable = state
        return self.stable


class VisualStateMemory:
    def __init__(self, vision, path=None):
        self.vision = vision
        self.path = path
        self.prototypes = {state: [] for state in GameState}
        self.max_per_state = 18
        self._load()

    def _load(self):
        if not self.path or not os.path.isfile(self.path):
            return
        try:
            with gzip.open(self.path, "rt", encoding="utf-8") as handle:
                data = json.load(handle)
            if str(data.get("game_id") or "") != "100072570" or int(data.get("schema", 0)) != 1:
                return
            for name, rows in (data.get("states") or {}).items():
                try:
                    state = GameState[name]
                except Exception:
                    continue
                clean = []
                for row in rows[-self.max_per_state:]:
                    if isinstance(row, list) and row:
                        clean.append(tuple(int(x) for x in row))
                self.prototypes[state] = clean
        except Exception:
            pass

    def save(self):
        if not self.path:
            return
        tmp = self.path + ".tmp"
        try:
            states = {state.name: [list(x) for x in rows[-self.max_per_state:]] for state, rows in self.prototypes.items() if rows}
            with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=5) as handle:
                json.dump({"game_id": "100072570", "schema": 1, "width": self.vision.width, "height": self.vision.height, "states": states}, handle, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, self.path)
        except Exception:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    def observe(self, state, confidence, fingerprint):
        if state in (GameState.UNKNOWN, GameState.LOADING) or confidence < 0.82 or not fingerprint:
            return
        bucket = self.prototypes[state]
        if bucket and min(self.vision.fingerprint_distance(fingerprint, old) for old in bucket) < 0.42:
            return
        bucket.append(tuple(fingerprint))
        if len(bucket) > self.max_per_state:
            bucket.pop(0)

    def infer(self, fingerprint):
        candidates = []
        for state, bucket in self.prototypes.items():
            if state in (GameState.UNKNOWN, GameState.LOADING, GameState.COMBAT) or not bucket:
                continue
            distance = min(self.vision.fingerprint_distance(fingerprint, old) for old in bucket)
            candidates.append((distance, state))
        if not candidates:
            return GameState.UNKNOWN, 0.0
        candidates.sort(key=lambda item: item[0])
        best_distance, best_state = candidates[0]
        second = candidates[1][0] if len(candidates) > 1 else 99.0
        if best_distance > 0.78 or second - best_distance < 0.10:
            return GameState.UNKNOWN, 0.0
        confidence = max(0.82, min(0.93, 0.94 - best_distance * 0.14))
        return best_state, confidence


class PowerTracker:
    GROWTH_KINDS = ("equip", "free_upgrade", "safe_growth")

    def __init__(self, path=None, persistence=None):
        self.path = path
        self.persistence = persistence
        self.environment_fingerprint = {"game_id": "100072570", "progress_schema": 2}
        self.current_power = 0
        self.best_power = 0
        self.actual_power_gains = 0
        self.action_completed = 0
        self.confirmed_power_gain_actions = 0
        self.pending = None
        self.stage_stats = {}
        self.action_stats = {kind: ActionStats() for kind in self.GROWTH_KINDS}
        self.selected_stage = None
        self.current_stage = None
        self.combat_started = 0.0
        self.power_candidate = 0
        self.power_candidate_hits = 0
        self.last_save = 0.0
        self._load()

    def set_environment_fingerprint(self, client_w, client_h, sample_w, sample_h):
        self.environment_fingerprint.update({
            "window_w": max(0, int(client_w or 0)), "window_h": max(0, int(client_h or 0)),
            "sample_w": max(0, int(sample_w or 0)), "sample_h": max(0, int(sample_h or 0)),
            "scale_x": round(float(sample_w) / max(1.0, float(client_w)), 6),
            "scale_y": round(float(sample_h) / max(1.0, float(client_h)), 6),
        })

    def observe_power(self, value):
        if not value:
            return False
        value = int(value)
        if self.power_candidate:
            tolerance = max(5, int(self.power_candidate * 0.003))
            if abs(value - self.power_candidate) <= tolerance:
                self.power_candidate_hits += 1
                weight = min(self.power_candidate_hits, 4)
                self.power_candidate = int(round((self.power_candidate * (weight - 1) + value) / weight))
            else:
                self.power_candidate = value
                self.power_candidate_hits = 1
        else:
            self.power_candidate = value
            self.power_candidate_hits = 1
        required = 2
        if self.current_power and abs(self.power_candidate - self.current_power) > max(5000, int(self.current_power * 0.50)):
            required = 3
        if self.power_candidate_hits < required:
            return False
        stable_value = self.power_candidate
        increased = bool(self.current_power and stable_value > self.current_power)
        if increased:
            self.actual_power_gains += 1
        self.current_power = stable_value
        self.best_power = max(self.best_power, stable_value)
        return increased

    def start_action(self, kind, state, fingerprint):
        self.pending = PendingAction(kind, state, fingerprint, time.monotonic(), self.current_power)
        if kind in self.action_stats:
            self.action_stats[kind].attempts += 1

    def _finish_growth_action(self, pending, success):
        stats = self.action_stats.get(pending.kind)
        if stats is not None:
            stats.total_seconds += max(0.1, time.monotonic() - pending.at)
            if success:
                stats.successes += 1
                stats.total_power_delta += max(0, self.current_power - pending.power_before)
            else:
                stats.failures += 1
        self.pending = None
        self.save()

    def resolve_action(self, state, fingerprint, vision):
        pending = self.pending
        if not pending:
            return
        now = time.monotonic()
        if now - pending.at < 0.65:
            return
        state_changed = state != pending.state and state != GameState.UNKNOWN
        scene_changed = vision.fingerprint_distance(fingerprint, pending.fingerprint) >= 1.8
        power_increased = self.current_power > pending.power_before > 0

        if pending.kind in self.action_stats:
            if not pending.completed and (scene_changed or state_changed):
                pending.completed = True
                self.action_completed += 1
            if power_increased:
                if not pending.completed:
                    self.action_completed += 1
                self.confirmed_power_gain_actions += 1
                self._finish_growth_action(pending, True)
                return
            if now - pending.at > 8.0:
                self._finish_growth_action(pending, False)
            return

        completed = False
        if pending.kind == "reward":
            completed = state_changed and state != GameState.REWARD
        elif pending.kind in ("home", "stage_select", "stage_enter", "retry", "open_equipment", "open_upgrade"):
            completed = state_changed or scene_changed
        if completed:
            self.action_completed += 1
            self.pending = None
        elif now - pending.at > 6.5:
            self.pending = None

    def growth_action_order(self):
        def score(kind):
            stats = self.action_stats[kind]
            if stats.attempts == 0:
                return 1_000_000.0
            expected_delta = (stats.total_power_delta + max(120.0, self.best_power * 0.0008)) / (stats.successes + 1.0)
            expected_seconds = max(0.8, stats.average_seconds)
            failure_risk = (stats.failures + 0.5) / (stats.attempts + 2.0)
            exploration = 80.0 / math.sqrt(stats.attempts + 1.0)
            return expected_delta / expected_seconds * (1.0 - min(0.90, failure_risk)) + exploration
        return sorted(self.GROWTH_KINDS, key=score, reverse=True)

    def select_stage(self, stage_id):
        self.selected_stage = stage_id

    def entered_combat(self):
        self.current_stage = self.selected_stage
        self.selected_stage = None
        self.combat_started = time.monotonic()

    def combat_result(self, won):
        if not self.combat_started:
            return
        stage = self.current_stage or "current"
        stats = self.stage_stats.setdefault(stage, StageStats())
        stats.attempts += 1
        if won:
            stats.wins += 1
            stats.total_seconds += max(0.1, time.monotonic() - self.combat_started)
        self.combat_started = 0.0
        self.save()

    def record_stuck(self):
        stage = self.current_stage or "current"
        self.stage_stats.setdefault(stage, StageStats()).stuck_events += 1
        self.save()

    def choose_stage(self, options):
        if not options:
            return None
        scored = []
        for numeric_value, required_power, word, stage_id in options:
            score = float(numeric_value)
            if required_power and self.current_power:
                ratio = self.current_power / max(required_power, 1)
                if ratio < 0.72:
                    score -= 150000.0 + (0.72 - ratio) * 60000.0
                elif ratio < 0.95:
                    score -= (0.95 - ratio) * 4500.0
                else:
                    score += min(1.5, ratio) * 220.0
            stats = self.stage_stats.get(stage_id)
            if stats and stats.attempts >= 2:
                reliability = stats.success_rate
                stuck_rate = stats.stuck_events / max(stats.attempts, 1)
                score += reliability * 1250.0 - stats.average_seconds * 0.12 - stuck_rate * 180.0
                if reliability < 0.55:
                    score -= 90000.0
            scored.append((score, word, stage_id))
        scored.sort(key=lambda item: item[0], reverse=True)
        return scored[0][1], scored[0][2]


    def save(self):
        if not self.path:
            return
        now = time.monotonic()
        if now - self.last_save < 1.0:
            return
        data = {
            "version": 2,
            "environment": self.environment_fingerprint,
            "best_power": self.best_power,
            "stage_stats": {
                str(key): {
                    "attempts": value.attempts, "wins": value.wins,
                    "total_seconds": value.total_seconds, "stuck_events": value.stuck_events,
                }
                for key, value in self.stage_stats.items()
            },
            "action_stats": {
                key: {
                    "attempts": value.attempts, "successes": value.successes,
                    "failures": value.failures, "total_power_delta": value.total_power_delta,
                    "total_seconds": value.total_seconds,
                }
                for key, value in self.action_stats.items()
            },
        }
        tmp = self.path + ".tmp"
        backup = self.path + ".bak"
        try:
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
            with open(tmp, "r", encoding="utf-8") as handle:
                check = json.load(handle)
            if not isinstance(check, dict) or check.get("version") != 2:
                raise ValueError("进度保存校验失败")
            if os.path.isfile(self.path):
                try:
                    shutil.copy2(self.path, backup)
                except OSError:
                    pass
            os.replace(tmp, self.path)
            self.last_save = now
            if self.persistence is not None:
                self.persistence.ok("progress")
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            if self.persistence is not None:
                self.persistence.fail("progress", exc)
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    def _load(self):
        if not self.path:
            return
        try:
            data = None
            for source, quarantine in ((self.path, True), (self.path + ".bak", False)):
                if not os.path.isfile(source):
                    continue
                try:
                    with open(source, "r", encoding="utf-8") as handle:
                        candidate = json.load(handle)
                    if not isinstance(candidate, dict) or candidate.get("version") not in (1, 2):
                        raise ValueError("进度文件结构无效")
                    data = candidate
                    break
                except (OSError, ValueError, TypeError, json.JSONDecodeError):
                    if quarantine:
                        try:
                            os.replace(self.path, self.path + f".corrupt.{int(time.time())}")
                        except OSError:
                            pass
            if data is None:
                return
            environment = data.get("environment") or {}
            if isinstance(environment, dict) and environment and str(environment.get("game_id") or "100072570") != str(self.environment_fingerprint["game_id"]):
                return
            self.best_power = max(0, int(data.get("best_power", 0)))
            for key, raw in (data.get("stage_stats") or {}).items():
                if not isinstance(raw, dict):
                    continue
                self.stage_stats[str(key)] = StageStats(
                    attempts=max(0, int(raw.get("attempts", 0))),
                    wins=max(0, int(raw.get("wins", 0))),
                    total_seconds=max(0.0, float(raw.get("total_seconds", 0.0))),
                    stuck_events=max(0, int(raw.get("stuck_events", 0))),
                )
            for key, raw in (data.get("action_stats") or {}).items():
                if key not in self.action_stats or not isinstance(raw, dict):
                    continue
                self.action_stats[key] = ActionStats(
                    attempts=max(0, int(raw.get("attempts", 0))),
                    successes=max(0, int(raw.get("successes", 0))),
                    failures=max(0, int(raw.get("failures", 0))),
                    total_power_delta=max(0, int(raw.get("total_power_delta", 0))),
                    total_seconds=max(0.0, float(raw.get("total_seconds", 0.0))),
                )
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            pass


class AdaptiveAgent:
    def __init__(self, winio, hwnd, stop_event, send_status, base_dir, power_tracker, profile, persistence=None):
        self.io = winio
        self.hwnd = hwnd
        self.stop_event = stop_event
        self.send_status = send_status
        self.profile = profile
        self.persistence = persistence
        self.governor = RuntimeGovernor(profile)
        self.vision = Vision(profile.sample_w, profile.sample_h)
        self.detector = StateDetector()
        self.state_memory = VisualStateMemory(self.vision, os.path.join(base_dir, ".ai_visual_memory.json.gz"))
        self.power = power_tracker
        self.grabber = FrameGrabber(winio, profile.sample_w, profile.sample_h, base_dir, profile, stop_event, hwnd)
        self.viewport = GameViewportDetector(profile.sample_w, profile.sample_h)
        self.ocr = AsyncOCR(winio, stop_event, base_dir, max_width=profile.ocr_max_width)
        self.ocr_available = False
        self.ocr_degraded_reported = False
        self.skill_hud = SkillHUDTracker(profile.sample_w, profile.sample_h)
        self.visual_encoder = CudaVisualEncoder(base_dir, profile, profile.sample_w, profile.sample_h, stop_event)
        self.previous = None
        self.snapshot = None
        self.last_ocr_request = 0.0
        self.last_ocr_recover = 0.0
        self.last_status = 0.0
        self.last_action = 0.0
        self.state_since = time.monotonic()
        self.last_effective_change = self.state_since
        self.scene_anchor = ()
        self.last_state = GameState.UNKNOWN
        self.recovery_attempts = 0
        self.last_recovery = 0.0
        self.target_confirmed = False
        self.confirm_streak = 0
        self.confirm_ocr_streak = 0
        self.identity_fail_streak = 0
        self.identity_last_ok = 0.0
        self.confirm_deadline = self.state_since + 30.0
        self.focus_lost_since = 0.0
        self.focus_recover_attempted = False
        self.latest_frame = None
        self.in_combat_episode = False
        self.combat_episode_started = 0.0
        self.terminal_candidate_since = 0.0
        self.terminal_hud_peak = 0
        self.combat_obs = CombatObservation()
        self.combat_frame_fingerprint = ()
        self.scene = SceneUnderstanding(self.vision, profile.sample_w, profile.sample_h, os.path.join(base_dir, ".ai_scene_prototypes.json.gz"), self.visual_encoder)
        self.world_model = CausalWorldModel(
            os.path.join(base_dir, ".ai_world_model_v3.json.gz"), profile,
            legacy_path=os.path.join(base_dir, ".ai_world_model_v2.json"), persistence=self.persistence, stop_event=self.stop_event,
            latent_dim=self.visual_encoder.latent_dim,
        )
        self.world_state = WorldState(captured_at=self.state_since)
        self.previous_world_state = None
        self.world_probe = None
        self.last_world_action = 0.0
        self.last_passive_sample = self.state_since
        self.last_plan_score = 0.0
        self.tactical_mode = "观察"
        self.last_tactic = ""
        self.last_emergency = 0.0
        self.current_action_timing = None
        self.unknown_actions = 0
        self.unknown_dynamic_since = 0.0
        self.novel_play_mode = False
        self.novel_play_since = 0.0
        self.io.bind_input_guard(self._input_guard)

    def _game_rect(self):
        return self.viewport.rect(self.io.client_rect(self.hwnd))

    def _input_guard(self):
        if self.stop_event.is_set():
            return False
        fresh_identity = time.monotonic() - self.identity_last_ok <= 1.4
        return self.target_confirmed and fresh_identity and self.io.valid_window(self.hwnd) and self.io.is_foreground(self.hwnd)

    def _update_target_confirmation(self, frame, now):
        title = self.io.window_title(self.hwnd)
        title_ok = self.io._game_title_ok(title)
        strong_title = self.io._strong_game_title_ok(title)
        hud = self.vision.hud_score(frame)
        snapshot = self.snapshot
        text = self.vision._compact(snapshot.text) if snapshot and now - snapshot.captured_at <= 5.0 else ""
        tokens = ("造梦西游", "黎尤浩劫", "战力", "法宝", "无双", "推荐战力", "关卡", "副本", "挑战", "主城")
        ocr_hits = sum(token in text for token in tokens)
        semantic = self.vision.semantic_state(snapshot)[0] if text else GameState.UNKNOWN
        ocr_specific = ocr_hits >= 2 or (ocr_hits >= 1 and semantic != GameState.UNKNOWN)
        semantic_specific = ocr_specific and semantic != GameState.UNKNOWN
        visual_specific = hud >= 2 and sum(self.vision.hud_votes.get(name, 0) >= 3 for name in ("hp", "mp", "boss")) >= 1
        visual_ocr = hud >= 2 and ocr_specific
        identity_recent = self.identity_last_ok > 0.0 and now - self.identity_last_ok <= 2.0
        verified = visual_ocr or (semantic_specific and hud >= 1) or (visual_specific and (strong_title or ocr_hits >= 1)) or (visual_specific and identity_recent)
        if self.target_confirmed:
            if verified:
                self.identity_last_ok = now
                self.identity_fail_streak = 0
                return True
            self.identity_fail_streak += 1
            if self.identity_fail_streak >= 6:
                self.target_confirmed = False
                self.confirm_streak = 0
                self.confirm_ocr_streak = 0
                self.identity_last_ok = 0.0
                self.io.release_all()
                self.send_status("游戏身份连续校验失败｜输入权限已撤销｜等待重新二阶段确认｜键鼠输入接管")
            return False
        if visual_ocr:
            self.confirm_streak += 2
            self.confirm_ocr_streak += 1
        elif semantic_specific and hud >= 1:
            self.confirm_streak += 2
            self.confirm_ocr_streak += 1
        elif visual_specific and (strong_title or title_ok):
            self.confirm_streak += 1
            self.confirm_ocr_streak = max(0, self.confirm_ocr_streak - 1)
        else:
            self.confirm_streak = max(0, self.confirm_streak - 2)
            self.confirm_ocr_streak = max(0, self.confirm_ocr_streak - 1)
        if (self.confirm_ocr_streak >= 3 and self.confirm_streak >= 5) or (strong_title and visual_specific and self.confirm_streak >= 12):
            self.target_confirmed = True
            self.identity_last_ok = now
            self.identity_fail_streak = 0
            self.send_status("游戏窗口二阶段确认通过｜输入权限已解锁｜键鼠输入可立即接管")
            return True
        return False

    def _online_benchmark(self, rect):
        if not rect:
            return
        _, _, client_w, client_h = rect
        aspect = client_h / max(1.0, float(client_w))
        current = int(self.grabber.width)
        target = max(0.010, min(0.026, self.profile.loop_target * 0.34))
        widths = {max(208, min(client_w, int(value) // 8 * 8)) for value in (208, current * 0.82, current)}
        probe = max(208, current)
        while probe < client_w:
            next_width = min(client_w, max(probe + 8, int(probe * 1.22) // 8 * 8))
            widths.add(max(208, next_width))
            if next_width <= probe:
                break
            probe = next_width
        widths = sorted(widths)
        best = (current, self.grabber.height, 999.0, 999.0)
        for width in widths:
            if self.stop_event.is_set():
                return
            height = max(117, int(round(width * aspect)))
            test = None
            try:
                test = FrameGrabber(self.io, width, height, self.grabber.base_dir, self.profile, self.stop_event, self.hwnd)
                vision = Vision(width, height)
                scene = SceneUnderstanding(vision, width, height)
                hud = SkillHUDTracker(width, height)
                samples = []
                previous = None
                for _ in range(7):
                    started = time.perf_counter()
                    frame = test.capture(rect)
                    if not frame:
                        break
                    _, motion, _, _ = vision.metrics(frame, previous)
                    vision.hud_score(frame)
                    fingerprint = vision.combat_fingerprint(frame)
                    obs = vision.combat_observation(frame, previous, motion)
                    scene.encode(frame, previous, obs, fingerprint, motion)
                    hud.observe(frame, time.monotonic())
                    samples.append(time.perf_counter() - started)
                    previous = frame
                if len(samples) >= 4:
                    usable = sorted(samples[1:])
                    p50 = usable[len(usable) // 2]
                    p95 = usable[min(len(usable) - 1, max(0, math.ceil(len(usable) * 0.95) - 1))]
                    if p95 <= target * 1.08 or width <= current:
                        if width > best[0] or best[2] == 999.0:
                            best = (width, height, p95, p50)
                    elif best[2] < 999.0 and width > best[0]:
                        break
            except Exception:
                pass
            finally:
                if test is not None:
                    test.close()
        width, height, p95, p50 = best
        if width != self.grabber.width or height != self.grabber.height:
            self.grabber.close()
            self.grabber = FrameGrabber(self.io, width, height, self.grabber.base_dir, self.profile, self.stop_event, self.hwnd)
            self.vision = Vision(width, height)
            self.state_memory = VisualStateMemory(self.vision, os.path.join(self.grabber.base_dir, ".ai_visual_memory.json.gz"))
            self.skill_hud = SkillHUDTracker(width, height)
            self.visual_encoder.close()
            self.visual_encoder = CudaVisualEncoder(self.grabber.base_dir, self.profile, width, height, self.stop_event)
            self.scene = SceneUnderstanding(self.vision, width, height, os.path.join(self.grabber.base_dir, ".ai_scene_prototypes.json.gz"), self.visual_encoder)
            self.viewport = GameViewportDetector(width, height)
            self.previous = None
        if p95 < 999.0:
            ratio = target / max(0.0002, p95)
            if ratio > 1.0:
                self.governor.candidate_budget = max(self.governor.candidate_budget + 1, int(self.governor.candidate_budget * math.sqrt(ratio)))
            elif ratio < 0.90:
                self.governor.candidate_budget = max(5, int(self.governor.candidate_budget * math.sqrt(max(0.20, ratio))))
        self.world_model.set_runtime_budget(self.governor.candidate_budget, self.governor.planning_budget)
        self.world_model.set_environment_fingerprint(client_w, client_h, width, height)
        self.power.set_environment_fingerprint(client_w, client_h, width, height)
        timing = "?" if p95 >= 999.0 else f"p50 {p50 * 1000.0:.1f}ms/p95 {p95 * 1000.0:.1f}ms"
        self.send_status(f"在线基准完成｜观察 {width}×{height}｜完整视觉 {timing}｜候选 {self.governor.candidate_budget}｜键鼠输入接管")

    def _update_novel_play_mode(self, state, motion, now):
        safe_unknown = (
            self.target_confirmed and state == GameState.UNKNOWN and not self.in_combat_episode
            and not self.vision.has_danger(self.snapshot) and motion >= 0.82
        )
        if safe_unknown:
            if not self.unknown_dynamic_since:
                self.unknown_dynamic_since = now
            if not self.novel_play_mode and now - self.unknown_dynamic_since >= 1.15:
                self.novel_play_mode = True
                self.novel_play_since = now
                self.scene.reset_episode()
                self.world_probe = None
                self.previous_world_state = None
                self.tactical_mode = "新玩法观察建模"
        else:
            self.unknown_dynamic_since = 0.0
            if self.novel_play_mode and state != GameState.UNKNOWN:
                self.novel_play_mode = False
                self.novel_play_since = 0.0
                self.world_probe = None
                self.previous_world_state = None

    def _novel_gameplay(self, now):
        state = self.world_state
        self.world_model.set_policy_context(state)
        if state is None or self.world_probe is not None:
            return
        if self._emergency_reflex(now):
            return
        available = set(self.world_model.available(now, self.skill_hud.readiness()))
        if not available:
            return
        age = now - self.novel_play_since if self.novel_play_since else 0.0
        confidence = self.world_model.context_confidence(state)
        base = ["F", "TOWARD", "K", "J", "W", "S", "A", "D", "EVADE", "RETREAT"]
        if age >= 5.0 or confidence >= 0.18 or state.engaged >= 0.42:
            base += ["U", "I", "O", "L", "Z"]
        if (age >= 10.0 or confidence >= 0.32) and state.engaged >= 0.34:
            base += ["JJJ", "KJ", "CHASEJ", "UJ", "IJ", "OJ", "LJ", "SPACE"]
        candidates = [a for a in base if a in available]
        if not candidates:
            return
        candidates.sort(key=lambda a: self.world_model.probe_score(a, state), reverse=True)
        candidates = candidates[:max(5, int(self.governor.candidate_budget))]
        action, score = self._timed_plan(state, candidates, 0.45 if confidence < 0.30 else 0.65)
        if action and self._execute_world_action(action, now):
            self.tactical_mode = "新玩法因果探索"
            self.last_plan_score = score

    def run(self):
        try:
            if not self.io.foreground(self.hwnd):
                raise RuntimeError("无法将游戏窗口置于前台")
            initial_rect = self.io.client_rect(self.hwnd)
            self._online_benchmark(initial_rect)
            ocr_started = time.perf_counter()
            self.ocr_available = self.ocr.self_test()
            ocr_elapsed = time.perf_counter() - ocr_started
            self.governor.ocr_scale = max(0.72, min(2.8, ocr_elapsed / 0.85 if ocr_elapsed > 0.0 else 1.0))
            if self.ocr_available:
                self.ocr.start()
                language = self.ocr.worker.language or "用户语言"
                if not language.lower().startswith("zh"):
                    self.send_status(f"中文 OCR 不可用，已降级到 {language} OCR｜视觉战斗保持启用｜键鼠输入接管")
            else:
                self.send_status("Windows OCR 不可用，已进入纯视觉战斗模式｜菜单仅做安全视觉等待｜键鼠输入接管")
            while not self.stop_event.is_set():
                cycle_started = time.perf_counter()
                if not self.io.valid_window(self.hwnd):
                    raise RuntimeError("Firefox 游戏窗口已关闭")
                if not self.io.is_foreground(self.hwnd):
                    self.io.release_all()
                    now = time.monotonic()
                    if not self.focus_lost_since:
                        self.focus_lost_since = now
                        self.focus_recover_attempted = False
                        self.send_status("游戏窗口失去前台｜已释放全部按键｜短暂尝试安全恢复焦点")
                    lost_for = now - self.focus_lost_since
                    if lost_for >= 0.55 and not self.focus_recover_attempted and not self.stop_event.is_set():
                        self.focus_recover_attempted = True
                        if self.io.foreground(self.hwnd):
                            self.focus_lost_since = 0.0
                            self.focus_recover_attempted = False
                            self.stop_event.wait(0.05)
                            continue
                    if lost_for >= 1.0:
                        raise RuntimeError("游戏窗口持续失去前台，已安全停止并释放输入")
                    self.stop_event.wait(0.08)
                    continue
                self.focus_lost_since = 0.0
                self.focus_recover_attempted = False
                client_rect = self.io.client_rect(self.hwnd)
                if not client_rect:
                    self.io.release_all()
                    self.stop_event.wait(0.15)
                    continue
                now = time.monotonic()
                probe_frame = None
                if self.viewport.should_probe(now):
                    probe_frame = self.grabber.capture(client_rect)
                    if probe_frame:
                        self.viewport.observe(probe_frame, client_rect, now)
                rect = self.viewport.rect(client_rect)
                if probe_frame is not None and rect == client_rect:
                    frame = probe_frame
                else:
                    frame = self.grabber.capture(rect)
                if not frame:
                    self.stop_event.wait(0.15)
                    continue
                self.latest_frame = frame
                self.skill_hud.observe(frame, now)

                available, snapshot = self.ocr.take_latest()
                if available:
                    self.snapshot = snapshot
                    if snapshot:
                        self.power.observe_power(self.vision.extract_power(snapshot))
                if self.ocr.disabled and self.ocr_available:
                    self.ocr_available = False
                    self.snapshot = None
                    if not self.ocr_degraded_reported:
                        self.ocr_degraded_reported = True
                        self.send_status("OCR 运行中失效，已自动降级为纯视觉战斗模式｜键鼠输入接管")
                if not self.ocr_available and not self.ocr.disabled and now - self.last_ocr_recover >= 20.0 and now >= self.ocr.retry_at:
                    self.last_ocr_recover = now
                    if self.ocr.self_test():
                        self.ocr_available = True
                        self.ocr_degraded_reported = False
                        self.ocr.start()
                        self.send_status("OCR 熔断已恢复｜重新启用菜单语义确认｜键鼠输入接管")
                    else:
                        self.ocr.worker.recovery_count += 1
                        self.ocr.worker.cooldown_until = now + min(120.0, 10.0 * (1.7 ** min(6, self.ocr.worker.recovery_count - 1)))
                if self.ocr_available and now - self.last_ocr_request >= self.governor.ocr_interval and self.ocr.request(rect):
                    self.last_ocr_request = now

                fingerprint = self.vision.fingerprint(frame)
                raw_state, confidence, motion = self.vision.classify(
                    frame, self.previous, self.snapshot,
                    self.detector.stable == GameState.COMBAT or self.in_combat_episode or self.novel_play_mode,
                )
                if raw_state == GameState.UNKNOWN and not self.vision.has_danger(self.snapshot):
                    recalled_state, recalled_confidence = self.state_memory.infer(fingerprint)
                    if recalled_confidence > confidence and not self.novel_play_mode:
                        raw_state, confidence = recalled_state, recalled_confidence
                else:
                    self.state_memory.observe(raw_state, confidence, fingerprint)
                self._update_target_confirmation(frame, now)
                if not self.target_confirmed and now >= self.confirm_deadline:
                    if self.ocr_available:
                        self.ocr_available = False
                        self.snapshot = None
                        self.ocr_degraded_reported = True
                        self.send_status("OCR 未能确认游戏界面，已自动降级为纯视觉模式｜不会点击未确认菜单｜键鼠输入接管")
                    else:
                        self.send_status("纯视觉模式等待可确认的游戏 HUD｜不会点击未确认菜单｜键鼠输入接管")
                    self.confirm_deadline = now + 30.0

                stable = self.detector.update(raw_state, confidence)
                self._update_novel_play_mode(stable, motion, now)
                self._track_progress(stable, fingerprint, now)
                self.power.resolve_action(stable, fingerprint, self.vision)
                if stable != self.last_state:
                    self._on_state_change(self.last_state, stable)
                    self.last_state = stable
                    self.state_since = now
                if stable == GameState.COMBAT or self.in_combat_episode or self.novel_play_mode:
                    self.combat_obs = self.vision.combat_observation(frame, self.previous, motion)
                    self.combat_frame_fingerprint = self.vision.combat_fingerprint(frame)
                    self.world_state = self.scene.encode(
                        frame, self.previous, self.combat_obs, self.combat_frame_fingerprint, motion
                    )
                    self._resolve_world_probe(now)
                    self._learn_passive_transition(now)
                if self._infer_neutral_terminal(stable, frame, now):
                    self.previous = frame
                    continue
                self._handle_state(stable, motion, fingerprint, now)
                self.previous = frame
                if now - self.last_status >= 1.2:
                    self._status(stable)
                    self.last_status = now
                delay = self.governor.finish(time.perf_counter() - cycle_started)
                self.stop_event.wait(delay)
        finally:
            self.state_memory.save()
            self.scene.save_prototypes()
            self.visual_encoder.close()
            self.world_model.save(force=True)
            self.ocr.close()
            self.io.bind_input_guard(None)
            self.io.release_all()
            self.grabber.close()

    def _track_progress(self, state, fingerprint, now):
        if state != self.last_state and state != GameState.UNKNOWN:
            self.last_effective_change = now
            self.scene_anchor = fingerprint
            self.recovery_attempts = 0
            self.unknown_actions = 0
            return
        if not self.scene_anchor:
            self.scene_anchor = fingerprint
            return
        distance = self.vision.fingerprint_distance(fingerprint, self.scene_anchor)
        threshold = 1.15 if state == GameState.COMBAT else (1.30 if self.novel_play_mode else 1.75)
        if distance >= threshold:
            self.last_effective_change = now
            self.scene_anchor = fingerprint
            self.recovery_attempts = 0

    def _on_state_change(self, old, new):
        if new == GameState.COMBAT and not self.in_combat_episode:
            self.in_combat_episode = True
            self.combat_episode_started = time.monotonic()
            self.power.entered_combat()
            self.vision.reset_combat_calibration()
            self.scene.reset_episode()
            self.world_probe = None
            self.previous_world_state = None
            self.tactical_mode = "观察"
            self.last_tactic = ""
            self.terminal_candidate_since = 0.0
            self.terminal_hud_peak = 0
        if self.in_combat_episode and new == GameState.REWARD:
            self.power.combat_result(True)
            self.world_model.note_terminal(True)
            self.in_combat_episode = False
            self.world_probe = None
            self.terminal_candidate_since = 0.0
            self.world_model.save()
        elif self.in_combat_episode and new == GameState.RETRY:
            self.power.combat_result(False)
            self.world_model.note_terminal(False)
            self.in_combat_episode = False
            self.world_probe = None
            self.terminal_candidate_since = 0.0
            self.world_model.save()
        elif self.in_combat_episode and new in (GameState.HOME, GameState.SELECT_STAGE, GameState.EQUIPMENT, GameState.UPGRADE):
            self.world_model.note_terminal(None)
            self.in_combat_episode = False
            self.world_probe = None
            self.previous_world_state = None
            self.terminal_candidate_since = 0.0
            self.scene.reset_episode()
            self.world_model.save()
        if old == GameState.COMBAT and new != GameState.COMBAT:
            self.io.release_all()

    def _infer_neutral_terminal(self, state, frame, now):
        if not self.in_combat_episode:
            self.terminal_candidate_since = 0.0
            return False
        hud = self.vision.hud_score(frame)
        self.terminal_hud_peak = max(self.terminal_hud_peak, int(hud))
        if state == GameState.COMBAT:
            self.terminal_candidate_since = 0.0
            return False
        boss_missing = self.combat_obs.boss_ratio is None
        hud_missing = self.terminal_hud_peak >= 2 and hud <= 0
        scene_jump = self.world_state is not None and float(self.world_state.scene_change) >= 0.72
        candidate = state == GameState.UNKNOWN and boss_missing and hud_missing and scene_jump
        if not candidate:
            self.terminal_candidate_since = 0.0
            return False
        if not self.terminal_candidate_since:
            self.terminal_candidate_since = now
            return False
        if now - self.terminal_candidate_since < 1.25:
            return False
        self.io.release_all()
        self.world_model.note_terminal(None)
        self.in_combat_episode = False
        self.world_probe = None
        self.previous_world_state = None
        self.terminal_candidate_since = 0.0
        self.scene.reset_episode()
        self.world_model.save()
        self.send_status("检测到战斗视觉终止但无法可靠判定胜负｜按中性 terminal 重置学习状态｜键鼠输入接管")
        return True

    def _handle_state(self, state, motion, fingerprint, now):
        stale_for = now - self.last_effective_change
        if state == GameState.LOADING:
            self.io.release_all()
            if now - self.state_since > 90:
                raise RestartGame("加载超过 90 秒")
            return
        if state == GameState.UNKNOWN:
            danger = self.vision.has_danger(self.snapshot)
            if not danger and self.novel_play_mode and self.world_state is not None:
                if motion >= 0.42 or self.world_state.crowd >= 0.12 or self.world_state.scene_change >= 0.12:
                    self._novel_gameplay(now)
                    return
            if (
                self.in_combat_episode and self.world_state is not None and not danger
                and (motion >= 0.55 or self.world_state.crowd >= 0.18 or self.world_state.scene_change >= 0.16)
            ):
                self._combat(now, motion)
                return
            self.io.release_all()
            if (
                self.unknown_actions < 10 and now - self.last_action >= 1.45
                and self.snapshot and now - self.snapshot.captured_at <= 4.5
            ):
                growth_word = self.vision.safe_growth_action_word(self.snapshot)
                if growth_word and self._click_unknown_word(growth_word, "safe_growth", fingerprint):
                    self.unknown_actions += 1
                    self.tactical_mode = "安全成长探索"
                    return
                word = self.vision.generic_safe_action_word(self.snapshot)
                if word and self._click_unknown_word(word):
                    self.unknown_actions += 1
                    self.tactical_mode = "陌生界面安全探索"
                    return
            timeout = 150 if self.novel_play_mode else 105
            if now - self.state_since > timeout and stale_for > 58:
                if not self.ocr_available:
                    self.last_effective_change = now
                    self.send_status("纯视觉模式无法安全确认当前菜单，保持等待且不执行危险点击｜键鼠输入接管")
                    return
                raise RestartGame(f"超过 {timeout} 秒无法识别或推进当前界面")
            return
        if state == GameState.COMBAT:
            if stale_for > 16:
                self._recover_combat(now)
                return
            self._combat(now, motion)
            return
        self.io.release_all()
        if stale_for > 45 and state not in (GameState.REWARD, GameState.EQUIPMENT, GameState.UPGRADE):
            if now - self.last_action > 15:
                raise RestartGame(f"{STATE_NAMES[state]}界面长期无有效变化")
        if now - self.last_action < 1.25 or self.power.pending:
            return
        if state == GameState.HOME:
            if not self._try_growth_entry(fingerprint):
                self._click_ocr_action(state, ("冒险", "副本", "关卡", "开始游戏"), "home", fingerprint)
        elif state == GameState.SELECT_STAGE:
            if not self._click_ocr_action(state, ("挑战", "进入关卡", "开始挑战", "进入"), "stage_enter", fingerprint):
                self._select_stage(fingerprint)
        elif state == GameState.REWARD:
            self._click_ocr_action(state, ("领取", "收下", "继续", "下一关", "完成", "确定"), "reward", fingerprint)
        elif state == GameState.EQUIPMENT:
            self._click_ocr_action(state, ("一键装备", "一键穿戴", "穿戴", "更换"), "equip", fingerprint)
        elif state == GameState.UPGRADE:
            self._click_ocr_action(state, ("免费强化", "免费升级", "免费"), "free_upgrade", fingerprint)
        elif state == GameState.RETRY:
            self._click_ocr_action(state, ("再次挑战", "重新挑战", "重试", "返回关卡"), "retry", fingerprint)

    def _click_unknown_word(self, word, growth_kind=None, fingerprint=None):
        if not self.snapshot:
            return False
        rect = self._game_rect()
        if not rect:
            return False
        x, y, width, height = rect
        nx = word.cx / max(self.snapshot.width, 1)
        ny = word.cy / max(self.snapshot.height, 1)
        if self.io.click(x + width * nx, y + height * ny):
            self.last_action = time.monotonic()
            if growth_kind and fingerprint is not None:
                self.power.start_action(growth_kind, GameState.UNKNOWN, fingerprint)
            self.last_ocr_request = 0.0
            return True
        return False

    def _try_growth_entry(self, fingerprint):
        mapping = {
            "equip": (("装备", "背包"), "open_equipment"),
            "free_upgrade": (("强化", "升级", "锻造"), "open_upgrade"),
        }
        for kind in self.power.growth_action_order():
            if kind == "safe_growth":
                word = self.vision.safe_growth_action_word(self.snapshot)
                if word and self._click_unknown_word(word, "safe_growth", fingerprint):
                    return True
                continue
            priorities, open_kind = mapping[kind]
            if self._click_ocr_action(GameState.HOME, priorities, open_kind, fingerprint):
                return True
        return False

    def _click_ocr_action(self, state, priorities, kind, fingerprint):
        word = self.vision.action_word(self.snapshot, state, priorities)
        if not word or not self.snapshot:
            return False
        rect = self._game_rect()
        if not rect:
            return False
        x, y, width, height = rect
        nx = word.cx / max(self.snapshot.width, 1)
        ny = word.cy / max(self.snapshot.height, 1)
        if self.io.click(x + width * nx, y + height * ny):
            self.last_action = time.monotonic()
            self.power.start_action(kind, state, fingerprint)
            self.last_ocr_request = 0.0
            if kind in ("home", "stage_enter", "retry"):
                self.snapshot = None
            return True
        return False

    def _select_stage(self, fingerprint):
        if not self.snapshot or self.vision.has_danger(self.snapshot):
            return False
        options = []
        for word in self.snapshot.words:
            text = self.vision._compact(word.text)
            if not (
                re.fullmatch(r"\d{1,3}[-—]\d{1,3}", text)
                or re.fullmatch(r"第?\d{1,3}关", text)
            ):
                continue
            nx = word.cx / max(self.snapshot.width, 1)
            ny = word.cy / max(self.snapshot.height, 1)
            if not (0.02 <= nx <= 0.98 and 0.05 <= ny <= 0.98):
                continue
            nums = [int(x) for x in re.findall(r"\d+", text)]
            numeric = nums[0] * 1000 + (nums[1] if len(nums) > 1 else 0)
            required_power = None
            nearby = []
            for candidate in self.vision._line_candidates(self.snapshot):
                if abs(candidate.cy - word.cy) > self.snapshot.height * 0.16:
                    continue
                if abs(candidate.cx - word.cx) > self.snapshot.width * 0.38:
                    continue
                candidate_text = self.vision._compact(candidate.text).replace("，", ",")
                if "推荐战力" not in candidate_text:
                    continue
                match = re.search(r"推荐战力[：:]?([0-9][0-9,.]{0,12})(万|亿)?", candidate_text)
                if match:
                    value = self.vision._parse_power_number(match.group(1), match.group(2))
                    if value:
                        nearby.append((abs(candidate.cy - word.cy), value))
            if nearby:
                nearby.sort(key=lambda item: item[0])
                required_power = nearby[0][1]
            options.append((numeric, required_power, word, text))
        choice = self.power.choose_stage(options)
        if not choice:
            return False
        word, stage_id = choice
        rect = self._game_rect()
        if not rect:
            return False
        x, y, width, height = rect
        nx = word.cx / max(self.snapshot.width, 1)
        ny = word.cy / max(self.snapshot.height, 1)
        if self.io.click(x + width * nx, y + height * ny):
            self.power.select_stage(stage_id)
            self.power.start_action("stage_select", GameState.SELECT_STAGE, fingerprint)
            self.last_action = time.monotonic()
            self.last_ocr_request = 0.0
            return True
        return False

    def _learn_passive_transition(self, now):
        current = self.world_state
        previous = self.previous_world_state
        if current is None:
            return
        if previous is not None and self.world_probe is None and now - self.last_world_action > 0.85:
            if now - self.last_passive_sample >= 0.30:
                self.world_model.record("WAIT", previous, current)
                self.last_passive_sample = now
        self.previous_world_state = current

    def _world_effective(self, before, after, raw):
        hp_delta, _, boss_damage, approach, scene, _, _, _, threat_relief, combo_gain, advantage_gain = raw
        if boss_damage > 0.003:
            return True
        if hp_delta > 0.008 or threat_relief > 0.035 or advantage_gain > 0.025:
            return True
        if abs(approach) > 0.015 or combo_gain > 0.045:
            return True
        if scene > 0.12:
            return True
        if before.motion < 1.2 and after.motion > 2.2:
            return True
        return False
    @staticmethod
    def _aggregate_probe_effect(observations, target_latency=0.35):
        if not observations:
            return None, 0.0
        base_weights = (0.12, 0.20, 0.28, 0.40)
        weighted = []
        for base, (sample_age, _, _) in zip(base_weights, observations):
            proximity = 1.0 / (0.10 + abs(float(sample_age) - float(target_latency)))
            weighted.append(base * (0.72 + 0.28 * min(2.2, proximity * 0.20)))
        total = sum(weighted) or 1.0
        effect = [0.0] * CausalWorldModel.EFFECT_DIM
        latency = 0.0
        for weight, (sample_age, _, raw) in zip(weighted, observations):
            normalized = weight / total
            latency += sample_age * normalized
            for index, value in enumerate(raw):
                effect[index] += float(value) * normalized
        return tuple(effect), latency

    def _finalize_world_probe(self):
        probe = self.world_probe
        if not probe or not probe.get("observations"):
            self.world_probe = None
            return
        before = probe["state"]
        after = probe["observations"][-1][1]
        raw, latency = self._aggregate_probe_effect(probe["observations"], probe.get("target_latency", 0.35))
        effective = self._world_effective(before, after, raw)
        self.world_model.record(
            probe["action"], before, after, effective,
            raw_override=raw, observed_latency=latency,
        )
        value_target = math.tanh((self.world_model._utility(after) - self.world_model._utility(before) + self.world_model._transition_reward(raw, before)) / 4.0)
        control_effect = tuple(raw) + (
            max(-1.0, min(1.0, float(after.threat) - float(before.threat))),
            max(-1.0, min(1.0, float(after.impact_risk) - float(before.impact_risk))),
        )
        self.visual_encoder.observe_transition(
            probe.get("frame"), self.latest_frame, probe["action"], control_effect, value_target,
            probe.get("components"), probe.get("timing"),
        )
        self.world_probe = None

    def _resolve_world_probe(self, now):
        probe = self.world_probe
        if not probe or self.world_state is None:
            return
        age = now - probe["at"]
        sample_times = probe["sample_times"]
        next_index = probe["next_index"]
        while next_index < len(sample_times) and age >= sample_times[next_index]:
            sample_age = sample_times[next_index]
            after = self.world_state
            raw = self.world_model._raw_effect(probe["state"], after)
            probe["observations"].append((sample_age, after, raw))
            next_index += 1
            probe["next_index"] = next_index
        if next_index >= len(sample_times):
            self._finalize_world_probe()

    def _action_duration(self, action):
        scale = self.governor.input_scale
        if action in ("A", "D", "TOWARD", "RETREAT"):
            return 0.115 * scale
        if action in ("W", "S"):
            return 0.075 * scale
        if action == "K":
            return 0.045 * scale
        if action == "SPACE":
            return 0.045 * scale
        if action in ("U", "I", "O", "L"):
            return 0.035 * scale
        return 0.032 * scale
    def _effect_delay(self, action):
        if action in ("A", "D", "W", "S", "TOWARD", "RETREAT"):
            base = 0.22
        elif action == "EVADE":
            base = 0.30
        elif action == "PARAM":
            base = 0.40
        elif action in ("JJJ", "KJ", "CHASEJ"):
            base = 0.43
        elif action in ("UJ", "IJ", "OJ", "LJ", "SPACEJ"):
            base = 0.54
        elif action in ("J", "U", "I", "O", "L", "SPACE", "WAIT"):
            base = 0.34
        else:
            base = 0.30
        return self.world_model.adaptive_effect_delay(action, base) * max(0.92, min(1.12, self.governor.input_scale))

    def _smart_wait(self, seconds):
        if seconds <= 0:
            return self._input_guard()
        if self.stop_event.wait(seconds):
            return False
        return self._input_guard()

    def _direction_key(self, toward=True):
        state = self.world_state
        side = 0.0 if state is None else state.target_side
        if not side and state is not None and state.player_x is not None:
            delta = state.active_x - state.player_x
            if abs(delta) > 0.08:
                side = 1.0 if delta > 0 else -1.0
        if not side:
            side = 1.0
        if not toward:
            if state is not None and abs(state.escape_side) > 0.5:
                side = state.escape_side
            else:
                side = -side
        return "D" if side > 0 else "A"

    def _timing(self, action, kind, base):
        value = self.world_model.timing_value(action, kind, base, self.current_action_timing)
        return value * self.governor.input_scale

    def _perform_tactical_action(self, action):
        components = []
        if action == "WAIT":
            return True, components
        if action == "TOWARD":
            key = self._direction_key(True)
            return self.io.tap(key, self._action_duration("TOWARD")), [key]
        if action == "RETREAT":
            key = self._direction_key(False)
            return self.io.tap(key, self._action_duration("RETREAT") * 1.08), [key]
        if action == "PARAM":
            state = self.world_state
            if state is None:
                return False, components
            readiness = self.skill_hud.readiness()
            stamp = time.monotonic()
            def ready(key):
                if readiness.get(key) is False:
                    return False
                return stamp - self.world_model.key_last_at.get(key, -9999.0) >= self.world_model.key_gap.get(key, 0.10)
            threat = max(state.threat, state.impact_risk)
            direction = None
            if threat >= 0.64 or state.telegraph >= 0.62:
                direction = self._direction_key(False)
            elif state.distance is not None and state.distance >= 0.16:
                direction = self._direction_key(True)
            attack_pool = [key for key in ("J", "U", "I", "O", "L", "SPACE") if ready(key)]
            if state.mp is not None and state.mp < self.world_model.threshold("low_mp"):
                attack_pool = [key for key in attack_pool if key == "J"]
            if state.boss is None or state.engaged < 0.30:
                attack_pool = [key for key in attack_pool if key != "SPACE"]
            if not attack_pool and ready("J"):
                attack_pool = ["J"]
            attack = None
            if attack_pool:
                deadline = time.perf_counter() + max(0.001, self.governor.planning_budget * 0.22)
                ranked = []
                for key in attack_pool:
                    try:
                        score = self.world_model.action_score(key, state, depth=1, deadline=deadline)[0]
                    except Exception:
                        score = 0.0
                    ranked.append((float(score), key))
                    if time.perf_counter() >= deadline and ranked:
                        break
                ranked.sort(reverse=True)
                attack = ranked[0][1] if ranked else attack_pool[0]
            jump = ready("K") and (state.telegraph >= 0.48 or state.impact_risk >= 0.46 or state.risk_trend >= 0.42)
            hold = 0.055
            if state.distance is not None:
                hold += min(0.12, max(0.0, state.distance - 0.08) * 0.28)
            if threat >= 0.64:
                hold = min(0.13, hold + 0.025)
            hold = self._timing(action, "down", hold)
            if direction:
                if not self.io.key_down(direction):
                    return False, components
                components.append(direction)
            try:
                if direction and not self._smart_wait(min(hold, self._timing(action, "gap", 0.030))):
                    return False, components
                if jump:
                    if not self.io.tap("K", self._action_duration("K")):
                        return False, components
                    components.append("K")
                    if not self._smart_wait(self._timing(action, "gap", 0.028)):
                        return False, components
                if attack:
                    if not self.io.tap(attack, self._action_duration(attack)):
                        return False, components
                    components.append(attack)
                    if attack != "J" and state.opening >= 0.48 and ready("J") and self._smart_wait(self._timing(action, "gap", 0.038)):
                        if self.io.tap("J", self._action_duration("J")):
                            components.append("J")
                if direction:
                    remaining = max(0.0, hold - self._timing(action, "gap", 0.030))
                    if remaining > 0.0:
                        self._smart_wait(remaining)
                return bool(components), components
            finally:
                if direction:
                    self.io.key_up(direction)
        if action == "EVADE":
            key = self._direction_key(False)
            if not self.io.key_down(key):
                return False, components
            components.append(key)
            try:
                if not self._smart_wait(self._timing(action, "gap", 0.018)):
                    return False, components
                if not self.io.tap("K", self._timing(action, "down", 0.040)):
                    return False, components
                components.append("K")
                self._smart_wait(self._timing(action, "gap", 0.055))
                return True, components
            finally:
                self.io.key_up(key)
        if action == "JJJ":
            for index in range(3):
                if not self.io.tap("J", self._timing(action, "down", 0.026)):
                    return False, components
                components.append("J")
                if index < 2 and not self._smart_wait(self._timing(action, "gap", 0.034)):
                    return False, components
            return True, components
        if action == "KJ":
            if not self.io.tap("K", self._timing(action, "down", 0.040)):
                return False, components
            components.append("K")
            if not self._smart_wait(self._timing(action, "gap", 0.052)) or not self.io.tap("J", self._timing(action, "down", 0.028)):
                return False, components
            components.append("J")
            if self._smart_wait(self._timing(action, "gap", 0.035)) and self.io.tap("J", self._timing(action, "down", 0.025)):
                components.append("J")
            return True, components
        if action == "CHASEJ":
            direction = self._direction_key(True)
            if not self.io.key_down(direction):
                return False, components
            components.append(direction)
            try:
                if not self._smart_wait(self._timing(action, "gap", 0.040)) or not self.io.tap("J", self._timing(action, "down", 0.028)):
                    return False, components
                components.append("J")
                if not self._smart_wait(self._timing(action, "gap", 0.050)) or not self.io.tap("J", self._timing(action, "down", 0.026)):
                    return False, components
                components.append("J")
                return True, components
            finally:
                self.io.key_up(direction)
        if action in ("UJ", "IJ", "OJ", "LJ"):
            skill = action[0]
            if not self.io.tap(skill, self._timing(action, "down", 0.034)):
                return False, components
            components.append(skill)
            if not self._smart_wait(self._timing(action, "gap", 0.060)) or not self.io.tap("J", self._timing(action, "down", 0.026)):
                return False, components
            components.append("J")
            return True, components
        if action == "SPACEJ":
            if not self.io.tap("SPACE", self._timing(action, "down", 0.044)):
                return False, components
            components.append("SPACE")
            if not self._smart_wait(self._timing(action, "gap", 0.070)) or not self.io.tap("J", self._timing(action, "down", 0.027)):
                return False, components
            components.append("J")
            if self._smart_wait(self._timing(action, "gap", 0.040)) and self.io.tap("J", self._timing(action, "down", 0.025)):
                components.append("J")
            return True, components
        if action in CausalWorldModel.PRIMITIVES:
            return self.io.tap(action, self._action_duration(action)), [action]
        return False, components

    def _candidate_actions(self, state, available):
        self.world_model.set_policy_context(state)
        allowed = set(available)
        if not allowed:
            return []
        hp = 0.70 if state.hp is None else state.hp
        mp = 0.70 if state.mp is None else state.mp
        distance = state.distance
        threat = max(state.threat, state.impact_risk * 0.92)
        boss = state.boss
        skill_actions = {"U", "I", "O", "L", "UJ", "IJ", "OJ", "LJ"}
        if hp < self.world_model.threshold("survival_hp"):
            self.tactical_mode = "极限保命"
            desired = ["EVADE", "H", "SPACE", "K", "RETREAT", "KJ", "A", "D"]
        elif state.impact_risk >= self.world_model.threshold("evade_impact") or state.risk_trend >= self.world_model.threshold("evade_trend") or state.telegraph >= self.world_model.threshold("evade_telegraph") or threat >= self.world_model.threshold("evade_threat") or state.incoming >= self.world_model.threshold("evade_incoming"):
            self.tactical_mode = "预判读招规避"
            desired = ["EVADE", "K", "RETREAT", "KJ", "SPACE", "H", "J", "TOWARD"]
        elif state.opening >= self.world_model.threshold("opening") and distance is not None and distance <= max(self.world_model.threshold("mid_distance") * 1.65, 0.24):
            self.tactical_mode = "抓后摇爆发"
            desired = ["UJ", "IJ", "OJ", "LJ", "SPACEJ", "JJJ", "J", "KJ", "CHASEJ", "TOWARD"]
        elif distance is None:
            self.tactical_mode = "寻敌推进"
            desired = ["TOWARD", "D", "F", "W", "S", "K", "J", "A", "Z"]
        elif distance > self.world_model.threshold("far_distance"):
            self.tactical_mode = "追击"
            desired = ["TOWARD", "CHASEJ", "K", "U", "I", "O", "L", "F", "D", "A"]
        elif distance > self.world_model.threshold("mid_distance"):
            self.tactical_mode = "中距压制"
            desired = ["CHASEJ", "TOWARD", "J", "JJJ", "UJ", "IJ", "OJ", "LJ", "KJ", "SPACEJ", "K", "EVADE"]
        else:
            if boss is not None and (boss < 0.34 or state.combo > 0.58) and threat < 0.58:
                self.tactical_mode = "斩杀爆发"
                desired = ["SPACEJ", "UJ", "IJ", "OJ", "LJ", "JJJ", "J", "KJ", "RETREAT"]
            else:
                self.tactical_mode = "近身连压"
                desired = ["JJJ", "J", "UJ", "IJ", "OJ", "LJ", "KJ", "SPACEJ", "EVADE", "RETREAT", "H"]
        if mp < self.world_model.threshold("low_mp"):
            desired = [a for a in desired if a not in skill_actions]
        elif mp < self.world_model.threshold("mid_mp"):
            desired = [a for a in desired if a not in ("UJ", "IJ", "OJ", "LJ")]
            for skill in ("U", "I", "O", "L"):
                if skill in allowed:
                    desired.append(skill)
        if boss is None and state.engaged < 0.45 and state.crowd < 0.35:
            desired = [a for a in desired if a not in ("SPACEJ", "SPACE")]
        novel = max(state.novelty, state.phase_shift)
        if novel >= self.world_model.threshold("novelty_probe") and hp >= self.world_model.threshold("probe_hp") and threat <= self.world_model.threshold("probe_threat"):
            self.tactical_mode = "陌生机制因果探测"
            probes = ["F", "TOWARD", "K", "J", "W", "S", "A", "D", "EVADE", "RETREAT", "U", "I", "O", "L", "Z", "SPACE"]
            probes = [a for a in probes if a in allowed]
            probes.sort(key=lambda a: self.world_model.probe_score(a, state), reverse=True)
            probe_head = probes[:max(5, int(math.sqrt(max(1, self.governor.candidate_budget)) * 3))]
            desired = probe_head + [a for a in desired if a not in probe_head]
        learned = []
        if threat < 0.68 and state.telegraph < 0.58 and state.impact_risk < 0.54:
            learned = self.world_model.learned_sequence_candidates(state, allowed, limit=max(3, int(math.sqrt(max(1, self.governor.candidate_budget)))))
        desired = learned + [a for a in desired if a not in learned]
        if "PARAM" in allowed and (state.distance is not None or state.engaged >= 0.24 or novel >= 0.35):
            insert_at = min(2, len(desired))
            desired.insert(insert_at, "PARAM")
        result = [a for a in desired if a in allowed]
        if not result:
            result = list(available)
        budget = max(5, int(self.governor.candidate_budget))
        return result[:budget]
    def _execute_world_action(self, action, now):
        before = self.world_state
        if before is None or self.world_probe is not None:
            return False
        self.io.release_all()
        timing = self.world_model.sample_timing(action) if action != "WAIT" else {"down": 1.0, "gap": 1.0}
        self.current_action_timing = timing
        try:
            ok, components = self._perform_tactical_action(action)
        finally:
            self.current_action_timing = None
        if not ok:
            self.world_model.pending_timing = None
            self.io.release_all()
            return False
        stamp = time.monotonic()
        self.world_model.note_execution(action, stamp, components, before, timing=timing)
        for key in components:
            self.skill_hud.note_action(key, stamp)
        self.last_world_action = stamp
        self.last_action = stamp
        self.last_tactic = action
        adaptive = self._effect_delay(action)
        self.world_probe = {
            "action": action,
            "state": before,
            "frame": self.latest_frame,
            "components": tuple(components),
            "timing": dict(timing),
            "at": stamp,
            "sample_times": (0.10, 0.20, 0.35, 0.55),
            "target_latency": adaptive,
            "next_index": 0,
            "observations": [],
        }
        return True
    def _emergency_reflex(self, now):
        state = self.world_state
        self.world_model.set_policy_context(state)
        if state is None or now - self.last_emergency < 0.24:
            return False
        hp = 0.70 if state.hp is None else state.hp
        urgent = (
            state.impact_risk >= self.world_model.threshold("emergency_impact")
            or state.risk_trend >= self.world_model.threshold("emergency_trend")
            or state.telegraph >= self.world_model.threshold("emergency_telegraph")
            or state.incoming >= self.world_model.threshold("emergency_incoming")
            or state.threat >= self.world_model.threshold("emergency_threat")
            or (hp < self.world_model.threshold("emergency_hp") and max(state.threat, state.impact_risk) >= self.world_model.threshold("evade_incoming"))
        )
        if not urgent:
            return False
        if self.world_probe is not None:
            probe = self.world_probe
            if now - probe["at"] >= 0.08:
                raw = self.world_model._raw_effect(probe["state"], state)
                probe.setdefault("observations", []).append((max(0.08, now - probe["at"]), state, raw))
                self._finalize_world_probe()
            else:
                self.world_probe = None
        available = self.world_model.available(now, self.skill_hud.readiness())
        emergency = [a for a in ("EVADE", "K", "RETREAT", "H", "SPACE", "KJ", "A", "D") if a in available]
        if not emergency:
            return False
        action, score = self.world_model.choose(state, emergency, depth=1)
        if action and self._execute_world_action(action, now):
            self.last_emergency = now
            self.tactical_mode = "提前量保命反应"
            self.last_plan_score = score
            return True
        return False

    def _timed_plan(self, state, candidates, budget_scale=1.0):
        budget = max(0.0015, self.governor.planning_budget * max(0.25, min(1.25, float(budget_scale))))
        self.world_model.set_runtime_budget(self.governor.candidate_budget, budget)
        self.world_model.set_policy_context(state)
        started = time.perf_counter()
        action, score, depth, complete = self.world_model.choose_iterative(state, candidates, budget)
        self.governor.note_planning(time.perf_counter() - started, depth, complete)
        return action, score

    def _combat(self, now, motion):
        self.world_model.set_policy_context(self.world_state)
        if self._emergency_reflex(now):
            return
        if self.world_probe is not None:
            return
        state = self.world_state
        if state is None:
            return
        available = self.world_model.available(now, self.skill_hud.readiness())
        if not available:
            return
        hp = 0.70 if state.hp is None else state.hp
        if hp > 0.64 and state.threat < 0.24 and self.world_model.needs_baseline():
            if self._execute_world_action("WAIT", now):
                self.tactical_mode = "观察建模"
                self.last_plan_score = 0.0
                return
        candidates = self._candidate_actions(state, available)
        action, score = self._timed_plan(state, candidates)
        if action is None:
            return
        self.last_plan_score = score
        self._execute_world_action(action, now)
    def _recover_combat(self, now):
        if now - self.last_recovery < 1.6:
            return
        self.io.release_all()
        self.recovery_attempts += 1
        self.power.record_stuck()
        self.last_recovery = now
        self.world_probe = None
        state = self.world_state
        self.tactical_mode = "脱困重规划"
        if state is not None:
            available = self.world_model.available(now, self.skill_hud.readiness())
            candidates = [a for a in ("EVADE", "TOWARD", "KJ", "K", "F", "CHASEJ", "J", "W", "S", "RETREAT", "D", "A") if a in available]
            if candidates:
                action, score = self._timed_plan(state, candidates, 0.75)
                if action and self._execute_world_action(action, now):
                    self.last_plan_score = score
                    return
        fallback = ("F", "K", "D", "J", "W", "A")[(self.recovery_attempts - 1) % 6]
        self.io.tap(fallback, self._action_duration(fallback))
        if self.recovery_attempts >= 11 and now - self.last_effective_change > 68:
            raise RestartGame("战术模型连续脱困失败，战斗超过 68 秒无有效推进")
    def _status(self, state):
        if self.power.current_power:
            power_text = f"战力 {self.power.current_power:,}"
        else:
            power_text = "战力待识别"
        if self.ocr_available:
            lang = self.ocr.worker.language or "?"
            ocr_text = f"OCR:{lang}"
        else:
            ocr_text = "纯视觉"
        ready_map = self.skill_hud.readiness()
        visual_skill_count = sum(1 for value in ready_map.values() if value is not None)
        def pct(value):
            return "--" if value is None else f"{int(max(0.0, min(1.0, value)) * 100):d}%"
        obs = self.combat_obs
        visual = f"HP {pct(obs.hp_ratio)} MP {pct(obs.mp_ratio)}"
        if obs.player_x is not None and obs.enemy_x is not None:
            if obs.player_y is not None and obs.enemy_y is not None:
                visual += f" 敌距 {math.hypot(obs.enemy_x - obs.player_x, (obs.enemy_y - obs.player_y) * 0.72):.2f}"
            else:
                visual += f" 敌距 {abs(obs.enemy_x - obs.player_x):.2f}"
        confidence = int(self.world_model.model_confidence() * 100)
        context_conf = int(self.world_model.context_confidence(self.world_state) * 100) if self.world_state else 0
        memory = len(self.world_model.memory)
        lifetime_k = self.world_model.lifetime_updates / 1000.0
        threat = int(max(0.0, min(1.0, self.world_state.threat if self.world_state else 0.0)) * 100)
        telegraph = int(max(0.0, min(1.0, self.world_state.telegraph if self.world_state else 0.0)) * 100)
        impact = int(max(0.0, min(1.0, self.world_state.impact_risk if self.world_state else 0.0)) * 100)
        tactic = self.last_tactic or "--"
        cpu = int(self.governor.cpu_load * 100) if self.governor.cpu_load else 0
        ram = int(self.governor.memory_load * 100) if self.governor.memory_load else 0
        gpu = self.profile.gpu_name.strip()
        gpu_text = (gpu[:18] + "…") if len(gpu) > 19 else (gpu or "GPU?")
        mode = "新玩法" if self.novel_play_mode and state == GameState.UNKNOWN else STATE_NAMES[state]
        self.send_status(
            f"{mode}｜{power_text}｜{visual}｜{self.tactical_mode} 威胁{threat}% 预兆{telegraph}% 冲击{impact}%｜招式 {tactic}｜模型 {confidence}% 局部{context_conf}%/{memory}条/终身{lifetime_k:.1f}k｜规划{self.governor.planning_depth}层 {self.last_plan_score:+.2f}｜{self.profile.label}/{self.governor.mode} {self.governor.estimated_hz:.0f}Hz CPU{cpu}% RAM{ram}%｜捕获:{self.grabber.backend_name} {gpu_text}/推理:{self.world_model.compute_backend}｜战力↑ {self.power.actual_power_gains}｜{ocr_text}/技能视觉{visual_skill_count}｜键鼠输入接管"
        )


class RunState(Enum):
    IDLE = auto()
    RUNNING = auto()
    STOPPING = auto()


class App:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("520x270")
        self.root.resizable(False, False)
        self.root.configure(bg="#101722")
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.base_dir = _select_data_dir(self.root, self.script_dir)
        self.firefox_path = _resolve_firefox_path(self.script_dir)
        self.profile = detect_runtime_profile(self.base_dir)
        self.messages = queue.SimpleQueue()
        self.persistence = PersistenceMonitor(self._send_status)
        self.stop_event = threading.Event()
        self.io = WinIO()
        self.input_monitor = HumanInputMonitor(self.io, self.stop_event)
        self.worker = None
        self.run_state = RunState.IDLE
        self.worker_done = True
        self.user_override = False
        self.closing = False
        self.close_deadline = 0.0
        self.owned_game_windows = {}
        cleanup_runtime_artifacts(self.base_dir)
        self._build()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(45, self.poll)

    def _owned_game_pid(self, hwnd):
        return self.owned_game_windows.get(int(hwnd), 0)

    def _build(self):
        tk.Label(
            self.root,
            text="造梦西游之黎尤浩劫篇",
            font=("Microsoft YaHei UI", 19, "bold"),
            fg="#f4f7fb",
            bg="#101722",
        ).pack(pady=(22, 4))
        tk.Label(
            self.root,
            text="陌生机制探索｜因果规划｜硬件自适应｜战力闭环",
            font=("Microsoft YaHei UI", 10),
            fg="#91a4ba",
            bg="#101722",
        ).pack()
        self.button = tk.Button(
            self.root,
            text="AI",
            command=self.start,
            width=13,
            height=2,
            font=("Microsoft YaHei UI", 16, "bold"),
            fg="white",
            bg="#16a56a",
            activebackground="#128357",
            activeforeground="white",
            bd=0,
            cursor="hand2",
        )
        self.button.pack(pady=20)
        ram = f"{self.profile.memory_gb:.0f}GB" if self.profile.memory_gb > 0 else "RAM?"
        gpu = self.profile.gpu_name.strip() or "GPU未识别"
        if len(gpu) > 28:
            gpu = gpu[:28] + "…"
        cpu_text = f"{self.profile.physical_cores or self.profile.cores}C/{self.profile.cores}T"
        if self.profile.cpu_mhz > 0:
            cpu_text += f" {self.profile.cpu_mhz / 1000.0:.1f}GHz"
        power_text = " 电池" if self.profile.on_battery else ""
        disk_text = f"盘余{self.profile.disk_free_gb:.0f}GB" if self.profile.disk_free_gb > 0 else "磁盘?"
        self.status = tk.StringVar(value=f"点击 AI 开始｜{self.profile.label}{power_text} {cpu_text}/{ram}/{disk_text}｜{gpu}｜任意键鼠输入可接管")
        tk.Label(
            self.root,
            textvariable=self.status,
            font=("Microsoft YaHei UI", 9),
            fg="#c6d2df",
            bg="#101722",
            wraplength=485,
        ).pack()

    def start(self):
        if self.run_state != RunState.IDLE or (self.worker is not None and self.worker.is_alive()):
            return
        self.firefox_path = _resolve_firefox_path(self.script_dir)
        if not self.input_monitor.wait_ready(1.5):
            self.status.set("全局键鼠接管监控未就绪，AI 未启动")
            return
        existing = self.io.choose_existing_firefox(self.firefox_path)
        if not os.path.isfile(self.firefox_path) and not existing:
            self.status.set("未找到已打开的游戏窗口或 FirefoxPortable.exe；已自动检查非 C 盘常见 Portable Firefox 路径")
            return
        self.run_state = RunState.RUNNING
        self.worker_done = False
        self.user_override = False
        self.stop_event.clear()
        self.input_monitor.arm()
        self.button.configure(state="disabled", text="运行中", bg="#4c657d")
        monitor_text = "低级钩子" if self.input_monitor.mode == "hook" else "轮询回退"
        self.status.set(f"正在连接已打开的游戏窗口；确实不存在时才新开 Firefox｜{self.profile.label}模式｜接管监控:{monitor_text}")
        self.root.withdraw()
        self.worker = threading.Thread(target=self._worker, daemon=True)
        self.worker.start()

    def _launch_game_window(self, force_new=False, exclude_hwnds=None):
        excluded = {int(x) for x in (exclude_hwnds or ())}
        if not force_new:
            hwnd = self.io.choose_existing_firefox(self.firefox_path, excluded)
            if hwnd:
                return hwnd
        if not os.path.isfile(self.firefox_path):
            raise RuntimeError("FirefoxPortable.exe 不存在，且未找到可继续使用的游戏窗口")
        previous = {item[0]: item[1] for item in self.io.firefox_windows()}
        subprocess.Popen(
            [self.firefox_path, "-new-window", GAME_URL],
            cwd=os.path.dirname(self.firefox_path),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        deadline = time.monotonic() + 45
        while not self.stop_event.is_set() and time.monotonic() < deadline:
            hwnd = self.io.choose_firefox(previous, self.firefox_path, excluded, require_new=True)
            if hwnd:
                self.owned_game_windows[int(hwnd)] = self.io.window_pid(hwnd)
                return hwnd
            self.stop_event.wait(0.35)
        if self.stop_event.is_set():
            return 0
        raise RuntimeError("未找到新开的 Firefox 游戏窗口")

    def _worker(self):
        hwnd = 0
        tracker = None
        try:
            restart_times = []
            restart_excluded = set()
            force_new = False
            _prepare_ai_dependencies(self.base_dir, self.profile, self.stop_event)
            if self.stop_event.is_set():
                return
            importlib.invalidate_caches()
            tracker = PowerTracker(os.path.join(self.base_dir, ".ai_progress.json"), self.persistence)
            while not self.stop_event.is_set():
                hwnd = self._launch_game_window(force_new=force_new, exclude_hwnds=restart_excluded)
                force_new = False
                if not hwnd or self.stop_event.is_set():
                    return
                self.messages.put(("status", "候选游戏窗口已找到，正在进行二阶段确认…｜键鼠输入接管"))
                session_started = time.monotonic()
                try:
                    if self.profile.prefer_dxgi:
                        gpu_name = self.profile.gpu_name.strip() or "独立GPU"
                        self.messages.put(("status", f"检测到 {gpu_name}｜从所选数据目录加载或准备GPU捕获；异常时自动回退并重试｜键鼠输入接管"))
                    AdaptiveAgent(
                        self.io, hwnd, self.stop_event, self._send_status, self.base_dir, tracker, self.profile, self.persistence
                    ).run()
                    return
                except RestartGame as exc:
                    self.io.release_all()
                    now = time.monotonic()
                    if now - session_started >= RESTART_RESET_AFTER:
                        restart_times.clear()
                    restart_times = [stamp for stamp in restart_times if now - stamp <= RESTART_WINDOW_SECONDS]
                    restart_times.append(now)
                    if self.stop_event.is_set():
                        return
                    if len(restart_times) > MAX_RESTARTS_PER_WINDOW:
                        raise RuntimeError(f"10 分钟内自动恢复超过 3 次：{exc}")
                    self.messages.put(("status", f"检测到卡住：{exc}｜正在安全重开游戏窗口（10分钟窗口 {len(restart_times)}/3）"))
                    restart_excluded.add(int(hwnd))
                    if int(hwnd) in self.owned_game_windows:
                        self.io.close_owned_game_window(hwnd, self._owned_game_pid(hwnd))
                        self.owned_game_windows.pop(int(hwnd), None)
                    force_new = True
                    self.stop_event.wait(1.0)
                    hwnd = 0
        except Exception as exc:
            self.messages.put(("status", f"已停止：{exc}"))
        finally:
            try:
                if tracker is not None:
                    tracker.save()
            except Exception as exc:
                self.persistence.fail("progress", exc)
            self.io.bind_input_guard(None)
            self.io.release_all()
            self.messages.put(("done", None))

    def _send_status(self, text):
        self.messages.put(("status", text))

    def _show_main(self):
        try:
            self.root.deiconify()
            self.root.state("normal")
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.focus_force()
            self.root.after(220, lambda: self.root.attributes("-topmost", False) if self.root.winfo_exists() else None)
        except Exception:
            pass

    def _human_override(self, reason="键鼠"):
        if self.run_state != RunState.RUNNING:
            return
        self.run_state = RunState.STOPPING
        self.user_override = True
        self.input_monitor.disarm()
        self.stop_event.set()
        self.io.release_all()
        self.button.configure(state="disabled", text="停止中", bg="#4c657d")
        storage = "｜经验保存异常" if self.persistence.failed else ""
        self.status.set(f"检测到用户{reason}操作｜AI 已停止控制｜正在保存模型并清理后台任务…{storage}")
        self._show_main()

    def stop(self):
        if self.run_state != RunState.RUNNING:
            return
        self.run_state = RunState.STOPPING
        self.input_monitor.disarm()
        self.stop_event.set()
        self.io.release_all()
        self.button.configure(state="disabled", text="停止中", bg="#4c657d")
        self.status.set("正在停止、保存模型并释放按键…")
        self._show_main()

    def _finish_stop_if_ready(self):
        if self.run_state != RunState.STOPPING:
            return
        worker_alive = bool(self.worker and self.worker.is_alive())
        if not self.worker_done or worker_alive or _dependency_jobs_active(self.base_dir):
            return
        self.input_monitor.disarm()
        self.io.release_all()
        self.run_state = RunState.IDLE
        self._show_main()
        self.button.configure(state="normal", text="AI", bg="#16a56a")
        storage = "｜经验保存异常" if self.persistence.failed else ""
        if self.user_override:
            self.status.set(f"AI 已关闭｜用户已接管｜点击 AI 可重新开始{storage}")
        else:
            self.status.set(f"AI 已关闭｜点击 AI 可重新开始{storage}")

    def poll(self):
        reason = self.input_monitor.take_trigger()
        if reason:
            self._human_override(reason)
        while True:
            try:
                kind, value = self.messages.get_nowait()
            except queue.Empty:
                break
            if kind == "status":
                if self.run_state == RunState.RUNNING and not self.user_override:
                    self.status.set(value)
            elif kind == "human":
                self._human_override(value or "键鼠")
            elif kind == "done":
                self.worker_done = True
                if self.run_state == RunState.RUNNING:
                    self.run_state = RunState.STOPPING
                    self.stop_event.set()
                    self.button.configure(state="disabled", text="停止中", bg="#4c657d")
                    self._show_main()
        self._finish_stop_if_ready()
        self.root.after(45, self.poll)

    def close(self):
        if self.closing:
            return
        self.closing = True
        self.run_state = RunState.STOPPING
        self.stop_event.set()
        self.input_monitor.close()
        self.io.release_all()
        self.close_deadline = time.monotonic() + 3.0
        self.status.set("正在关闭并清理 OCR/工作线程…")
        self._finish_close()

    def _finish_close(self):
        worker_alive = bool(self.worker and self.worker.is_alive())
        dependency_alive = _dependency_jobs_active(self.base_dir)
        if (worker_alive or dependency_alive) and time.monotonic() < self.close_deadline:
            self.root.after(50, self._finish_close)
            return
        self.io.release_all()
        self.root.destroy()


def cleanup_runtime_artifacts(base_dir):
    base_dir = os.path.abspath(base_dir)
    now = time.time()
    backups = {}
    try:
        for name in os.listdir(base_dir):
            path = os.path.join(base_dir, name)
            if name.startswith(".ai_ocr_") and name.endswith(".bmp"):
                try:
                    if now - os.path.getmtime(path) >= 600.0:
                        os.remove(path)
                except OSError:
                    pass
                continue
            match = re.match(r"^(.*)\.(rejected|corrupt)\.(\d+)$", name)
            if match and os.path.isfile(path):
                backups.setdefault((match.group(1), match.group(2)), []).append(path)
            if name.startswith(".ai_") and name.endswith(".tmp") and os.path.isfile(path):
                try:
                    if now - os.path.getmtime(path) >= 86400.0:
                        os.remove(path)
                except OSError:
                    pass
    except OSError:
        pass
    for rows in backups.values():
        rows.sort(key=lambda path: os.path.getmtime(path) if os.path.exists(path) else 0.0, reverse=True)
        for path in rows[2:]:
            try:
                os.remove(path)
            except OSError:
                pass
    temp_root = os.path.join(base_dir, ".ai_tmp")
    if os.path.isdir(temp_root):
        for root, dirs, files in os.walk(temp_root, topdown=False):
            for name in files:
                path = os.path.join(root, name)
                try:
                    if now - os.path.getmtime(path) >= 86400.0:
                        os.remove(path)
                except OSError:
                    pass
            for name in dirs:
                path = os.path.join(root, name)
                try:
                    if not os.listdir(path):
                        os.rmdir(path)
                except OSError:
                    pass


def main():
    if platform.system() != "Windows":
        raise SystemExit("本程序仅支持 Windows 11")
    enable_dpi_awareness()
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
